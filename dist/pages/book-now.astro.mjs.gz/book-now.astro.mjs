import { c as createComponent, r as renderComponent, a as renderTemplate, m as maybeRenderHead } from '../chunks/astro/server_DL3Tye_C.mjs';
import 'piccolore';
import { $ as $$MainLayout } from '../chunks/MainLayout_B3UWJLyy.mjs';
import { $ as $$PageHero, a as $$TrustStrip } from '../chunks/TrustStrip_B_sgXsCD.mjs';
export { renderers } from '../renderers.mjs';

const $$BookNow = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "MainLayout", $$MainLayout, { "title": "Book Now - Emerald City Limos Seattle Limo Service", "description": "Book your luxury transportation with Emerald City Limos. Professional chauffeur service available 24/7 in Seattle and surrounding areas.", "keywords": "book limo seattle, reserve car service seattle, seattle limo booking, emerald city limos" }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<div class="bg-gray-50"> ${renderComponent($$result2, "PageHero", $$PageHero, { "eyebrow": "Reserve in 60 Seconds", "headline": "Book Your", "headlineAccent": "Seattle Luxury Ride", "supporting": "Reserve any vehicle in our fleet \u2014 sedan, SUV, Sprinter, or motorcoach \u2014 in under a minute. Confirmation, flight tracking, and a dedicated dispatcher follow instantly.", "image": {
    src: "https://images.unsplash.com/photo-1449965408869-eaa3f722e40d?w=1920&h=1080&fit=crop&q=85&fm=webp&auto=format",
    alt: "Luxury black car at night ready for booking"
  }, "size": "page", "id": "book-now-hero" })} ${renderComponent($$result2, "TrustStrip", $$TrustStrip, {})}  <section class="py-12"> <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8"> <div class="bg-white rounded-lg shadow-xl overflow-hidden" style="min-height: 800px;"> <iframe src="https://customer.moovs.app/a1-charters-1/iframe" title="Moovs App" class="w-full border-0" style="min-height: 800px; height: 100vh;" loading="eager"></iframe> </div> </div> </section>  <section class="py-16 bg-white"> <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center"> <h2 class="text-3xl font-bold text-gray-900 mb-6">Need Help Booking?</h2> <p class="text-xl text-gray-600 mb-8">
Our team is available 24/7 to assist you
</p> <div class="flex flex-col sm:flex-row gap-4 justify-center"> <a href="tel:+12065959675" class="bg-emerald-700 hover:bg-emerald-800 text-white px-8 py-4 rounded-lg font-semibold transition-all inline-flex items-center justify-center"> <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"> <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"></path> </svg>
Call (206) 595-9675
</a> <a href="mailto:client@emeraldcitylimos.com" class="bg-[#d4af37] hover:bg-[#b8941f] text-black px-8 py-4 rounded-lg font-semibold transition-all inline-flex items-center justify-center"> <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"> <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path> </svg>
Email Us
</a> </div> </div> </section> </div> ` })}`;
}, "/home/josh/Documents/emerald-update/src/pages/book-now.astro", void 0);

const $$file = "/home/josh/Documents/emerald-update/src/pages/book-now.astro";
const $$url = "/book-now";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$BookNow,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };

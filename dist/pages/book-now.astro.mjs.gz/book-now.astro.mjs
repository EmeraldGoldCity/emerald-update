import { c as createAstro, a as createComponent, r as renderTemplate, d as addAttribute, m as maybeRenderHead, b as renderComponent } from '../chunks/astro/server_Cr-soRLN.mjs';
import 'piccolore';
import { $ as $$MainLayout } from '../chunks/MainLayout_BHrzvkR-.mjs';
import 'clsx';
export { renderers } from '../renderers.mjs';

var __freeze = Object.freeze;
var __defProp = Object.defineProperty;
var __template = (cooked, raw) => __freeze(__defProp(cooked, "raw", { value: __freeze(cooked.slice()) }));
var _a;
const $$Astro = createAstro("https://emeraldcitylimos.com");
const $$BookingWidget = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$BookingWidget;
  const {
    src = "https://customer.moovs.app/a1-charters-1/iframe",
    minHeight = "820px"
  } = Astro2.props;
  return renderTemplate(_a || (_a = __template(["", '<section class="bg-brand-forest py-12 sm:py-16" aria-labelledby="booking-widget-heading"> <div class="mx-auto max-w-7xl px-6 sm:px-8 lg:px-12"> <div class="mb-6 flex flex-col gap-3 sm:mb-8 sm:flex-row sm:items-end sm:justify-between"> <div> <div class="mb-2 flex items-center gap-3"> <span class="h-px w-8 bg-brand-gold" aria-hidden="true"></span> <p class="font-sans text-[10px] font-semibold uppercase tracking-[0.22em] text-brand-gold">\nReservation Portal\n</p> </div> <h2 id="booking-widget-heading" class="font-display text-white text-2xl font-light leading-tight text-brand-forest sm:text-3xl" style="letter-spacing: -0.01em;">\nBook in <em class="italic text-brand-gold">under two minutes.</em> </h2> </div> <p class="hidden font-sans text-[0.78rem] text-brand-forest/60 sm:block">\nPowered by Moovs \xB7 secured booking\n</p> </div> <div data-booking-widget', ' class="relative overflow-hidden border border-brand-forest/10 bg-white shadow-[0_24px_48px_-32px_rgba(10,35,24,0.18)]"', `> <!-- Placeholder: visible until the iframe is injected --> <div data-booking-placeholder class="absolute inset-0 flex flex-col items-center justify-center gap-5 bg-brand-champagne px-6 text-center" aria-hidden="false"> <span class="pointer-events-none absolute inset-0" style="background: radial-gradient(ellipse 60% 50% at center, rgba(195,154,69,0.10) 0%, transparent 70%);" aria-hidden="true"></span> <span class="relative inline-flex h-14 w-14 items-center justify-center border border-brand-gold/30 bg-brand-gold/5 text-brand-gold"> <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" width="26" height="26" aria-hidden="true"> <path d="M6.75 3v2.25M17.25 3v2.25M3 18.75V7.5a2.25 2.25 0 0 1 2.25-2.25h13.5A2.25 2.25 0 0 1 21 7.5v11.25m-18 0A2.25 2.25 0 0 0 5.25 21h13.5A2.25 2.25 0 0 0 21 18.75m-18 0v-7.5A2.25 2.25 0 0 1 5.25 9h13.5A2.25 2.25 0 0 1 21 11.25v7.5"></path> </svg> </span> <div class="relative max-w-md"> <p class="font-display text-xl font-medium leading-tight text-brand-forest">
Loading booking portal
</p> <p data-booking-status class="mt-1.5 font-sans text-[0.92rem] font-light leading-relaxed text-brand-forest/65">
Scroll down to load the reservation form, or call dispatch.
</p> </div> <div class="relative flex flex-col items-stretch gap-3 sm:flex-row sm:items-center"> <a href="tel:+12065959675" class="inline-flex min-h-[48px] items-center justify-center gap-2 border border-brand-forest/25 bg-white px-5 font-sans text-[0.74rem] font-semibold uppercase tracking-[0.18em] text-brand-forest outline-none transition-colors duration-200 hover:border-brand-gold focus-visible:ring-2 focus-visible:ring-brand-gold focus-visible:ring-offset-2 focus-visible:ring-offset-brand-champagne" aria-label="Call dispatch at (206) 595-9675"> <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" width="14" height="14" class="text-brand-gold" aria-hidden="true"> <path d="M2.25 6.75c0 8.284 6.716 15 15 15h2.25a2.25 2.25 0 0 0 2.25-2.25v-1.372c0-.516-.351-.966-.852-1.091l-4.423-1.106c-.44-.11-.902.055-1.173.417l-.97 1.293c-.282.376-.769.542-1.21.38a12.035 12.035 0 0 1-7.143-7.143c-.162-.441.004-.928.38-1.21l1.293-.97c.363-.271.527-.734.417-1.173L6.963 3.102a1.125 1.125 0 0 0-1.091-.852H4.5A2.25 2.25 0 0 0 2.25 4.5v2.25Z"></path> </svg>
Call (206) 595-9675
</a> <button type="button" data-booking-load-now class="inline-flex min-h-[48px] items-center justify-center gap-2 border border-brand-gold bg-brand-gold px-5 font-sans text-[0.74rem] font-semibold uppercase tracking-[0.18em] text-brand-forest outline-none transition-[background-color,box-shadow] duration-200 hover:bg-brand-gold-soft hover:shadow-[0_8px_20px_-8px_rgba(163,126,44,0.55)] focus-visible:ring-2 focus-visible:ring-brand-gold focus-visible:ring-offset-2 focus-visible:ring-offset-brand-champagne motion-reduce:transition-none">
Load booking now
<span aria-hidden="true">\u2192</span> </button> </div> </div> </div> </div> </section> <script>
  (() => {
    const widget = document.querySelector('[data-booking-widget]');
    if (!widget) return;

    const src = widget.getAttribute('data-src');
    if (!src) return;

    const placeholder = widget.querySelector('[data-booking-placeholder]');
    const loadBtn = widget.querySelector('[data-booking-load-now]');
    const status = widget.querySelector('[data-booking-status]');
    let mounted = false;

    function mount() {
      if (mounted) return;
      mounted = true;
      if (status) status.textContent = 'Almost ready\u2026';

      const iframe = document.createElement('iframe');
      iframe.src = src;
      iframe.title = 'Emerald City Limos booking portal';
      iframe.loading = 'lazy';
      iframe.setAttribute('referrerpolicy', 'no-referrer-when-downgrade');
      iframe.className = 'absolute inset-0 h-full w-full border-0';
      iframe.style.minHeight = widget.style.minHeight || '820px';

      iframe.addEventListener('load', () => {
        if (placeholder) placeholder.remove();
      });

      widget.appendChild(iframe);
    }

    // Click-to-load fallback button
    loadBtn?.addEventListener('click', mount);

    // Lazy-load via IntersectionObserver
    if ('IntersectionObserver' in window) {
      const io = new IntersectionObserver(
        (entries) => {
          entries.forEach((entry) => {
            if (entry.isIntersecting) {
              mount();
              io.disconnect();
            }
          });
        },
        { rootMargin: '200px' }
      );
      io.observe(widget);
    } else {
      // No IO support \u2014 mount immediately.
      mount();
    }
  })();
<\/script>`])), maybeRenderHead(), addAttribute(src, "data-src"), addAttribute(`min-height: ${minHeight};`, "style"));
}, "/home/josh/Documents/emerald-update/src/components/booking/BookingWidget.astro", void 0);

const $$BookNow = createComponent(($$result, $$props, $$slots) => {
  const PHONE_DISPLAY = "(206) 595-9675";
  const PHONE_HREF = "tel:+12065959675";
  const reassurance = [
    {
      title: "Flight tracking",
      description: "Live ADS-B monitoring on every airport pickup \u2014 staging reflows as your arrival shifts.",
      iconPath: "M6 12 3.269 3.125A59.769 59.769 0 0 1 21.485 12 59.768 59.768 0 0 1 3.27 20.875L5.999 12Zm0 0h7.5"
    },
    {
      title: "Flat-rate pricing",
      description: "No surge, no hidden tolls. Price locks at booking and matches the receipt.",
      iconPath: "M2.25 8.25h19.5M2.25 9h19.5m-16.5 5.25h6m-6 2.25h3m-3.75 3h15a2.25 2.25 0 0 0 2.25-2.25V6.75a2.25 2.25 0 0 0-2.25-2.25H4.5A2.25 2.25 0 0 0 2.25 6.75v10.5A2.25 2.25 0 0 0 4.5 19.5Z"
    },
    {
      title: "Licensed & insured",
      description: "Washington UTC permit on file. $1.5M in commercial liability on every ride.",
      iconPath: "M9 12.75 11.25 15 15 9.75m-3-7.036A11.959 11.959 0 0 1 3.598 6 11.99 11.99 0 0 0 3 9.749c0 5.592 3.824 10.29 9 11.623 5.176-1.332 9-6.03 9-11.622 0-1.31-.21-2.571-.598-3.751h-.152c-3.196 0-6.1-1.248-8.25-3.285Z"
    },
    {
      title: "Human dispatch",
      description: "Trouble with the form? Call (206) 595-9675 \u2014 a real dispatcher picks up 24/7.",
      iconPath: "M2.25 6.75c0 8.284 6.716 15 15 15h2.25a2.25 2.25 0 0 0 2.25-2.25v-1.372c0-.516-.351-.966-.852-1.091l-4.423-1.106c-.44-.11-.902.055-1.173.417l-.97 1.293c-.282.376-.769.542-1.21.38a12.035 12.035 0 0 1-7.143-7.143c-.162-.441.004-.928.38-1.21l1.293-.97c.363-.271.527-.734.417-1.173L6.963 3.102a1.125 1.125 0 0 0-1.091-.852H4.5A2.25 2.25 0 0 0 2.25 4.5v2.25Z"
    }
  ];
  return renderTemplate`${renderComponent($$result, "MainLayout", $$MainLayout, { "title": "Book a Ride | Emerald City Limos", "description": "Reserve any vehicle in our Seattle fleet in under two minutes sedan, SUV, Sprinter, or motorcoach. Flat-rate pricing, flight tracking, 24/7 dispatch.", "keywords": "book limo seattle, reserve car service seattle, seattle limo booking, emerald city limos booking", "canonical": "https://emeraldcitylimos.com/book-now" }, { "default": ($$result2) => renderTemplate`   ${renderComponent($$result2, "BookingWidget", $$BookingWidget, {})}  ${maybeRenderHead()}<section class="bg-brand-forest py-16 text-brand-champagne sm:py-10 lg:py-14" aria-labelledby="book-now-trust-heading"> <div class="mx-auto max-w-7xl px-6 sm:px-8 lg:px-12"> <div class="mb-12 text-center sm:mb-14"> <div class="mb-3 flex items-center justify-center gap-3"> <span class="h-px w-8 bg-brand-gold-soft" aria-hidden="true"></span> <p class="font-sans text-[10px] font-semibold uppercase tracking-[0.22em] text-brand-gold-soft">
What Every Booking Includes
</p> <span class="h-px w-8 bg-brand-gold-soft" aria-hidden="true"></span> </div> <h2 id="book-now-trust-heading" class="mx-auto max-w-2xl font-display font-light leading-[1.1] text-white" style="font-size: clamp(1.75rem, 3.4vw, 2.4rem); letter-spacing: -0.01em;">
The booking is fast.
<em class="italic text-brand-gold-soft">The standard is the same.</em> </h2> </div> <ul role="list" class="m-0 grid list-none grid-cols-1 gap-px overflow-hidden border border-white/8 bg-white/8 p-0 sm:grid-cols-2 lg:grid-cols-4"> ${reassurance.map((item) => renderTemplate`<li class="flex flex-col gap-3 bg-brand-forest px-5 py-8 sm:px-6 sm:py-10"> <span class="inline-flex h-10 w-10 items-center justify-center border border-brand-gold-soft/40 bg-brand-gold-soft/10 text-brand-gold-soft"> <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" width="18" height="18" aria-hidden="true"> <path${addAttribute(item.iconPath, "d")}></path> </svg> </span> <h3 class="font-display text-lg font-medium leading-snug text-white"> ${item.title} </h3> <p class="font-sans text-[0.82rem] leading-relaxed text-white/70"> ${item.description} </p> </li>`)} </ul> </div> </section>  <section class="relative overflow-hidden bg-brand-champagne py-16 sm:py-20" aria-labelledby="book-now-help-heading"> <div class="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-brand-gold/25 to-transparent" aria-hidden="true"></div> <div class="relative mx-auto max-w-3xl px-6 text-center sm:px-8 lg:px-12"> <div class="mb-3 flex items-center justify-center gap-3"> <span class="h-px w-8 bg-brand-gold" aria-hidden="true"></span> <p class="font-sans text-[10px] font-semibold uppercase tracking-[0.22em] text-brand-gold">
Need Help?
</p> <span class="h-px w-8 bg-brand-gold" aria-hidden="true"></span> </div> <h2 id="book-now-help-heading" class="mb-4 font-display font-light leading-[1.1] text-brand-forest" style="font-size: clamp(1.75rem, 3.4vw, 2.4rem); letter-spacing: -0.01em;">
Booking something
<em class="italic text-brand-gold">unusual?</em> </h2> <p class="mx-auto mb-8 max-w-xl font-sans text-[0.98rem] font-light leading-relaxed text-brand-forest/75">
Multi-vehicle weddings, corporate accounts, multi-day charters,
        or a route the widget doesn't price — talk to a dispatcher.
</p> <div class="flex flex-col items-stretch justify-center gap-3 sm:flex-row sm:items-center sm:gap-4" role="group" aria-label="Call or contact us"> <a${addAttribute(PHONE_HREF, "href")} class="inline-flex min-h-[52px] items-center justify-center gap-2 border border-brand-gold bg-brand-gold px-8 font-sans text-[11px] font-semibold uppercase tracking-[0.2em] text-brand-forest outline-none transition-[background-color,box-shadow] duration-200 hover:bg-brand-gold-soft hover:shadow-[0_12px_28px_-12px_rgba(163,126,44,0.5)] focus-visible:ring-2 focus-visible:ring-brand-gold focus-visible:ring-offset-2 focus-visible:ring-offset-brand-champagne motion-reduce:transition-none"${addAttribute(`Call dispatch at ${PHONE_DISPLAY}`, "aria-label")}> <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" width="14" height="14" aria-hidden="true"> <path d="M2.25 6.75c0 8.284 6.716 15 15 15h2.25a2.25 2.25 0 0 0 2.25-2.25v-1.372c0-.516-.351-.966-.852-1.091l-4.423-1.106c-.44-.11-.902.055-1.173.417l-.97 1.293c-.282.376-.769.542-1.21.38a12.035 12.035 0 0 1-7.143-7.143c-.162-.441.004-.928.38-1.21l1.293-.97c.363-.271.527-.734.417-1.173L6.963 3.102a1.125 1.125 0 0 0-1.091-.852H4.5A2.25 2.25 0 0 0 2.25 4.5v2.25Z"></path> </svg>
Call ${PHONE_DISPLAY} </a> <a href="/contact" class="inline-flex min-h-[52px] items-center justify-center gap-2 border border-brand-forest/25 bg-white px-8 font-sans text-[11px] font-semibold uppercase tracking-[0.2em] text-brand-forest outline-none transition-colors duration-200 hover:border-brand-gold focus-visible:ring-2 focus-visible:ring-brand-gold focus-visible:ring-offset-2 focus-visible:ring-offset-brand-champagne motion-reduce:transition-none">
Send a Message
<span aria-hidden="true">→</span> </a> </div> </div> </section> ` })}`;
}, "/home/josh/Documents/emerald-update/src/pages/book-now.astro", void 0);

const $$file = "/home/josh/Documents/emerald-update/src/pages/book-now.astro";
const $$url = "/book-now";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$BookNow,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };

import { c as createAstro, a as createComponent, m as maybeRenderHead, d as addAttribute, r as renderTemplate, b as renderComponent, u as unescapeHTML } from '../../chunks/astro/server_Cr-soRLN.mjs';
import 'piccolore';
import { $ as $$LocationLayout, l as locations, a as $$LocationCTA } from '../../chunks/locations_DdafASrP.mjs';
import { $ as $$PageHero, a as $$TrustStrip } from '../../chunks/TrustStrip_BQ1W8xK4.mjs';
import 'clsx';
import { f as fleet } from '../../chunks/fleet_MM31ydii.mjs';
import { $ as $$FleetCard } from '../../chunks/FleetCard_MXN8Ly--.mjs';
/* empty css                                     */
export { renderers } from '../../renderers.mjs';

const $$Astro$7 = createAstro("https://emeraldcitylimos.com");
const $$LocationIntro = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$7, $$props, $$slots);
  Astro2.self = $$LocationIntro;
  const { location } = Astro2.props;
  const PHONE_DISPLAY = "(206) 595-9675";
  const PHONE_HREF = "tel:+12065959675";
  const trustSignals = [
    {
      label: "WUTC Licensed",
      sub: "Washington UTC permit",
      iconPath: "M9 12.75 11.25 15 15 9.75M21 12c0 1.268-.63 2.39-1.593 3.068a3.745 3.745 0 0 1-1.043 3.296 3.745 3.745 0 0 1-3.296 1.043A3.745 3.745 0 0 1 12 21c-1.268 0-2.39-.63-3.068-1.593a3.746 3.746 0 0 1-3.296-1.043 3.745 3.745 0 0 1-1.043-3.296A3.745 3.745 0 0 1 3 12c0-1.268.63-2.39 1.593-3.068a3.745 3.745 0 0 1 1.043-3.296 3.746 3.746 0 0 1 3.296-1.043A3.746 3.746 0 0 1 12 3c1.268 0 2.39.63 3.068 1.593a3.746 3.746 0 0 1 3.296 1.043 3.746 3.746 0 0 1 1.043 3.296A3.745 3.745 0 0 1 21 12Z"
    },
    {
      label: "$1.5M Insured",
      sub: "Commercial liability",
      iconPath: "M9 12.75 11.25 15 15 9.75m-3-7.036A11.959 11.959 0 0 1 3.598 6 11.99 11.99 0 0 0 3 9.749c0 5.592 3.824 10.29 9 11.623 5.176-1.332 9-6.03 9-11.622 0-1.31-.21-2.571-.598-3.751h-.152c-3.196 0-6.1-1.248-8.25-3.285Z"
    },
    {
      label: "Flight Tracked",
      sub: "Live ADS-B monitoring",
      iconPath: "M6 12 3.269 3.125A59.769 59.769 0 0 1 21.485 12 59.768 59.768 0 0 1 3.27 20.875L5.999 12Zm0 0h7.5"
    },
    {
      label: "24/7 Dispatch",
      sub: "Same-day & 30-min recovery",
      iconPath: "M12 6v6h4.5m4.5 0a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z"
    }
  ];
  const presenceGroups = [
    {
      title: "Landmarks",
      items: location.nearbyLandmarks,
      iconPath: "M3 21V9.75m18 11.25V9.75M3 21h18M5.625 9.75h12.75M9 21v-3.375c0-.621.504-1.125 1.125-1.125h3.75c.621 0 1.125.504 1.125 1.125V21M12 3 2.25 9.75h19.5L12 3Z"
    },
    {
      title: "Business Districts",
      items: location.businessDistricts ?? [],
      iconPath: "M3.75 21h16.5M4.5 3h15M5.25 3v18m13.5-18v18M9 6.75h1.5m-1.5 3h1.5m-1.5 3h1.5m3-6H15m-1.5 3H15m-1.5 3H15M9 21v-3.375c0-.621.504-1.125 1.125-1.125h3.75c.621 0 1.125.504 1.125 1.125V21"
    },
    {
      title: "Hotels",
      items: location.hotels ?? [],
      iconPath: "M2.25 21h19.5m-18-18v18m10.5-18v18m6-13.5V21M6.75 6.75h.75m-.75 3h.75m-.75 3h.75m3-6h.75m-.75 3h.75m-.75 3h.75M6.75 21v-3.75A1.5 1.5 0 0 1 8.25 15.75h1.5a1.5 1.5 0 0 1 1.5 1.5V21M3 3h12M14.25 7.5h6.75A.75.75 0 0 1 21.75 8.25V21"
    },
    {
      title: "Event Venues",
      items: location.eventVenues ?? [],
      iconPath: "M9.813 15.904 9 18.75l-.813-2.846a4.5 4.5 0 0 0-3.09-3.09L2.25 12l2.846-.813a4.5 4.5 0 0 0 3.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 0 0 3.09 3.09L15.75 12l-2.846.813a4.5 4.5 0 0 0-3.09 3.09ZM18.259 8.715 18 9.75l-.259-1.035a3.375 3.375 0 0 0-2.455-2.456L14.25 6l1.036-.259a3.375 3.375 0 0 0 2.455-2.456L18 2.25l.259 1.035a3.375 3.375 0 0 0 2.456 2.456L21.75 6l-1.035.259a3.375 3.375 0 0 0-2.456 2.456ZM16.894 20.567 16.5 21.75l-.394-1.183a2.25 2.25 0 0 0-1.423-1.423L13.5 18.75l1.183-.394a2.25 2.25 0 0 0 1.423-1.423l.394-1.183.394 1.183a2.25 2.25 0 0 0 1.423 1.423l1.183.394-1.183.394a2.25 2.25 0 0 0-1.423 1.423Z"
    }
  ].filter((g) => g.items.length > 0);
  const totalCoverage = location.nearbyLandmarks.length + (location.businessDistricts?.length ?? 0) + (location.hotels?.length ?? 0) + (location.eventVenues?.length ?? 0);
  return renderTemplate`${maybeRenderHead()}<section class="relative overflow-hidden bg-brand-ivory py-16 sm:py-20 lg:py-24"${addAttribute(`intro-${location.slug}`, "aria-labelledby")}> <!-- Decorative gold hairlines (purely visual, hidden from AT) --> <div class="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-brand-gold/25 to-transparent" aria-hidden="true"></div> <div class="pointer-events-none absolute inset-x-0 bottom-0 h-px bg-gradient-to-r from-transparent via-brand-gold/20 to-transparent" aria-hidden="true"></div> <div class="relative mx-auto max-w-7xl px-6 sm:px-8 lg:px-12"> <div class="grid gap-12 lg:grid-cols-[1.1fr_1fr] lg:gap-16 xl:gap-20"> <!-- ── Copy + conversion column ─────────────────────────── --> <div class="flex flex-col"> <!-- Gold rule + eyebrow --> <div class="mb-4 flex items-center gap-3"> <span class="h-px w-8 bg-brand-gold" aria-hidden="true"></span> <p class="font-sans text-[10px] font-semibold uppercase tracking-[0.22em] text-brand-gold">
Trusted in ${location.name} </p> </div> <h2${addAttribute(`intro-${location.slug}`, "id")} class="mb-5 font-display font-light leading-[1.08] text-brand-green-deep" style="font-size: clamp(1.85rem, 3.4vw, 2.5rem); letter-spacing: -0.01em;">
Why ${location.name} riders choose
<em class="italic text-brand-gold">Emerald City Limos</em> </h2> <!-- Rating chip — visible E-E-A-T signal aligned with LimousineBusiness schema --> <div class="mb-6 inline-flex w-fit items-center gap-2.5 rounded-full border border-brand-gold/25 bg-white px-3.5 py-1.5 shadow-[0_1px_0_rgba(0,0,0,0.02)]"> <span class="flex items-center gap-0.5 text-brand-gold" aria-hidden="true"> ${Array.from({ length: 5 }).map(() => renderTemplate`<svg viewBox="0 0 20 20" fill="currentColor" class="h-3.5 w-3.5"> <path d="M9.05 2.927c.3-.921 1.603-.921 1.902 0l1.286 3.957a1 1 0 0 0 .95.69h4.162c.969 0 1.371 1.24.588 1.81l-3.367 2.446a1 1 0 0 0-.363 1.118l1.286 3.957c.3.92-.755 1.688-1.539 1.118l-3.367-2.446a1 1 0 0 0-1.176 0L5.046 18.02c-.783.57-1.838-.197-1.539-1.118l1.286-3.957a1 1 0 0 0-.363-1.118L1.063 9.383c-.783-.57-.38-1.81.588-1.81h4.162a1 1 0 0 0 .95-.69L8.05 2.927Z"></path> </svg>`)} </span> <p class="font-sans text-xs font-semibold tabular-nums text-brand-green-deep">
4.9
<span class="font-normal text-brand-green-deep/55">/ 5</span> </p> <span class="h-3 w-px bg-brand-green-deep/15" aria-hidden="true"></span> <p class="font-sans text-xs font-medium text-brand-green-deep/70">
127 verified rides
</p> </div> <!-- Lead value-prop paragraph --> <p class="font-sans text-[0.98rem] font-light leading-[1.8] text-brand-green-deep/85 sm:text-[1.02rem]"> ${location.localValueProp} </p> <!-- Trust-signal grid — replaces the second "wall of text" --> <ul class="mt-7 grid list-none grid-cols-2 gap-2.5 p-0 sm:grid-cols-4"${addAttribute(`Service guarantees in ${location.name}`, "aria-label")}> ${trustSignals.map((t) => renderTemplate`<li class="group flex flex-col gap-2 border border-brand-green-deep/8 bg-white p-3 transition-colors duration-200 hover:border-brand-gold/45 hover:bg-brand-gold/[0.03]"> <span class="inline-flex h-8 w-8 items-center justify-center rounded-sm bg-brand-gold/10 text-brand-gold transition-colors group-hover:bg-brand-gold group-hover:text-white"> <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" width="16" height="16" aria-hidden="true"> <path${addAttribute(t.iconPath, "d")}></path> </svg> </span> <p class="font-sans text-[0.78rem] font-semibold leading-tight text-brand-green-deep"> ${t.label} </p> <p class="font-sans text-[0.68rem] leading-snug text-brand-green-deep/55"> ${t.sub} </p> </li>`)} </ul> ${location.localValuePropExtended && renderTemplate`<p class="mt-7 border-l-2 border-brand-gold/30 pl-4 font-sans text-[0.92rem] font-light italic leading-[1.75] text-brand-green-deep/70"> ${location.localValuePropExtended} </p>`} <!-- Conversion cluster --> <div class="mt-8 flex flex-wrap items-center gap-3"> <a href="https://customer.moovs.app/a1-charters-1/new/info" target="_blank" rel="noopener noreferrer" class="inline-flex h-11 items-center bg-brand-gold px-5 font-sans text-[0.78rem] font-semibold uppercase tracking-[0.14em] text-brand-forest shadow-[0_2px_0_rgba(0,0,0,0.08)] outline-none transition-[background-color,box-shadow,transform] duration-200 hover:bg-brand-gold-soft hover:shadow-[0_6px_20px_-6px_rgba(163,126,44,0.55)] focus-visible:ring-2 focus-visible:ring-brand-gold focus-visible:ring-offset-2 focus-visible:ring-offset-brand-ivory motion-reduce:transition-none"${addAttribute(`Reserve chauffeur service in ${location.name}`, "aria-label")}>
Reserve a Ride
<svg viewBox="0 0 20 20" fill="currentColor" class="ml-2 h-3 w-3" aria-hidden="true"> <path fill-rule="evenodd" d="M3 10a.75.75 0 0 1 .75-.75h10.638L10.23 5.29a.75.75 0 1 1 1.04-1.08l5.5 5.25a.75.75 0 0 1 0 1.08l-5.5 5.25a.75.75 0 1 1-1.04-1.08l4.158-3.96H3.75A.75.75 0 0 1 3 10Z" clip-rule="evenodd"></path> </svg> </a> <a href="https://customer.moovs.app/a1-charters-1/new/info" target="_blank" rel="noopener noreferrer" class="inline-flex h-11 items-center border border-brand-green-deep/20 bg-white px-5 font-sans text-[0.78rem] font-semibold uppercase tracking-[0.14em] text-brand-green-deep outline-none transition-colors duration-200 hover:border-brand-gold/60 hover:text-brand-gold focus-visible:ring-2 focus-visible:ring-brand-gold focus-visible:ring-offset-2 focus-visible:ring-offset-brand-ivory motion-reduce:transition-none">
Get a Quote
</a> <a${addAttribute(PHONE_HREF, "href")} class="inline-flex h-11 items-center gap-2 px-2 font-sans text-sm font-semibold tabular-nums text-brand-green-deep outline-none transition-colors duration-200 hover:text-brand-gold focus-visible:ring-2 focus-visible:ring-brand-gold focus-visible:ring-offset-2 focus-visible:ring-offset-brand-ivory motion-reduce:transition-none"${addAttribute(`Call Emerald City Limos at ${PHONE_DISPLAY}, available 24 hours`, "aria-label")}> <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" class="h-4 w-4 text-brand-gold" aria-hidden="true"> <path d="M2.25 6.75c0 8.284 6.716 15 15 15h2.25a2.25 2.25 0 0 0 2.25-2.25v-1.372c0-.516-.351-.966-.852-1.091l-4.423-1.106c-.44-.11-.902.055-1.173.417l-.97 1.293c-.282.376-.769.542-1.21.38a12.035 12.035 0 0 1-7.143-7.143c-.162-.441.004-.928.38-1.21l1.293-.97c.363-.271.527-.734.417-1.173L6.963 3.102a1.125 1.125 0 0 0-1.091-.852H4.5A2.25 2.25 0 0 0 2.25 4.5v2.25Z"></path> </svg> ${PHONE_DISPLAY} </a> </div> </div> <!-- ── Presence panel ───────────────────────────────────── --> <aside class="relative"${addAttribute(`Areas, hotels and venues served in ${location.name}`, "aria-label")}> <div class="relative border border-brand-green-deep/10 bg-white shadow-[0_1px_0_rgba(0,0,0,0.02),0_24px_48px_-32px_rgba(10,35,24,0.18)]"> <!-- Panel header --> <div class="flex items-center justify-between gap-3 border-b border-brand-green-deep/8 px-5 py-4 sm:px-6"> <div class="flex items-center gap-3"> <span class="inline-flex h-9 w-9 items-center justify-center bg-brand-gold/10 text-brand-gold" aria-hidden="true"> <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" class="h-4 w-4"> <path d="M15 10.5a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z"></path> <path d="M19.5 10.5c0 7.142-7.5 11.25-7.5 11.25S4.5 17.642 4.5 10.5a7.5 7.5 0 1 1 15 0Z"></path> </svg> </span> <div> <p class="font-sans text-[10px] font-semibold uppercase tracking-[0.22em] text-brand-gold">
Where we serve
</p> <p class="font-display text-base font-medium leading-tight text-brand-green-deep"> ${location.name} &amp; surrounds
</p> </div> </div> <div class="hidden text-right sm:block"> <p class="font-sans text-[0.65rem] font-semibold uppercase tracking-[0.18em] text-brand-green-deep/50">
Coverage
</p> <p class="font-sans text-sm font-semibold tabular-nums text-brand-green-deep"> ${totalCoverage} <span class="font-normal text-brand-green-deep/55"> points</span> </p> </div> </div> <!-- Group list --> <ul role="list" class="m-0 list-none divide-y divide-brand-green-deep/8 p-0"> ${presenceGroups.map((group) => renderTemplate`<li class="px-5 py-5 sm:px-6"> <div class="mb-3 flex items-center justify-between gap-3"> <h3 class="flex items-center gap-2.5 font-sans text-[11px] font-semibold uppercase tracking-[0.2em] text-brand-green-deep"> <span class="inline-flex h-6 w-6 items-center justify-center text-brand-gold" aria-hidden="true"> <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="h-4 w-4"> <path${addAttribute(group.iconPath, "d")}></path> </svg> </span> ${group.title} </h3> <span class="inline-flex min-w-[1.5rem] items-center justify-center px-1.5 font-sans text-[10px] font-semibold tabular-nums text-brand-green-deep/55"> ${group.items.length} </span> </div> <ul role="list" class="m-0 flex list-none flex-wrap gap-1.5 p-0"> ${group.items.map((item) => renderTemplate`<li class="cursor-default border border-brand-green-deep/10 bg-brand-ivory/40 px-2.5 py-1 font-sans text-[0.72rem] font-medium leading-tight text-brand-green-deep/80 transition-colors duration-200 hover:border-brand-gold/45 hover:bg-brand-gold/[0.05] hover:text-brand-green-deep"> ${item} </li>`)} </ul> </li>`)} ${location.zipCodes.length > 0 && renderTemplate`<li class="bg-brand-green-deep/[0.02] px-5 py-5 sm:px-6"> <div class="mb-3 flex items-center justify-between gap-3"> <h3 class="flex items-center gap-2.5 font-sans text-[11px] font-semibold uppercase tracking-[0.2em] text-brand-green-deep"> <span class="inline-flex h-6 w-6 items-center justify-center text-brand-gold" aria-hidden="true"> <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="h-4 w-4"> <path d="M4.5 9.75 12 3l7.5 6.75M5.25 9.75v9a1.5 1.5 0 0 0 1.5 1.5h10.5a1.5 1.5 0 0 0 1.5-1.5v-9"></path> </svg> </span>
ZIP Codes Served
</h3> <span class="inline-flex min-w-[1.5rem] items-center justify-center px-1.5 font-sans text-[10px] font-semibold tabular-nums text-brand-green-deep/55"> ${location.zipCodes.length} </span> </div> <ul role="list" class="m-0 grid list-none grid-cols-3 gap-1.5 p-0 sm:grid-cols-4 md:grid-cols-5"> ${location.zipCodes.map((zip) => renderTemplate`<li class="cursor-default border border-brand-green-deep/10 bg-white px-2 py-1 text-center font-sans text-[0.72rem] font-semibold tabular-nums leading-tight tracking-[0.04em] text-brand-green-deep/75 transition-colors duration-200 hover:border-brand-gold/45 hover:text-brand-green-deep"> ${zip} </li>`)} </ul> </li>`} </ul> </div> <!-- Footnote micro-CTA --> <p class="mt-3 px-1 font-sans text-[0.72rem] leading-relaxed text-brand-green-deep/55">
Outside this list? We routinely serve adjacent neighborhoods —
<a href="https://customer.moovs.app/a1-charters-1/new/info" target="_blank" rel="noopener noreferrer" class="font-semibold text-brand-gold underline-offset-2 outline-none transition-colors hover:text-brand-gold-soft hover:underline focus-visible:underline focus-visible:ring-2 focus-visible:ring-brand-gold focus-visible:ring-offset-2 focus-visible:ring-offset-brand-ivory">
ask for a custom quote
</a>.
</p> </aside> </div> </div> </section>`;
}, "/home/josh/Documents/emerald-update/src/components/locations/LocationIntro.astro", void 0);

const locationServices = [
  {
    id: "airport-transfers",
    title: "Airport Transfers",
    description: "Flight-tracked transfers to SEA-TAC, Boeing Field, and Paine Field with curbside or baggage-claim meet-and-greet.",
    href: "/airport-transfers",
    iconPath: "M3.75 9h16.5m-16.5 6.75h16.5M2.25 12c0-2.485 4.367-4.5 9.75-4.5s9.75 2.015 9.75 4.5-4.367 4.5-9.75 4.5S2.25 14.485 2.25 12z"
  },
  {
    id: "corporate-transportation",
    title: "Corporate Transportation",
    description: "Dedicated chauffeur accounts with consolidated billing, dispatcher-direct lines, and recurring named-driver assignments.",
    href: "/services#corporate-transportation",
    iconPath: "M3.75 21h16.5M4.5 3h15M5.25 3v18m13.5-18v18M9 6.75h1.5m-1.5 3h1.5m-1.5 3h1.5m3-6H15m-1.5 3H15m-1.5 3H15M9 21v-3.375c0-.621.504-1.125 1.125-1.125h3.75c.621 0 1.125.504 1.125 1.125V21"
  },
  {
    id: "hourly-chauffeur",
    title: "Hourly Chauffeur",
    description: "Three-hour minimum hourly bookings for back-to-back meetings, full-day client visits, and roadshows across the metro.",
    href: "/services#hourly-chauffeur",
    iconPath: "M12 6v6h4.5m4.5 0a9 9 0 11-18 0 9 9 0 0118 0z"
  },
  {
    id: "events-weddings",
    title: "Events & Weddings",
    description: "Stretch limousines, Cadillac Escalade ESVs, and Mercedes Sprinters for weddings, galas, and milestone celebrations.",
    href: "/services#events-weddings",
    iconPath: "M21 8.25c0-2.485-2.099-4.5-4.688-4.5-1.935 0-3.597 1.126-4.312 2.733-.715-1.607-2.377-2.733-4.313-2.733C5.1 3.75 3 5.765 3 8.25c0 7.22 9 12 9 12s9-4.78 9-12z"
  },
  {
    id: "point-to-point",
    title: "Point-to-Point Transfers",
    description: "Flat-rate, on-demand rides across King, Pierce, and Snohomish counties — no surge pricing, no hidden tolls.",
    href: "/services#point-to-point",
    iconPath: "M15 10.5a3 3 0 11-6 0 3 3 0 016 0z M19.5 10.5c0 7.142-7.5 11.25-7.5 11.25S4.5 17.642 4.5 10.5a7.5 7.5 0 1115 0z"
  }
];

const $$Astro$6 = createAstro("https://emeraldcitylimos.com");
const $$LocationServices = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$6, $$props, $$slots);
  Astro2.self = $$LocationServices;
  const { location } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<section class="bg-white py-16 sm:py-20 lg:py-24"${addAttribute(`services-${location.slug}`, "aria-labelledby")}> <div class="mx-auto max-w-7xl px-6 sm:px-8 lg:px-12"> <!-- Section heading --> <div class="mb-12 text-center sm:mb-16"> <p class="mb-3 font-sans text-[11px] font-semibold uppercase tracking-[0.22em] text-brand-gold">
Services
</p> <h2${addAttribute(`services-${location.slug}`, "id")} class="font-display font-light leading-[1.1] text-brand-forest" style="font-size: clamp(1.75rem, 3.5vw, 2.5rem);">
Chauffeur services available in
<span class="italic text-brand-gold">${location.name}</span> </h2> </div> <!-- Cards grid --> <ul class="m-0 grid list-none gap-6 p-0 sm:grid-cols-2 lg:grid-cols-3"> ${locationServices.map((svc) => renderTemplate`<li> <a${addAttribute(svc.href, "href")} class="ecl-focusable group flex h-full flex-col gap-3 border-l-2 border-brand-gold/60 bg-white p-6 ring-1 ring-brand-forest/10 transition-[border-color,box-shadow] duration-300 hover:border-brand-gold hover:shadow-[0_8px_28px_-12px_rgba(10,35,24,0.18)] sm:p-7"${addAttribute(`${svc.title} in ${location.name} \u2014 learn more`, "aria-label")}> <div class="flex h-12 w-12 items-center justify-center rounded-sm bg-brand-forest text-brand-gold-soft"> <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" width="22" height="22" aria-hidden="true"> <path stroke-linecap="round" stroke-linejoin="round"${addAttribute(svc.iconPath, "d")}></path> </svg> </div> <h3 class="font-display text-xl font-medium leading-snug text-brand-forest transition-colors duration-300 group-hover:text-brand-gold"> ${svc.title} </h3> <p class="font-sans text-sm leading-relaxed text-brand-forest/75"> ${svc.description} </p> <span class="mt-auto inline-flex items-center gap-1.5 font-sans text-[11px] font-semibold uppercase tracking-[0.2em] text-brand-gold">
Learn more
<span aria-hidden="true" class="transition-transform duration-300 group-hover:translate-x-0.5">→</span> </span> </a> </li>`)} </ul> </div> </section>`;
}, "/home/josh/Documents/emerald-update/src/components/locations/LocationServices.astro", void 0);

const $$Astro$5 = createAstro("https://emeraldcitylimos.com");
const $$LocationFleet = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$5, $$props, $$slots);
  Astro2.self = $$LocationFleet;
  const { location } = Astro2.props;
  const CATEGORY_ORDER = ["Luxury Sedan", "Luxury SUV", "Executive Van", "Limousine"];
  const previewVehicles = CATEGORY_ORDER.map(
    (category) => fleet.find((v) => v.category === category)
  ).filter((v) => Boolean(v));
  return renderTemplate`${maybeRenderHead()}<section class="bg-brand-champagne py-16 sm:py-20 lg:py-24"${addAttribute(`fleet-${location.slug}`, "aria-labelledby")}> <div class="mx-auto max-w-7xl px-6 sm:px-8 lg:px-12"> <div class="mb-12 flex flex-col items-start justify-between gap-4 sm:mb-16 sm:flex-row sm:items-end"> <div> <p class="mb-3 font-sans text-[11px] font-semibold uppercase tracking-[0.22em] text-brand-gold">
The Fleet
</p> <h2${addAttribute(`fleet-${location.slug}`, "id")} class="font-display font-light leading-[1.1] text-brand-forest" style="font-size: clamp(1.75rem, 3.5vw, 2.5rem);">
Vehicles dispatched to
<span class="italic text-brand-gold">${location.name}</span> </h2> </div> <a href="/fleet" class="ecl-focusable inline-flex items-center gap-1.5 font-sans text-[11px] font-semibold uppercase tracking-[0.2em] text-brand-gold hover:text-brand-forest">
View full fleet
<span aria-hidden="true">→</span> </a> </div> <ul class="m-0 grid list-none gap-6 p-0 sm:grid-cols-2 lg:grid-cols-4"> ${previewVehicles.map((vehicle) => renderTemplate`<li class="h-full"> ${renderComponent($$result, "FleetCard", $$FleetCard, { "vehicle": vehicle })} </li>`)} </ul> </div> </section>`;
}, "/home/josh/Documents/emerald-update/src/components/locations/LocationFleet.astro", void 0);

const $$Astro$4 = createAstro("https://emeraldcitylimos.com");
const $$LocationWhyChoose = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$4, $$props, $$slots);
  Astro2.self = $$LocationWhyChoose;
  const { location } = Astro2.props;
  const reasons = [
    {
      title: "On-Time Guarantee",
      description: "Chauffeurs depart staging early and route around live traffic \u2014 if we are late, the ride is on us.",
      iconPath: "M12 6v6h4.5m4.5 0a9 9 0 11-18 0 9 9 0 0118 0z"
    },
    {
      title: "Live Flight Tracking",
      description: "Every airport pickup tracks ADS-B in real time. We know your wheels-down before you do.",
      iconPath: "M6 12 3.269 3.125A59.769 59.769 0 0121.485 12 59.768 59.768 0 013.27 20.875L5.999 12zm0 0h7.5"
    },
    {
      title: "Professional Chauffeurs",
      description: "Background-checked, business-attired, and trained on every loading-zone, FBO ramp, and hotel circle in the metro.",
      iconPath: "M15.75 6a3.75 3.75 0 11-7.5 0 3.75 3.75 0 017.5 0zM4.501 20.118a7.5 7.5 0 0114.998 0A17.933 17.933 0 0112 21.75c-2.676 0-5.216-.584-7.499-1.632z"
    },
    {
      title: "Luxury Fleet",
      description: "Mercedes S-Class, Cadillac Escalade ESV, Lincoln Navigator L, Mercedes Sprinters, and stretch limousines.",
      iconPath: "M8.25 18.75a1.5 1.5 0 01-3 0m3 0a1.5 1.5 0 00-3 0m3 0h6m-9 0H3.375a1.125 1.125 0 01-1.125-1.125V14.25m17.25 4.5a1.5 1.5 0 01-3 0m3 0a1.5 1.5 0 00-3 0m3 0h1.125c.621 0 1.129-.504 1.09-1.124a17.902 17.902 0 00-3.213-9.193 2.256 2.256 0 00-1.586-.67H4.25A2.25 2.25 0 002 7.498v6.75z"
    },
    {
      title: "Transparent Pricing",
      description: "All-inclusive flat rates \u2014 no surge, no hidden tolls, no surprise gratuity line items at drop-off.",
      iconPath: "M2.25 18.75a60.07 60.07 0 0115.797 2.101c.727.198 1.453-.342 1.453-1.096V18.75M3.75 4.5v.75A.75.75 0 013 6h-.75m0 0v-.375c0-.621.504-1.125 1.125-1.125H20.25M2.25 6v9m18-10.5v.75c0 .414.336.75.75.75h.75m-1.5-1.5h.375c.621 0 1.125.504 1.125 1.125v9.75c0 .621-.504 1.125-1.125 1.125h-.375m1.5-1.5H21a.75.75 0 00-.75.75v.75m0 0H3.75m0 0h-.375a1.125 1.125 0 01-1.125-1.125V15m1.5 1.5v-.75A.75.75 0 003 15h-.75M15 10.5a3 3 0 11-6 0 3 3 0 016 0zm3 0h.008v.008H18V10.5zm-12 0h.008v.008H6V10.5z"
    }
  ];
  return renderTemplate`${maybeRenderHead()}<section class="bg-brand-forest py-16 text-white sm:py-20 lg:py-24"${addAttribute(`why-${location.slug}`, "aria-labelledby")}> <div class="mx-auto max-w-7xl px-6 sm:px-8 lg:px-12"> <div class="mb-12 text-center sm:mb-16"> <p class="mb-3 font-sans text-[11px] font-semibold uppercase tracking-[0.22em] text-brand-gold-soft">
Why riders return
</p> <h2${addAttribute(`why-${location.slug}`, "id")} class="font-display font-light leading-[1.1] text-white" style="font-size: clamp(1.75rem, 3.5vw, 2.5rem);">
Built for ${location.name}'s most demanding rides
</h2> </div> <ul class="m-0 grid list-none gap-6 p-0 sm:grid-cols-2 lg:grid-cols-5"> ${reasons.map((r) => renderTemplate`<li class="flex flex-col gap-3 border-l border-brand-gold/40 pl-5"> <div class="flex h-11 w-11 items-center justify-center rounded-sm bg-white/5 ring-1 ring-brand-gold/40"> <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" width="20" height="20" class="text-brand-gold-soft" aria-hidden="true"> <path stroke-linecap="round" stroke-linejoin="round"${addAttribute(r.iconPath, "d")}></path> </svg> </div> <h3 class="font-display text-lg font-medium leading-snug text-white">${r.title}</h3> <p class="font-sans text-sm leading-relaxed text-white/70">${r.description}</p> </li>`)} </ul> </div> </section>`;
}, "/home/josh/Documents/emerald-update/src/components/locations/LocationWhyChoose.astro", void 0);

const $$Astro$3 = createAstro("https://emeraldcitylimos.com");
const $$LocationRoutes = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$3, $$props, $$slots);
  Astro2.self = $$LocationRoutes;
  const { location } = Astro2.props;
  const routes = location.popularRoutes ?? [];
  return renderTemplate`${routes.length > 0 && renderTemplate`${maybeRenderHead()}<section class="bg-white py-16 sm:py-20 lg:py-24"${addAttribute(`routes-${location.slug}`, "aria-labelledby")}><div class="mx-auto max-w-5xl px-6 sm:px-8 lg:px-12"><div class="mb-12 text-center sm:mb-16"><p class="mb-3 font-sans text-[11px] font-semibold uppercase tracking-[0.22em] text-brand-gold">
Popular Routes
</p><h2${addAttribute(`routes-${location.slug}`, "id")} class="font-display font-light leading-[1.1] text-brand-forest" style="font-size: clamp(1.75rem, 3.5vw, 2.5rem);">
Most-booked rides from
<span class="italic text-brand-gold">${location.name}</span></h2></div><ul class="m-0 list-none divide-y divide-brand-forest/10 border-y border-brand-forest/10 p-0">${routes.map((route) => {
    const from = route.from ?? location.name;
    return renderTemplate`<li class="grid items-center gap-3 py-4 sm:grid-cols-[1.4fr_auto_auto_auto] sm:gap-6 sm:py-5"><div class="font-display text-lg text-brand-forest"><span>${from}</span><span class="mx-2 text-brand-gold" aria-hidden="true">→</span><span>${route.to}</span></div><div class="font-sans text-xs uppercase tracking-[0.18em] text-brand-forest/60 tabular-nums">${route.driveTime}</div><div class="font-sans text-xs uppercase tracking-[0.18em] text-brand-forest/60 tabular-nums">${route.distanceMiles} mi
</div><div class="font-sans text-sm font-semibold tabular-nums text-brand-forest">${route.startingPriceUSD ? `from $${route.startingPriceUSD}` : "On request"}</div></li>`;
  })}</ul><p class="mt-6 text-center font-sans text-xs text-brand-forest/60">
Flat-rate pricing. All-inclusive — no surge, no hidden tolls.
</p></div></section>`}`;
}, "/home/josh/Documents/emerald-update/src/components/locations/LocationRoutes.astro", void 0);

const $$Astro$2 = createAstro("https://emeraldcitylimos.com");
const $$LocationFAQ = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$2, $$props, $$slots);
  Astro2.self = $$LocationFAQ;
  const { location } = Astro2.props;
  const faqs = location.faqs ?? [];
  return renderTemplate`${faqs.length > 0 && renderTemplate`${maybeRenderHead()}<section class="bg-white py-16 sm:py-20 lg:py-24"${addAttribute(`faq-${location.slug}`, "aria-labelledby")} data-astro-cid-clwm4emr><div class="mx-auto max-w-3xl px-6 sm:px-8 lg:px-12" data-astro-cid-clwm4emr><div class="mb-12 text-center sm:mb-16" data-astro-cid-clwm4emr><p class="mb-3 font-sans text-[11px] font-semibold uppercase tracking-[0.22em] text-brand-gold" data-astro-cid-clwm4emr>
Frequently Asked
</p><h2${addAttribute(`faq-${location.slug}`, "id")} class="font-display font-light leading-[1.1] text-brand-forest" style="font-size: clamp(1.75rem, 3.5vw, 2.5rem);" data-astro-cid-clwm4emr>${location.name} chauffeur service questions
</h2></div><ul class="m-0 list-none divide-y divide-brand-forest/10 border-y border-brand-forest/10 p-0" data-astro-cid-clwm4emr>${faqs.map((faq, i) => renderTemplate`<li data-astro-cid-clwm4emr><details class="group ecl-faq-item"${addAttribute(`faq-${location.slug}`, "name")}${addAttribute(i === 0, "open")} data-astro-cid-clwm4emr><summary class="ecl-focusable flex cursor-pointer list-none items-center justify-between gap-4 py-5 font-display text-lg text-brand-forest hover:text-brand-gold" data-astro-cid-clwm4emr><span data-astro-cid-clwm4emr>${faq.question}</span><span class="ecl-faq-icon flex h-6 w-6 flex-shrink-0 items-center justify-center text-brand-gold transition-transform duration-300 group-open:rotate-180" aria-hidden="true" data-astro-cid-clwm4emr><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" width="18" height="18" data-astro-cid-clwm4emr><path stroke-linecap="round" stroke-linejoin="round" d="M19.5 8.25l-7.5 7.5-7.5-7.5" data-astro-cid-clwm4emr></path></svg></span></summary><p class="pb-5 font-sans text-base leading-relaxed text-brand-forest/80" data-astro-cid-clwm4emr>${faq.answer}</p></details></li>`)}</ul></div></section>`}`;
}, "/home/josh/Documents/emerald-update/src/components/locations/LocationFAQ.astro", void 0);

var __freeze = Object.freeze;
var __defProp = Object.defineProperty;
var __template = (cooked, raw) => __freeze(__defProp(cooked, "raw", { value: __freeze(cooked.slice()) }));
var _a;
const $$Astro$1 = createAstro("https://emeraldcitylimos.com");
const $$LocationSchema = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$1, $$props, $$slots);
  Astro2.self = $$LocationSchema;
  const { location } = Astro2.props;
  const SITE_URL = "https://emeraldcitylimos.com";
  const PAGE_URL = `${SITE_URL}/locations/${location.slug}`;
  const PHONE = "+1-206-595-9675";
  const businessNode = {
    "@type": "LimousineService",
    "@id": `${PAGE_URL}#business`,
    name: `Emerald City Limos \u2014 ${location.name}`,
    url: PAGE_URL,
    telephone: PHONE,
    email: "client@emeraldcitylimos.com",
    image: new URL(location.heroImage.src, SITE_URL).href,
    priceRange: "$$",
    address: {
      "@type": "PostalAddress",
      addressLocality: location.name,
      addressRegion: "WA",
      addressCountry: "US"
    },
    geo: {
      "@type": "GeoCoordinates",
      latitude: location.coordinates.lat,
      longitude: location.coordinates.lng
    },
    areaServed: {
      "@type": "City",
      name: location.name,
      containedInPlace: { "@type": "AdministrativeArea", name: location.county }
    },
    openingHoursSpecification: {
      "@type": "OpeningHoursSpecification",
      dayOfWeek: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"],
      opens: "00:00",
      closes: "23:59"
    },
    aggregateRating: {
      "@type": "AggregateRating",
      ratingValue: "4.9",
      reviewCount: "127",
      bestRating: "5",
      worstRating: "1"
    }
  };
  const serviceNodes = locationServices.map((svc) => ({
    "@type": "Service",
    "@id": `${PAGE_URL}#service-${svc.id}`,
    name: `${svc.title} in ${location.name}`,
    description: svc.description,
    provider: { "@id": `${PAGE_URL}#business` },
    areaServed: { "@type": "City", name: location.name },
    serviceType: svc.title,
    url: `${SITE_URL}${svc.href}`
  }));
  const faqNode = location.faqs && location.faqs.length > 0 ? {
    "@type": "FAQPage",
    "@id": `${PAGE_URL}#faq`,
    mainEntity: location.faqs.map((faq) => ({
      "@type": "Question",
      name: faq.question,
      acceptedAnswer: { "@type": "Answer", text: faq.answer }
    }))
  } : null;
  const breadcrumbNode = {
    "@type": "BreadcrumbList",
    "@id": `${PAGE_URL}#breadcrumb`,
    itemListElement: [
      { "@type": "ListItem", position: 1, name: "Home", item: SITE_URL },
      { "@type": "ListItem", position: 2, name: "Service Areas", item: `${SITE_URL}/locations` },
      { "@type": "ListItem", position: 3, name: location.name, item: PAGE_URL }
    ]
  };
  const graph = [
    businessNode,
    ...serviceNodes,
    breadcrumbNode,
    ...faqNode ? [faqNode] : []
  ];
  const payload = {
    "@context": "https://schema.org",
    "@graph": graph
  };
  return renderTemplate(_a || (_a = __template(['<script type="application/ld+json">', "<\/script>"])), unescapeHTML(JSON.stringify(payload)));
}, "/home/josh/Documents/emerald-update/src/components/locations/LocationSchema.astro", void 0);

const $$Astro = createAstro("https://emeraldcitylimos.com");
async function getStaticPaths() {
  return locations.map((loc) => ({
    params: { slug: loc.slug },
    props: { location: loc }
  }));
}
const $$slug = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$slug;
  const { location } = Astro2.props;
  const canonical = `https://emeraldcitylimos.com/locations/${location.slug}`;
  const ogImage = location.meta.ogImage ?? location.heroImage.src;
  return renderTemplate`${renderComponent($$result, "LocationLayout", $$LocationLayout, { "title": location.meta.title, "description": location.meta.description, "keywords": location.meta.keywords.join(", "), "ogImage": ogImage, "canonical": canonical }, { "default": ($$result2) => renderTemplate` ${renderComponent($$result2, "PageHero", $$PageHero, { "eyebrow": location.county, "headline": "Luxury Chauffeur Service", "headlineAccent": location.name, "supporting": location.heroSupporting, "image": { src: location.heroImage, alt: location.heroImageAlt }, "id": `hero-${location.slug}`, "size": "page", "noAnim": true, "breadcrumbs": [{ label: "Home", href: "/" }, { label: "Locations", href: "/locations" }, { label: location.name }] })} ${renderComponent($$result2, "TrustStrip", $$TrustStrip, {})} ${renderComponent($$result2, "LocationIntro", $$LocationIntro, { "location": location })} ${renderComponent($$result2, "LocationServices", $$LocationServices, { "location": location })} ${renderComponent($$result2, "LocationFleet", $$LocationFleet, { "location": location })} ${renderComponent($$result2, "LocationWhyChoose", $$LocationWhyChoose, { "location": location })} ${renderComponent($$result2, "LocationRoutes", $$LocationRoutes, { "location": location })}  ${renderComponent($$result2, "LocationFAQ", $$LocationFAQ, { "location": location })} ${renderComponent($$result2, "LocationCTA", $$LocationCTA, { "location": location })} ${renderComponent($$result2, "LocationSchema", $$LocationSchema, { "location": location })} ` })}`;
}, "/home/josh/Documents/emerald-update/src/pages/locations/[slug].astro", void 0);

const $$file = "/home/josh/Documents/emerald-update/src/pages/locations/[slug].astro";
const $$url = "/locations/[slug]";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$slug,
  file: $$file,
  getStaticPaths,
  url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };

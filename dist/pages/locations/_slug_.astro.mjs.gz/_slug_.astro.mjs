import { b as createAstro, c as createComponent, m as maybeRenderHead, d as addAttribute, r as renderComponent, F as Fragment, a as renderTemplate, u as unescapeHTML } from '../../chunks/astro/server_DL3Tye_C.mjs';
import 'piccolore';
import { $ as $$LocationLayout, l as locations, a as $$LocationCTA } from '../../chunks/locations_CSbeZWl-.mjs';
import { $ as $$PageHero, a as $$TrustStrip } from '../../chunks/TrustStrip_B_sgXsCD.mjs';
import 'clsx';
import { f as fleet, $ as $$FleetCard } from '../../chunks/FleetCard_CpyszYd9.mjs';
/* empty css                                     */
export { renderers } from '../../renderers.mjs';

const $$Astro$7 = createAstro("https://emeraldcitylimos.com");
const $$LocationIntro = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$7, $$props, $$slots);
  Astro2.self = $$LocationIntro;
  const { location } = Astro2.props;
  const chipGroups = [
    { title: "Landmarks We Serve", items: location.nearbyLandmarks },
    { title: "Business Districts", items: location.businessDistricts ?? [] },
    { title: "Hotels", items: location.hotels ?? [] },
    { title: "Event Venues", items: location.eventVenues ?? [] }
  ].filter((g) => g.items.length > 0);
  return renderTemplate`${maybeRenderHead()}<section class="relative bg-brand-ivory py-16 sm:py-20 lg:py-24 overflow-hidden"${addAttribute(`intro-${location.slug}`, "aria-labelledby")}> <!-- Decorative background rule --> <div class="pointer-events-none absolute inset-0 flex items-center justify-center" aria-hidden="true"> <div class="h-full w-px bg-gradient-to-b from-transparent via-brand-gold/10 to-transparent"></div> </div> <div class="relative mx-auto max-w-7xl px-6 sm:px-8 lg:px-12"> <div class="grid gap-14 lg:grid-cols-[1.25fr_1fr] lg:gap-20"> <!-- ── Copy column ──────────────────────────────────────── --> <div> <!-- Gold rule --> <div class="mb-5 h-px w-9 bg-brand-gold" aria-hidden="true"></div> <p class="mb-4 font-sans text-[10px] font-semibold uppercase tracking-[0.22em] text-brand-gold">
Trusted in ${location.name} </p> <h2${addAttribute(`intro-${location.slug}`, "id")} class="mb-7 font-display font-light leading-[1.08] text-brand-green-deep" style="font-size: clamp(1.85rem, 3.4vw, 2.5rem); letter-spacing: -0.01em;">
Why ${location.name} riders choose
<em class="not-italic italic text-brand-gold">
Emerald City Limos
</em> </h2> <p class="font-sans text-base font-light leading-[1.9] text-brand-green-deep/80 sm:text-[1.05rem]"> ${location.localValueProp} </p> ${location.localValuePropExtended && renderTemplate`${renderComponent($$result, "Fragment", Fragment, {}, { "default": ($$result2) => renderTemplate`  <div class="my-6 flex items-center gap-4" aria-hidden="true"> <div class="h-px flex-1 bg-brand-gold/15"></div> <div class="h-1 w-1 rounded-full bg-brand-gold/40"></div> <div class="h-px flex-1 bg-brand-gold/15"></div> </div> <p class="font-sans text-base font-light leading-[1.9] text-brand-green-deep/80 sm:text-[1.05rem]"> ${location.localValuePropExtended} </p> ` })}`} </div> <!-- ── Chip groups column ────────────────────────────────── --> <aside class="flex flex-col gap-7 lg:pt-1"${addAttribute(`Areas we serve in ${location.name}`, "aria-label")}> ${chipGroups.map((group) => renderTemplate`<div> <!-- Group label with trailing hairline --> <h3 class="mb-3 flex items-center gap-3 font-sans text-[10px] font-semibold uppercase tracking-[0.22em] text-brand-gold"> ${group.title} <span class="flex-1 border-t border-brand-gold/20" aria-hidden="true"></span> </h3> <ul class="flex list-none flex-wrap gap-2 p-0 m-0"> ${group.items.map((item) => renderTemplate`<li class="group/chip cursor-default border border-brand-green-deep/10 bg-white px-3 py-[5px] font-sans text-[11px] font-normal leading-none text-brand-green-deep/70 transition-colors duration-200 hover:border-brand-gold/40 hover:bg-brand-gold/[0.04] hover:text-brand-green-deep"> ${item} </li>`)} </ul> </div>`)} ${location.zipCodes.length > 0 && renderTemplate`<div> <h3 class="mb-3 flex items-center gap-3 font-sans text-[10px] font-semibold uppercase tracking-[0.22em] text-brand-gold">
ZIP Codes Served
<span class="flex-1 border-t border-brand-gold/20" aria-hidden="true"></span> </h3> <ul class="flex list-none flex-wrap gap-2 p-0 m-0"> ${location.zipCodes.map((zip) => renderTemplate`<li class="cursor-default border border-brand-green-deep/8 bg-brand-green-deep/[0.03] px-3 py-[5px] font-sans text-[11px] font-normal tabular-nums leading-none text-brand-green-deep/55 tracking-[0.05em] transition-colors duration-200 hover:border-brand-gold/30 hover:text-brand-green-deep/75"> ${zip} </li>`)} </ul> </div>`} </aside> </div> </div> <!-- Bottom decorative rule --> <div class="pointer-events-none absolute bottom-0 left-0 right-0 h-px" style="background: linear-gradient(to right, transparent, rgba(163,126,44,0.2), transparent);" aria-hidden="true"></div> </section>`;
}, "/home/josh/Documents/emerald-update/src/components/locations/LocationIntro.astro", void 0);

const locationServices = [
  {
    id: "airport-transfers",
    title: "Airport Transfers",
    description: "Flight-tracked transfers to SEA-TAC, Boeing Field, and Paine Field with curbside or baggage-claim meet-and-greet.",
    href: "/airport-transfers",
    iconPath: "M3.75 9h16.5m-16.5 6.75h16.5M2.25 12c0-2.485 4.367-4.5 9.75-4.5s9.75 2.015 9.75 4.5-4.367 4.5-9.75 4.5S2.25 14.485 2.25 12z"
  },
  {
    id: "corporate-transportation",
    title: "Corporate Transportation",
    description: "Dedicated chauffeur accounts with consolidated billing, dispatcher-direct lines, and recurring named-driver assignments.",
    href: "/services#corporate-transportation",
    iconPath: "M3.75 21h16.5M4.5 3h15M5.25 3v18m13.5-18v18M9 6.75h1.5m-1.5 3h1.5m-1.5 3h1.5m3-6H15m-1.5 3H15m-1.5 3H15M9 21v-3.375c0-.621.504-1.125 1.125-1.125h3.75c.621 0 1.125.504 1.125 1.125V21"
  },
  {
    id: "hourly-chauffeur",
    title: "Hourly Chauffeur",
    description: "Three-hour minimum hourly bookings for back-to-back meetings, full-day client visits, and roadshows across the metro.",
    href: "/services#hourly-chauffeur",
    iconPath: "M12 6v6h4.5m4.5 0a9 9 0 11-18 0 9 9 0 0118 0z"
  },
  {
    id: "events-weddings",
    title: "Events & Weddings",
    description: "Stretch limousines, Cadillac Escalade ESVs, and Mercedes Sprinters for weddings, galas, and milestone celebrations.",
    href: "/services#events-weddings",
    iconPath: "M21 8.25c0-2.485-2.099-4.5-4.688-4.5-1.935 0-3.597 1.126-4.312 2.733-.715-1.607-2.377-2.733-4.313-2.733C5.1 3.75 3 5.765 3 8.25c0 7.22 9 12 9 12s9-4.78 9-12z"
  },
  {
    id: "point-to-point",
    title: "Point-to-Point Transfers",
    description: "Flat-rate, on-demand rides across King, Pierce, and Snohomish counties — no surge pricing, no hidden tolls.",
    href: "/services#point-to-point",
    iconPath: "M15 10.5a3 3 0 11-6 0 3 3 0 016 0z M19.5 10.5c0 7.142-7.5 11.25-7.5 11.25S4.5 17.642 4.5 10.5a7.5 7.5 0 1115 0z"
  }
];

const $$Astro$6 = createAstro("https://emeraldcitylimos.com");
const $$LocationServices = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$6, $$props, $$slots);
  Astro2.self = $$LocationServices;
  const { location } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<section class="bg-white py-16 sm:py-20 lg:py-24"${addAttribute(`services-${location.slug}`, "aria-labelledby")}> <div class="mx-auto max-w-7xl px-6 sm:px-8 lg:px-12"> <!-- Section heading --> <div class="mb-12 text-center sm:mb-16"> <p class="mb-3 font-sans text-[11px] font-semibold uppercase tracking-[0.22em] text-brand-gold">
Services
</p> <h2${addAttribute(`services-${location.slug}`, "id")} class="font-display font-light leading-[1.1] text-brand-forest" style="font-size: clamp(1.75rem, 3.5vw, 2.5rem);">
Chauffeur services available in
<span class="italic text-brand-gold">${location.name}</span> </h2> </div> <!-- Cards grid --> <ul class="m-0 grid list-none gap-6 p-0 sm:grid-cols-2 lg:grid-cols-3"> ${locationServices.map((svc) => renderTemplate`<li> <a${addAttribute(svc.href, "href")} class="ecl-focusable group flex h-full flex-col gap-3 border-l-2 border-brand-gold/60 bg-white p-6 ring-1 ring-brand-forest/10 transition-[border-color,box-shadow] duration-300 hover:border-brand-gold hover:shadow-[0_8px_28px_-12px_rgba(10,35,24,0.18)] sm:p-7"${addAttribute(`${svc.title} in ${location.name} \u2014 learn more`, "aria-label")}> <div class="flex h-12 w-12 items-center justify-center rounded-sm bg-brand-forest text-brand-gold-soft"> <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" width="22" height="22" aria-hidden="true"> <path stroke-linecap="round" stroke-linejoin="round"${addAttribute(svc.iconPath, "d")}></path> </svg> </div> <h3 class="font-display text-xl font-medium leading-snug text-brand-forest transition-colors duration-300 group-hover:text-brand-gold"> ${svc.title} </h3> <p class="font-sans text-sm leading-relaxed text-brand-forest/75"> ${svc.description} </p> <span class="mt-auto inline-flex items-center gap-1.5 font-sans text-[11px] font-semibold uppercase tracking-[0.2em] text-brand-gold">
Learn more
<span aria-hidden="true" class="transition-transform duration-300 group-hover:translate-x-0.5">→</span> </span> </a> </li>`)} </ul> </div> </section>`;
}, "/home/josh/Documents/emerald-update/src/components/locations/LocationServices.astro", void 0);

const $$Astro$5 = createAstro("https://emeraldcitylimos.com");
const $$LocationFleet = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$5, $$props, $$slots);
  Astro2.self = $$LocationFleet;
  const { location } = Astro2.props;
  const CATEGORY_ORDER = ["Luxury Sedan", "Luxury SUV", "Executive Van", "Limousine"];
  const previewVehicles = CATEGORY_ORDER.map(
    (category) => fleet.find((v) => v.category === category)
  ).filter((v) => Boolean(v));
  return renderTemplate`${maybeRenderHead()}<section class="bg-brand-champagne py-16 sm:py-20 lg:py-24"${addAttribute(`fleet-${location.slug}`, "aria-labelledby")}> <div class="mx-auto max-w-7xl px-6 sm:px-8 lg:px-12"> <div class="mb-12 flex flex-col items-start justify-between gap-4 sm:mb-16 sm:flex-row sm:items-end"> <div> <p class="mb-3 font-sans text-[11px] font-semibold uppercase tracking-[0.22em] text-brand-gold">
The Fleet
</p> <h2${addAttribute(`fleet-${location.slug}`, "id")} class="font-display font-light leading-[1.1] text-brand-forest" style="font-size: clamp(1.75rem, 3.5vw, 2.5rem);">
Vehicles dispatched to
<span class="italic text-brand-gold">${location.name}</span> </h2> </div> <a href="/fleet" class="ecl-focusable inline-flex items-center gap-1.5 font-sans text-[11px] font-semibold uppercase tracking-[0.2em] text-brand-gold hover:text-brand-forest">
View full fleet
<span aria-hidden="true">→</span> </a> </div> <ul class="m-0 grid list-none gap-6 p-0 sm:grid-cols-2 lg:grid-cols-4"> ${previewVehicles.map((vehicle) => renderTemplate`<li class="h-full"> ${renderComponent($$result, "FleetCard", $$FleetCard, { "vehicle": vehicle })} </li>`)} </ul> </div> </section>`;
}, "/home/josh/Documents/emerald-update/src/components/locations/LocationFleet.astro", void 0);

const $$Astro$4 = createAstro("https://emeraldcitylimos.com");
const $$LocationWhyChoose = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$4, $$props, $$slots);
  Astro2.self = $$LocationWhyChoose;
  const { location } = Astro2.props;
  const reasons = [
    {
      title: "On-Time Guarantee",
      description: "Chauffeurs depart staging early and route around live traffic \u2014 if we are late, the ride is on us.",
      iconPath: "M12 6v6h4.5m4.5 0a9 9 0 11-18 0 9 9 0 0118 0z"
    },
    {
      title: "Live Flight Tracking",
      description: "Every airport pickup tracks ADS-B in real time. We know your wheels-down before you do.",
      iconPath: "M6 12 3.269 3.125A59.769 59.769 0 0121.485 12 59.768 59.768 0 013.27 20.875L5.999 12zm0 0h7.5"
    },
    {
      title: "Professional Chauffeurs",
      description: "Background-checked, business-attired, and trained on every loading-zone, FBO ramp, and hotel circle in the metro.",
      iconPath: "M15.75 6a3.75 3.75 0 11-7.5 0 3.75 3.75 0 017.5 0zM4.501 20.118a7.5 7.5 0 0114.998 0A17.933 17.933 0 0112 21.75c-2.676 0-5.216-.584-7.499-1.632z"
    },
    {
      title: "Luxury Fleet",
      description: "Mercedes S-Class, Cadillac Escalade ESV, Lincoln Navigator L, Mercedes Sprinters, and stretch limousines.",
      iconPath: "M8.25 18.75a1.5 1.5 0 01-3 0m3 0a1.5 1.5 0 00-3 0m3 0h6m-9 0H3.375a1.125 1.125 0 01-1.125-1.125V14.25m17.25 4.5a1.5 1.5 0 01-3 0m3 0a1.5 1.5 0 00-3 0m3 0h1.125c.621 0 1.129-.504 1.09-1.124a17.902 17.902 0 00-3.213-9.193 2.256 2.256 0 00-1.586-.67H4.25A2.25 2.25 0 002 7.498v6.75z"
    },
    {
      title: "Transparent Pricing",
      description: "All-inclusive flat rates \u2014 no surge, no hidden tolls, no surprise gratuity line items at drop-off.",
      iconPath: "M2.25 18.75a60.07 60.07 0 0115.797 2.101c.727.198 1.453-.342 1.453-1.096V18.75M3.75 4.5v.75A.75.75 0 013 6h-.75m0 0v-.375c0-.621.504-1.125 1.125-1.125H20.25M2.25 6v9m18-10.5v.75c0 .414.336.75.75.75h.75m-1.5-1.5h.375c.621 0 1.125.504 1.125 1.125v9.75c0 .621-.504 1.125-1.125 1.125h-.375m1.5-1.5H21a.75.75 0 00-.75.75v.75m0 0H3.75m0 0h-.375a1.125 1.125 0 01-1.125-1.125V15m1.5 1.5v-.75A.75.75 0 003 15h-.75M15 10.5a3 3 0 11-6 0 3 3 0 016 0zm3 0h.008v.008H18V10.5zm-12 0h.008v.008H6V10.5z"
    }
  ];
  return renderTemplate`${maybeRenderHead()}<section class="bg-brand-forest py-16 text-white sm:py-20 lg:py-24"${addAttribute(`why-${location.slug}`, "aria-labelledby")}> <div class="mx-auto max-w-7xl px-6 sm:px-8 lg:px-12"> <div class="mb-12 text-center sm:mb-16"> <p class="mb-3 font-sans text-[11px] font-semibold uppercase tracking-[0.22em] text-brand-gold-soft">
Why riders return
</p> <h2${addAttribute(`why-${location.slug}`, "id")} class="font-display font-light leading-[1.1] text-white" style="font-size: clamp(1.75rem, 3.5vw, 2.5rem);">
Built for ${location.name}'s most demanding rides
</h2> </div> <ul class="m-0 grid list-none gap-6 p-0 sm:grid-cols-2 lg:grid-cols-5"> ${reasons.map((r) => renderTemplate`<li class="flex flex-col gap-3 border-l border-brand-gold/40 pl-5"> <div class="flex h-11 w-11 items-center justify-center rounded-sm bg-white/5 ring-1 ring-brand-gold/40"> <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" width="20" height="20" class="text-brand-gold-soft" aria-hidden="true"> <path stroke-linecap="round" stroke-linejoin="round"${addAttribute(r.iconPath, "d")}></path> </svg> </div> <h3 class="font-display text-lg font-medium leading-snug text-white">${r.title}</h3> <p class="font-sans text-sm leading-relaxed text-white/70">${r.description}</p> </li>`)} </ul> </div> </section>`;
}, "/home/josh/Documents/emerald-update/src/components/locations/LocationWhyChoose.astro", void 0);

const $$Astro$3 = createAstro("https://emeraldcitylimos.com");
const $$LocationRoutes = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$3, $$props, $$slots);
  Astro2.self = $$LocationRoutes;
  const { location } = Astro2.props;
  const routes = location.popularRoutes ?? [];
  return renderTemplate`${routes.length > 0 && renderTemplate`${maybeRenderHead()}<section class="bg-white py-16 sm:py-20 lg:py-24"${addAttribute(`routes-${location.slug}`, "aria-labelledby")}><div class="mx-auto max-w-5xl px-6 sm:px-8 lg:px-12"><div class="mb-12 text-center sm:mb-16"><p class="mb-3 font-sans text-[11px] font-semibold uppercase tracking-[0.22em] text-brand-gold">
Popular Routes
</p><h2${addAttribute(`routes-${location.slug}`, "id")} class="font-display font-light leading-[1.1] text-brand-forest" style="font-size: clamp(1.75rem, 3.5vw, 2.5rem);">
Most-booked rides from
<span class="italic text-brand-gold">${location.name}</span></h2></div><ul class="m-0 list-none divide-y divide-brand-forest/10 border-y border-brand-forest/10 p-0">${routes.map((route) => {
    const from = route.from ?? location.name;
    return renderTemplate`<li class="grid items-center gap-3 py-4 sm:grid-cols-[1.4fr_auto_auto_auto] sm:gap-6 sm:py-5"><div class="font-display text-lg text-brand-forest"><span>${from}</span><span class="mx-2 text-brand-gold" aria-hidden="true">→</span><span>${route.to}</span></div><div class="font-sans text-xs uppercase tracking-[0.18em] text-brand-forest/60 tabular-nums">${route.driveTime}</div><div class="font-sans text-xs uppercase tracking-[0.18em] text-brand-forest/60 tabular-nums">${route.distanceMiles} mi
</div><div class="font-sans text-sm font-semibold tabular-nums text-brand-forest">${route.startingPriceUSD ? `from $${route.startingPriceUSD}` : "On request"}</div></li>`;
  })}</ul><p class="mt-6 text-center font-sans text-xs text-brand-forest/60">
Flat-rate pricing. All-inclusive — no surge, no hidden tolls.
</p></div></section>`}`;
}, "/home/josh/Documents/emerald-update/src/components/locations/LocationRoutes.astro", void 0);

const $$Astro$2 = createAstro("https://emeraldcitylimos.com");
const $$LocationFAQ = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$2, $$props, $$slots);
  Astro2.self = $$LocationFAQ;
  const { location } = Astro2.props;
  const faqs = location.faqs ?? [];
  return renderTemplate`${faqs.length > 0 && renderTemplate`${maybeRenderHead()}<section class="bg-white py-16 sm:py-20 lg:py-24"${addAttribute(`faq-${location.slug}`, "aria-labelledby")} data-astro-cid-clwm4emr><div class="mx-auto max-w-3xl px-6 sm:px-8 lg:px-12" data-astro-cid-clwm4emr><div class="mb-12 text-center sm:mb-16" data-astro-cid-clwm4emr><p class="mb-3 font-sans text-[11px] font-semibold uppercase tracking-[0.22em] text-brand-gold" data-astro-cid-clwm4emr>
Frequently Asked
</p><h2${addAttribute(`faq-${location.slug}`, "id")} class="font-display font-light leading-[1.1] text-brand-forest" style="font-size: clamp(1.75rem, 3.5vw, 2.5rem);" data-astro-cid-clwm4emr>${location.name} chauffeur service questions
</h2></div><ul class="m-0 list-none divide-y divide-brand-forest/10 border-y border-brand-forest/10 p-0" data-astro-cid-clwm4emr>${faqs.map((faq, i) => renderTemplate`<li data-astro-cid-clwm4emr><details class="group ecl-faq-item"${addAttribute(`faq-${location.slug}`, "name")}${addAttribute(i === 0, "open")} data-astro-cid-clwm4emr><summary class="ecl-focusable flex cursor-pointer list-none items-center justify-between gap-4 py-5 font-display text-lg text-brand-forest hover:text-brand-gold" data-astro-cid-clwm4emr><span data-astro-cid-clwm4emr>${faq.question}</span><span class="ecl-faq-icon flex h-6 w-6 flex-shrink-0 items-center justify-center text-brand-gold transition-transform duration-300 group-open:rotate-180" aria-hidden="true" data-astro-cid-clwm4emr><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" width="18" height="18" data-astro-cid-clwm4emr><path stroke-linecap="round" stroke-linejoin="round" d="M19.5 8.25l-7.5 7.5-7.5-7.5" data-astro-cid-clwm4emr></path></svg></span></summary><p class="pb-5 font-sans text-base leading-relaxed text-brand-forest/80" data-astro-cid-clwm4emr>${faq.answer}</p></details></li>`)}</ul></div></section>`}`;
}, "/home/josh/Documents/emerald-update/src/components/locations/LocationFAQ.astro", void 0);

var __freeze = Object.freeze;
var __defProp = Object.defineProperty;
var __template = (cooked, raw) => __freeze(__defProp(cooked, "raw", { value: __freeze(cooked.slice()) }));
var _a;
const $$Astro$1 = createAstro("https://emeraldcitylimos.com");
const $$LocationSchema = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$1, $$props, $$slots);
  Astro2.self = $$LocationSchema;
  const { location } = Astro2.props;
  const SITE_URL = "https://emeraldcitylimos.com";
  const PAGE_URL = `${SITE_URL}/locations/${location.slug}`;
  const PHONE = "+1-206-595-9675";
  const businessNode = {
    "@type": "LimousineService",
    "@id": `${PAGE_URL}#business`,
    name: `Emerald City Limos \u2014 ${location.name}`,
    url: PAGE_URL,
    telephone: PHONE,
    email: "client@emeraldcitylimos.com",
    image: new URL(location.heroImage, SITE_URL).href,
    priceRange: "$$",
    address: {
      "@type": "PostalAddress",
      addressLocality: location.name,
      addressRegion: "WA",
      addressCountry: "US"
    },
    geo: {
      "@type": "GeoCoordinates",
      latitude: location.coordinates.lat,
      longitude: location.coordinates.lng
    },
    areaServed: {
      "@type": "City",
      name: location.name,
      containedInPlace: { "@type": "AdministrativeArea", name: location.county }
    },
    openingHoursSpecification: {
      "@type": "OpeningHoursSpecification",
      dayOfWeek: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"],
      opens: "00:00",
      closes: "23:59"
    },
    aggregateRating: {
      "@type": "AggregateRating",
      ratingValue: "4.9",
      reviewCount: "127",
      bestRating: "5",
      worstRating: "1"
    }
  };
  const serviceNodes = locationServices.map((svc) => ({
    "@type": "Service",
    "@id": `${PAGE_URL}#service-${svc.id}`,
    name: `${svc.title} in ${location.name}`,
    description: svc.description,
    provider: { "@id": `${PAGE_URL}#business` },
    areaServed: { "@type": "City", name: location.name },
    serviceType: svc.title,
    url: `${SITE_URL}${svc.href}`
  }));
  const faqNode = location.faqs && location.faqs.length > 0 ? {
    "@type": "FAQPage",
    "@id": `${PAGE_URL}#faq`,
    mainEntity: location.faqs.map((faq) => ({
      "@type": "Question",
      name: faq.question,
      acceptedAnswer: { "@type": "Answer", text: faq.answer }
    }))
  } : null;
  const breadcrumbNode = {
    "@type": "BreadcrumbList",
    "@id": `${PAGE_URL}#breadcrumb`,
    itemListElement: [
      { "@type": "ListItem", position: 1, name: "Home", item: SITE_URL },
      { "@type": "ListItem", position: 2, name: "Service Areas", item: `${SITE_URL}/locations` },
      { "@type": "ListItem", position: 3, name: location.name, item: PAGE_URL }
    ]
  };
  const graph = [businessNode, ...serviceNodes, breadcrumbNode];
  if (faqNode) graph.push(faqNode);
  const payload = {
    "@context": "https://schema.org",
    "@graph": graph
  };
  return renderTemplate(_a || (_a = __template(['<script type="application/ld+json">', "<\/script>"])), unescapeHTML(JSON.stringify(payload)));
}, "/home/josh/Documents/emerald-update/src/components/locations/LocationSchema.astro", void 0);

const $$Astro = createAstro("https://emeraldcitylimos.com");
async function getStaticPaths() {
  return locations.map((loc) => ({
    params: { slug: loc.slug },
    props: { location: loc }
  }));
}
const $$slug = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$slug;
  const { location } = Astro2.props;
  const canonical = `https://emeraldcitylimos.com/locations/${location.slug}`;
  const ogImage = location.meta.ogImage ?? location.heroImage;
  return renderTemplate`${renderComponent($$result, "LocationLayout", $$LocationLayout, { "title": location.meta.title, "description": location.meta.description, "keywords": location.meta.keywords.join(", "), "ogImage": ogImage, "canonical": canonical }, { "default": ($$result2) => renderTemplate` ${renderComponent($$result2, "PageHero", $$PageHero, { "eyebrow": location.county, "headline": "Luxury Chauffeur Service", "headlineAccent": location.name, "supporting": location.heroSupporting, "image": { src: location.heroImage, alt: location.heroImageAlt }, "id": `hero-${location.slug}`, "size": "page", "noAnim": true })} ${renderComponent($$result2, "TrustStrip", $$TrustStrip, {})} ${renderComponent($$result2, "LocationIntro", $$LocationIntro, { "location": location })} ${renderComponent($$result2, "LocationServices", $$LocationServices, { "location": location })} ${renderComponent($$result2, "LocationFleet", $$LocationFleet, { "location": location })} ${renderComponent($$result2, "LocationWhyChoose", $$LocationWhyChoose, { "location": location })} ${renderComponent($$result2, "LocationRoutes", $$LocationRoutes, { "location": location })}  ${renderComponent($$result2, "LocationFAQ", $$LocationFAQ, { "location": location })} ${renderComponent($$result2, "LocationCTA", $$LocationCTA, { "location": location })} ${renderComponent($$result2, "LocationSchema", $$LocationSchema, { "location": location })} ` })}`;
}, "/home/josh/Documents/emerald-update/src/pages/locations/[slug].astro", void 0);

const $$file = "/home/josh/Documents/emerald-update/src/pages/locations/[slug].astro";
const $$url = "/locations/[slug]";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$slug,
  file: $$file,
  getStaticPaths,
  url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };

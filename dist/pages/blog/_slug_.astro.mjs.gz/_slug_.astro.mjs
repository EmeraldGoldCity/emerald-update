import { d as createAstro, c as createComponent, m as maybeRenderHead, r as renderComponent, a as renderTemplate, u as unescapeHTML, b as addAttribute, F as Fragment } from '../../chunks/astro/server_aszwXi13.mjs';
import 'piccolore';
import { $ as $$MainLayout } from '../../chunks/MainLayout_cGPQHjQ1.mjs';
import { $ as $$PostCard, s as sanityClient, B as BLOG_POST_QUERY, R as RELATED_POSTS_QUERY, c as BLOG_SLUGS_QUERY } from '../../chunks/PostCard_CTh8mdoc.mjs';
import { toHTML } from '@portabletext/to-html';
/* empty css                                     */
export { renderers } from '../../renderers.mjs';

const $$Astro$1 = createAstro("https://emeraldcitylimos.com");
const $$RelatedArticles = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$1, $$props, $$slots);
  Astro2.self = $$RelatedArticles;
  const { posts } = Astro2.props;
  return renderTemplate`${posts.length > 0 && renderTemplate`${maybeRenderHead()}<section class="bg-brand-champagne py-16 sm:py-20 px-6 sm:px-8" aria-labelledby="related-articles-heading"><div class="max-w-6xl mx-auto"><!-- Section eyebrow + heading — matches site-wide heading style --><div class="flex items-center gap-4 mb-6"><div class="h-px w-10 bg-brand-gold shrink-0" aria-hidden="true"></div><p class="font-sans text-[10px] font-semibold tracking-[0.22em] uppercase text-brand-gold">
Continue Reading
</p></div><h2 id="related-articles-heading" class="font-display font-light text-brand-forest leading-[1.1] tracking-[-0.02em] mb-10" style="font-size: clamp(1.5rem, 3vw, 2.25rem);">
Related Articles
</h2><ul class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8" role="list">${posts.map((post) => renderTemplate`<li role="listitem">${renderComponent($$result, "PostCard", $$PostCard, { "post": post })}</li>`)}</ul></div></section>`}`;
}, "/home/josh/Documents/emerald-update/src/components/blog/RelatedArticles.astro", void 0);

const routeMap = {
  service: (slug) => `/services/${slug ?? ""}`,
  fleet: (slug) => `/fleet/${slug ?? ""}`,
  location: (slug) => `/service-areas/${slug ?? ""}`,
  booking: () => "#"
};
function resolveInternalLink(type, slug) {
  const resolver = routeMap[type];
  if (!resolver) return "#";
  return resolver(slug);
}

var __freeze = Object.freeze;
var __defProp = Object.defineProperty;
var __template = (cooked, raw) => __freeze(__defProp(cooked, "raw", { value: __freeze(cooked.slice()) }));
var _a;
const $$Astro = createAstro("https://emeraldcitylimos.com");
async function getStaticPaths() {
  const slugs = await sanityClient.fetch(BLOG_SLUGS_QUERY);
  return slugs.map(({ slug }) => ({ params: { slug } }));
}
const $$slug = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$slug;
  const { slug } = Astro2.params;
  const post = await sanityClient.fetch(BLOG_POST_QUERY, { slug });
  if (!post) {
    return Astro2.redirect("/blog", 301);
  }
  function esc(s) {
    return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  }
  function safeUrl(u) {
    if (typeof u !== "string") return "#";
    return /^https?:\/\//.test(u) || u.startsWith("/") ? u : "#";
  }
  const bodyHTML = post.body ? toHTML(post.body, {
    components: {
      types: {
        image: ({ value }) => {
          const url = safeUrl(value.url);
          if (url === "#") return "";
          const alt = esc(value.alt ?? "");
          const caption = value.caption;
          return `<figure class="pt-body-image">
              <img src="${url}" alt="${alt}" loading="lazy" decoding="async" class="pt-img" />
              ${caption ? `<figcaption class="pt-caption">${esc(caption)}</figcaption>` : ""}
            </figure>`;
        },
        externalImage: ({ value }) => {
          const url = safeUrl(value.url);
          if (url === "#") return "";
          const alt = esc(value.alt ?? "");
          const caption = value.caption;
          const attribution = value.attribution;
          const source = value.source;
          const creditParts = [];
          if (attribution) creditParts.push(`by ${esc(attribution)}`);
          if (source) creditParts.push(`on ${esc(source)}`);
          const credit = creditParts.length ? `Photo ${creditParts.join(" ")}` : "";
          return `<figure class="pt-body-image">
              <img src="${url}" alt="${alt}" loading="lazy" decoding="async" class="pt-img" />
              ${caption ? `<figcaption class="pt-caption">${esc(caption)}</figcaption>` : ""}
              ${credit ? `<p class="pt-attribution">${credit}</p>` : ""}
            </figure>`;
        },
        internalLinkBlock: ({ value }) => {
          const href = resolveInternalLink(
            value.linkType ?? "",
            value.slug
          );
          const heading = esc(value.heading ?? "");
          const description = value.description;
          const label = esc(value.label || "Learn more");
          return `<div class="pt-link-block">
              <span class="pt-link-block__heading">${heading}</span>
              ${description ? `<span class="pt-link-block__desc">${esc(description)}</span>` : ""}
              <a href="${esc(href)}" class="pt-link-block__cta">${label} <span aria-hidden="true">\u2192</span></a>
            </div>`;
        }
      },
      marks: {
        link: ({ children, value }) => {
          const href = safeUrl(value.href);
          return `<a href="${href}" target="_blank" rel="noopener noreferrer">${children}</a>`;
        },
        internalLink: ({ children, value }) => {
          const href = resolveInternalLink(
            value.type ?? "",
            value.slug
          );
          return `<a href="${esc(href)}">${children}</a>`;
        }
      }
    }
  }) : "";
  const pageTitle = post.seo?.metaTitle ?? post.title;
  const pageDesc = post.seo?.metaDescription ?? post.excerpt;
  const ogImage = post.mainImage?.url ?? void 0;
  const categoryRefs = post.categoryRefs ?? [];
  const relatedPosts = categoryRefs.length > 0 ? await sanityClient.fetch(RELATED_POSTS_QUERY, {
    currentId: post._id,
    categoryRefs
  }) : [];
  function formatDate(iso) {
    return new Date(iso).toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric"
    });
  }
  return renderTemplate(_a || (_a = __template(["", ' <script type="application/ld+json">', "<\/script> <script>\n  (function () {\n    function copyUrl(url, onSuccess) {\n      if (navigator.clipboard && navigator.clipboard.writeText) {\n        navigator.clipboard.writeText(url).then(onSuccess).catch(function () {\n          fallbackCopy(url, onSuccess);\n        });\n      } else {\n        fallbackCopy(url, onSuccess);\n      }\n    }\n\n    function fallbackCopy(url, onSuccess) {\n      var ta = document.createElement('textarea');\n      ta.value = url;\n      ta.style.cssText = 'position:fixed;opacity:0;pointer-events:none;';\n      document.body.appendChild(ta);\n      ta.select();\n      document.execCommand('copy');\n      document.body.removeChild(ta);\n      onSuccess();\n    }\n\n    // Desktop button \u2014 shows checkmark icon on success\n    var desktopBtn = document.getElementById('copy-link-btn');\n    if (desktopBtn) {\n      desktopBtn.addEventListener('click', function () {\n        var url = desktopBtn.getAttribute('data-url') || window.location.href;\n        copyUrl(url, function () {\n          var copyIcon  = document.getElementById('copy-icon');\n          var checkIcon = document.getElementById('check-icon');\n          if (copyIcon)  copyIcon.style.display  = 'none';\n          if (checkIcon) checkIcon.style.display = 'block';\n          setTimeout(function () {\n            if (copyIcon)  copyIcon.style.display  = '';\n            if (checkIcon) checkIcon.style.display = 'none';\n          }, 2000);\n        });\n      });\n    }\n\n    // Mobile button \u2014 updates label text on success\n    var mobileBtn = document.getElementById('copy-link-btn-mobile');\n    if (mobileBtn) {\n      mobileBtn.addEventListener('click', function () {\n        var url = mobileBtn.getAttribute('data-url') || window.location.href;\n        copyUrl(url, function () {\n          var label = mobileBtn.querySelector('.copy-label');\n          if (label) {\n            label.textContent = 'Copied!';\n            setTimeout(function () { label.textContent = 'Copy link'; }, 2000);\n          }\n        });\n      });\n    }\n  })();\n<\/script> "])), renderComponent($$result, "MainLayout", $$MainLayout, { "title": pageTitle, "description": pageDesc, "ogImage": ogImage, "canonical": `https://emeraldcitylimos.com/blog/${slug}` }, { "default": async ($$result2) => renderTemplate`  ${maybeRenderHead()}<section class="relative overflow-hidden bg-brand-forest-deep" style="min-height: clamp(400px, 62vh, 700px);" aria-label="Article hero"> <!-- Background image --> ${post.mainImage?.url && renderTemplate`<img${addAttribute(post.mainImage.url, "src")}${addAttribute(post.mainImage.alt ?? post.title, "alt")} width="1440" height="810" loading="eager" decoding="async" fetchpriority="high" class="absolute inset-0 w-full h-full object-cover object-center">`} <!-- Gradient overlay — heavier at the bottom for legibility --> <div class="absolute inset-0" style="background: linear-gradient(to bottom, rgba(6,23,15,0.45) 0%, rgba(6,23,15,0.82) 40%, rgba(6,23,15,0.98) 75%, rgba(6,23,15,1) 100%);" aria-hidden="true"></div> <!-- Inner layout: breadcrumb top, title/meta bottom --> <div class="absolute inset-0 flex flex-col justify-between"> <!-- Breadcrumb --> <div class="px-6 sm:px-8 pt-24"> <nav aria-label="Breadcrumb" class="mx-auto max-w-5xl"> <ol class="flex items-center gap-2 font-sans text-[10px] font-semibold tracking-[0.16em] uppercase text-white/50 list-none p-0 m-0"> <li><a href="/" class="hover:text-brand-gold transition-colors">Home</a></li> <li aria-hidden="true" class="text-white/30">/</li> <li><a href="/blog" class="hover:text-brand-gold transition-colors">Blog</a></li> <li aria-hidden="true" class="text-white/30">/</li> <li class="text-brand-gold/80 truncate max-w-[240px]" aria-current="page">${post.title}</li> </ol> </nav> </div> <!-- Categories, title, meta --> <div class="px-6 sm:px-8 pb-8 sm:pb-4"> <div class="mx-auto max-w-5xl"> ${post.categories && post.categories.length > 0 && renderTemplate`<div class="flex flex-wrap gap-3 mb-4"> ${post.categories.map((cat) => renderTemplate`<span class="font-sans text-[9px] font-semibold tracking-[0.2em] uppercase text-brand-gold"> ${cat.title} </span>`)} </div>`} <h1 class="font-display font-light text-white leading-[1.08] tracking-[-0.025em] mb-5" style="font-size: clamp(1.75rem, 4vw, 3.25rem);"> ${post.title} </h1> <div class="flex flex-wrap items-center gap-4"> ${post.author && renderTemplate`<span class="font-sans text-sm text-white/70">${post.author.name}</span>`} ${post.publishedAt && renderTemplate`${renderComponent($$result2, "Fragment", Fragment, {}, { "default": async ($$result3) => renderTemplate` <span class="text-white/30" aria-hidden="true">·</span> <time${addAttribute(post.publishedAt, "datetime")} class="font-sans text-sm text-white/70"> ${formatDate(post.publishedAt)} </time> ` })}`} ${post.readingTime && renderTemplate`${renderComponent($$result2, "Fragment", Fragment, {}, { "default": async ($$result3) => renderTemplate` <span class="text-white/30" aria-hidden="true">·</span> <span class="font-sans text-sm text-white/70">${post.readingTime} min read</span> ` })}`} </div> </div> </div> </div> </section>  <article class="bg-white px-6 sm:px-8 py-12 sm:py-16" itemscope itemtype="https://schema.org/BlogPosting"> <!-- Wide wrapper: article + sticky share sidebar --> <div class="mx-auto max-w-5xl"> <div class="lg:grid lg:grid-cols-[minmax(0,1fr)_56px] lg:gap-12 xl:gap-16"> <!-- ── Main content column ─────────────────────────────────── --> <div> <!-- Body --> <div class="prose prose-neutral prose-headings:font-display prose-headings:font-light prose-headings:text-brand-forest prose-a:text-brand-gold prose-a:no-underline hover:prose-a:underline prose-img:rounded-none prose-strong:text-brand-forest max-w-none" itemprop="articleBody">${unescapeHTML(bodyHTML)}</div> <!-- Mobile share — visible only below lg --> <div class="lg:hidden mt-12 pt-8 border-t border-brand-forest/[.08]"> <p class="font-sans text-[10px] font-semibold tracking-[0.2em] uppercase text-neutral-400 mb-4">
Share this article
</p> <div class="flex flex-wrap items-center gap-2" role="group" aria-label="Share this article"> <a${addAttribute(`https://twitter.com/intent/tweet?url=https://emeraldcitylimos.com/blog/${slug}&text=${encodeURIComponent(post.title)}`, "href")} target="_blank" rel="noopener noreferrer" aria-label="Share on X (Twitter)" class="share-btn inline-flex items-center gap-2 min-h-[40px] px-4 font-sans text-[10px] font-semibold tracking-[0.16em] uppercase text-brand-forest border border-brand-forest/15 bg-white transition-colors duration-200 hover:border-brand-gold hover:text-brand-gold"> <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="13" height="13" aria-hidden="true"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-4.714-6.231-5.401 6.231H2.744l7.737-8.835L1.254 2.25H8.08l4.259 5.63 5.905-5.63Zm-1.161 17.52h1.833L7.084 4.126H5.117z"></path></svg>
X
</a> <a${addAttribute(`https://www.facebook.com/sharer/sharer.php?u=https://emeraldcitylimos.com/blog/${slug}`, "href")} target="_blank" rel="noopener noreferrer" aria-label="Share on Facebook" class="share-btn inline-flex items-center gap-2 min-h-[40px] px-4 font-sans text-[10px] font-semibold tracking-[0.16em] uppercase text-brand-forest border border-brand-forest/15 bg-white transition-colors duration-200 hover:border-brand-gold hover:text-brand-gold"> <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="13" height="13" aria-hidden="true"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"></path></svg>
Facebook
</a> <a${addAttribute(`https://www.linkedin.com/shareArticle?mini=true&url=https://emeraldcitylimos.com/blog/${slug}&title=${encodeURIComponent(post.title)}`, "href")} target="_blank" rel="noopener noreferrer" aria-label="Share on LinkedIn" class="share-btn inline-flex items-center gap-2 min-h-[40px] px-4 font-sans text-[10px] font-semibold tracking-[0.16em] uppercase text-brand-forest border border-brand-forest/15 bg-white transition-colors duration-200 hover:border-brand-gold hover:text-brand-gold"> <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="13" height="13" aria-hidden="true"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 0 1-2.063-2.065 2.064 2.064 0 1 1 2.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"></path></svg>
LinkedIn
</a> <button type="button" id="copy-link-btn-mobile"${addAttribute(`https://emeraldcitylimos.com/blog/${slug}`, "data-url")} aria-label="Copy link to clipboard" class="share-btn inline-flex items-center gap-2 min-h-[40px] px-4 font-sans text-[10px] font-semibold tracking-[0.16em] uppercase text-brand-forest border border-brand-forest/15 bg-white transition-colors duration-200 hover:border-brand-gold hover:text-brand-gold cursor-pointer"> <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" width="13" height="13" aria-hidden="true"><path d="M13.19 8.688a4.5 4.5 0 0 1 1.242 7.244l-4.5 4.5a4.5 4.5 0 0 1-6.364-6.364l1.757-1.757m13.35-.622 1.757-1.757a4.5 4.5 0 0 0-6.364-6.364l-4.5 4.5a4.5 4.5 0 0 0 1.242 7.244"></path></svg> <span class="copy-label">Copy link</span> </button> </div> </div> <!-- Back link --> <div class="mt-10 pt-8 border-t border-brand-forest/[.08]"> <a href="/blog" class="inline-flex items-center gap-2 font-sans text-[11px] font-semibold tracking-[0.2em] uppercase text-brand-gold hover:text-brand-forest transition-colors duration-200"> <span aria-hidden="true">←</span> Back to Blog
</a> </div> </div> <!-- ── Sticky share sidebar — desktop only (lg+) ──────────── --> <aside class="hidden lg:block" aria-label="Share this article"> <div class="sticky top-8 flex flex-col items-center gap-3"> <p class="font-sans text-[8px] font-semibold tracking-[0.22em] uppercase text-neutral-400 [writing-mode:vertical-rl] rotate-180 mb-1">
Share
</p> <!-- X / Twitter --> <a${addAttribute(`https://twitter.com/intent/tweet?url=https://emeraldcitylimos.com/blog/${slug}&text=${encodeURIComponent(post.title)}`, "href")} target="_blank" rel="noopener noreferrer" aria-label="Share on X (Twitter)" class="share-icon-btn inline-flex h-10 w-10 items-center justify-center border border-brand-forest/12 bg-white text-brand-forest/60 transition-colors duration-200 hover:border-brand-gold hover:text-brand-gold"> <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="14" height="14" aria-hidden="true"> <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-4.714-6.231-5.401 6.231H2.744l7.737-8.835L1.254 2.25H8.08l4.259 5.63 5.905-5.63Zm-1.161 17.52h1.833L7.084 4.126H5.117z"></path> </svg> </a> <!-- Facebook --> <a${addAttribute(`https://www.facebook.com/sharer/sharer.php?u=https://emeraldcitylimos.com/blog/${slug}`, "href")} target="_blank" rel="noopener noreferrer" aria-label="Share on Facebook" class="share-icon-btn inline-flex h-10 w-10 items-center justify-center border border-brand-forest/12 bg-white text-brand-forest/60 transition-colors duration-200 hover:border-brand-gold hover:text-brand-gold"> <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="14" height="14" aria-hidden="true"> <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"></path> </svg> </a> <!-- LinkedIn --> <a${addAttribute(`https://www.linkedin.com/shareArticle?mini=true&url=https://emeraldcitylimos.com/blog/${slug}&title=${encodeURIComponent(post.title)}`, "href")} target="_blank" rel="noopener noreferrer" aria-label="Share on LinkedIn" class="share-icon-btn inline-flex h-10 w-10 items-center justify-center border border-brand-forest/12 bg-white text-brand-forest/60 transition-colors duration-200 hover:border-brand-gold hover:text-brand-gold"> <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="14" height="14" aria-hidden="true"> <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 0 1-2.063-2.065 2.064 2.064 0 1 1 2.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"></path> </svg> </a> <!-- Copy link --> <button type="button" id="copy-link-btn"${addAttribute(`https://emeraldcitylimos.com/blog/${slug}`, "data-url")} aria-label="Copy link to clipboard" class="share-icon-btn inline-flex h-10 w-10 items-center justify-center border border-brand-forest/12 bg-white text-brand-forest/60 transition-colors duration-200 hover:border-brand-gold hover:text-brand-gold cursor-pointer"> <svg id="copy-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" width="14" height="14" aria-hidden="true"> <path d="M13.19 8.688a4.5 4.5 0 0 1 1.242 7.244l-4.5 4.5a4.5 4.5 0 0 1-6.364-6.364l1.757-1.757m13.35-.622 1.757-1.757a4.5 4.5 0 0 0-6.364-6.364l-4.5 4.5a4.5 4.5 0 0 0 1.242 7.244"></path> </svg> <!-- Checkmark shown on copy success --> <svg id="check-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="14" height="14" aria-hidden="true" style="display:none;"> <path d="M4.5 12.75l6 6 9-13.5"></path> </svg> </button> </div> </aside> </div> </div> </article>  ${renderComponent($$result2, "RelatedArticles", $$RelatedArticles, { "posts": relatedPosts })}  <section class="bg-brand-champagne py-14 sm:py-20 px-6 sm:px-8"> <div class="max-w-3xl mx-auto text-center"> <p class="font-sans text-[10px] font-semibold tracking-[0.22em] uppercase text-brand-gold mb-4">
Ready to Ride?
</p> <h2 class="font-display font-light text-brand-forest leading-[1.1] tracking-[-0.02em] mb-6" style="font-size: clamp(1.5rem, 3vw, 2.25rem);">
Book your Seattle chauffeur today
</h2> <a href="https://customer.moovs.app/a1-charters-1/new/info" target="_blank" rel="noopener noreferrer" class="inline-flex items-center gap-2 min-h-[52px] px-10 font-sans text-[11px] font-semibold tracking-[0.2em] uppercase bg-brand-forest text-white border border-brand-forest transition-colors duration-200 hover:bg-brand-forest/90">
Reserve Your Ride →
</a> </div> </section> ` }), unescapeHTML(JSON.stringify({
    "@context": "https://schema.org",
    "@type": "BlogPosting",
    headline: post.title,
    description: post.excerpt,
    url: `https://emeraldcitylimos.com/blog/${slug}`,
    datePublished: post.publishedAt,
    author: post.author ? { "@type": "Person", name: post.author.name } : void 0,
    publisher: {
      "@type": "Organization",
      name: "Emerald City Limos",
      url: "https://emeraldcitylimos.com"
    },
    ...ogImage ? { image: ogImage } : {}
  })));
}, "/home/josh/Documents/emerald-update/src/pages/blog/[slug].astro", void 0);

const $$file = "/home/josh/Documents/emerald-update/src/pages/blog/[slug].astro";
const $$url = "/blog/[slug]";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$slug,
  file: $$file,
  getStaticPaths,
  url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };

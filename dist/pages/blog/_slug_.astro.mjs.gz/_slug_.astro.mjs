import { c as createAstro, a as createComponent, r as renderTemplate, u as unescapeHTML, b as renderComponent, m as maybeRenderHead, d as addAttribute, F as Fragment } from '../../chunks/astro/server_Cr-soRLN.mjs';
import 'piccolore';
import { $ as $$MainLayout } from '../../chunks/MainLayout_Dr-tyif_.mjs';
import { s as sanityClient, B as BLOG_POST_QUERY, u as urlFor, a as BLOG_SLUGS_QUERY } from '../../chunks/sanity_DfKDg59q.mjs';
import { toHTML } from '@portabletext/to-html';
/* empty css                                     */
export { renderers } from '../../renderers.mjs';

var __freeze = Object.freeze;
var __defProp = Object.defineProperty;
var __template = (cooked, raw) => __freeze(__defProp(cooked, "raw", { value: __freeze(cooked.slice()) }));
var _a;
const $$Astro = createAstro("https://emeraldcitylimos.com");
async function getStaticPaths() {
  const slugs = await sanityClient.fetch(BLOG_SLUGS_QUERY);
  return slugs.map(({ slug }) => ({ params: { slug } }));
}
const $$slug = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$slug;
  const { slug } = Astro2.params;
  const post = await sanityClient.fetch(BLOG_POST_QUERY, { slug });
  if (!post) {
    return Astro2.redirect("/blog", 301);
  }
  const bodyHTML = post.body ? toHTML(post.body) : "";
  const pageTitle = post.seo?.metaTitle ?? post.title;
  const pageDesc = post.seo?.metaDescription ?? post.excerpt;
  const ogImage = post.mainImage?.asset ? urlFor(post.mainImage).width(1200).height(630).auto("format").url() : void 0;
  function formatDate(iso) {
    return new Date(iso).toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric"
    });
  }
  return renderTemplate(_a || (_a = __template(["", ' <script type="application/ld+json">', "<\/script> "])), renderComponent($$result, "MainLayout", $$MainLayout, { "title": pageTitle, "description": pageDesc, "ogImage": ogImage, "canonical": `https://emeraldcitylimos.com/blog/${slug}` }, { "default": async ($$result2) => renderTemplate`  ${post.mainImage?.asset && renderTemplate`${maybeRenderHead()}<div class="relative bg-brand-forest overflow-hidden" style="height: clamp(260px, 40vw, 480px);"> <img${addAttribute(urlFor(post.mainImage).width(1440).height(480).auto("format").url(), "src")}${addAttribute(post.mainImage.alt ?? post.title, "alt")} width="1440" height="480" loading="eager" decoding="async" class="w-full h-full object-cover opacity-60"> <div class="absolute inset-0 bg-gradient-to-t from-brand-forest via-brand-forest/40 to-transparent"></div> </div>`} <article class="bg-white px-6 sm:px-8 py-12 sm:py-16" itemscope itemtype="https://schema.org/BlogPosting"> <div class="max-w-3xl mx-auto"> <!-- Breadcrumb --> <nav aria-label="Breadcrumb" class="mb-8"> <ol class="flex items-center gap-2 font-sans text-[10px] font-semibold tracking-[0.16em] uppercase text-neutral-400 list-none p-0 m-0"> <li><a href="/" class="hover:text-brand-gold transition-colors">Home</a></li> <li aria-hidden="true" class="text-neutral-300">/</li> <li><a href="/blog" class="hover:text-brand-gold transition-colors">Blog</a></li> <li aria-hidden="true" class="text-neutral-300">/</li> <li class="text-brand-gold truncate max-w-[180px]" aria-current="page">${post.title}</li> </ol> </nav> <!-- Categories --> ${post.categories && post.categories.length > 0 && renderTemplate`<div class="flex flex-wrap gap-3 mb-4"> ${post.categories.map((cat) => renderTemplate`<span class="font-sans text-[9px] font-semibold tracking-[0.2em] uppercase text-brand-gold"> ${cat.title} </span>`)} </div>`} <!-- Title --> <h1 class="font-display font-light text-brand-forest leading-[1.08] tracking-[-0.025em] mb-6" style="font-size: clamp(1.75rem, 4vw, 3rem);" itemprop="headline"> ${post.title} </h1> <!-- Meta row --> <div class="flex flex-wrap items-center gap-4 mb-8 pb-8 border-b border-brand-forest/[.08]"> ${post.author && renderTemplate`<span class="font-sans text-sm text-neutral-600" itemprop="author" itemscope itemtype="https://schema.org/Person"> <span itemprop="name">${post.author.name}</span> </span>`} ${post.publishedAt && renderTemplate`${renderComponent($$result2, "Fragment", Fragment, {}, { "default": async ($$result3) => renderTemplate` <span class="text-neutral-300" aria-hidden="true">·</span> <time${addAttribute(post.publishedAt, "datetime")} class="font-sans text-sm text-neutral-500" itemprop="datePublished"> ${formatDate(post.publishedAt)} </time> ` })}`} ${post.readingTime && renderTemplate`${renderComponent($$result2, "Fragment", Fragment, {}, { "default": async ($$result3) => renderTemplate` <span class="text-neutral-300" aria-hidden="true">·</span> <span class="font-sans text-sm text-neutral-500">${post.readingTime} min read</span> ` })}`} </div> <!-- Body --> <div class="prose prose-neutral prose-headings:font-display prose-headings:font-light prose-headings:text-brand-forest prose-a:text-brand-gold prose-a:no-underline hover:prose-a:underline prose-img:rounded-none prose-strong:text-brand-forest max-w-none" itemprop="articleBody">${unescapeHTML(bodyHTML)}</div> <!-- Back link --> <div class="mt-16 pt-8 border-t border-brand-forest/[.08]"> <a href="/blog" class="inline-flex items-center gap-2 font-sans text-[11px] font-semibold tracking-[0.2em] uppercase text-brand-gold hover:text-brand-forest transition-colors duration-200"> <span aria-hidden="true">←</span> Back to Blog
</a> </div> </div> </article>  <section class="bg-brand-champagne py-14 sm:py-20 px-6 sm:px-8"> <div class="max-w-3xl mx-auto text-center"> <p class="font-sans text-[10px] font-semibold tracking-[0.22em] uppercase text-brand-gold mb-4">
Ready to Ride?
</p> <h2 class="font-display font-light text-brand-forest leading-[1.1] tracking-[-0.02em] mb-6" style="font-size: clamp(1.5rem, 3vw, 2.25rem);">
Book your Seattle chauffeur today
</h2> <a href="https://customer.moovs.app/a1-charters-1/new/info" target="_blank" rel="noopener noreferrer" class="inline-flex items-center gap-2 min-h-[52px] px-10 font-sans text-[11px] font-semibold tracking-[0.2em] uppercase bg-brand-forest text-white border border-brand-forest transition-colors duration-200 hover:bg-brand-forest/90">
Reserve Your Ride →
</a> </div> </section> ` }), unescapeHTML(JSON.stringify({
    "@context": "https://schema.org",
    "@type": "BlogPosting",
    headline: post.title,
    description: post.excerpt,
    url: `https://emeraldcitylimos.com/blog/${slug}`,
    datePublished: post.publishedAt,
    author: post.author ? { "@type": "Person", name: post.author.name } : void 0,
    publisher: {
      "@type": "Organization",
      name: "Emerald City Limos",
      url: "https://emeraldcitylimos.com"
    },
    ...ogImage ? { image: ogImage } : {}
  })));
}, "/home/josh/Documents/emerald-update/src/pages/blog/[slug].astro", void 0);

const $$file = "/home/josh/Documents/emerald-update/src/pages/blog/[slug].astro";
const $$url = "/blog/[slug]";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$slug,
  file: $$file,
  getStaticPaths,
  url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };

import { c as createComponent, m as maybeRenderHead, b as addAttribute, a as renderTemplate, r as renderComponent } from '../chunks/astro/server_aszwXi13.mjs';
import 'piccolore';
import { $ as $$MainLayout } from '../chunks/MainLayout_CHOXC4sZ.mjs';
import { $ as $$PageHero, a as $$TrustStrip } from '../chunks/TrustStrip_C2Lja_d6.mjs';
import 'clsx';
import { s as services } from '../chunks/services_CcRo8FGN.mjs';
import { s as serviceHero } from '../chunks/fleet_CKS-qGY1.mjs';
export { renderers } from '../renderers.mjs';

const $$ServicesGrid = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<section class="bg-brand-champagne py-16 sm:py-20 lg:py-24" aria-labelledby="services-grid-heading"> <div class="mx-auto max-w-7xl px-6 sm:px-8 lg:px-12"> <div class="mb-12 max-w-2xl sm:mb-14"> <div class="mb-4 flex items-center gap-3"> <span class="h-px w-8 bg-brand-gold" aria-hidden="true"></span> <p class="font-sans text-[10px] font-semibold uppercase tracking-[0.22em] text-brand-gold">
What We Do
</p> </div> <h2 id="services-grid-heading" class="font-display font-light leading-[1.08] text-brand-forest" style="font-size: clamp(1.85rem, 3.4vw, 2.5rem); letter-spacing: -0.01em;">
A chauffeur for
<em class="italic text-brand-gold">every occasion.</em> </h2> </div> <ul role="list" class="m-0 grid list-none grid-cols-1 gap-4 p-0 md:grid-cols-2 lg:grid-cols-3 lg:gap-5"> ${services.map((service) => renderTemplate`<li class="m-0 p-0"> <a${addAttribute(service.href, "href")} class="group relative flex h-full flex-col border border-brand-forest/8 bg-white p-6 outline-none transition-[border-color,box-shadow,transform] duration-300 hover:border-brand-gold/45 hover:shadow-[0_24px_48px_-32px_rgba(10,35,24,0.28)] focus-visible:border-brand-gold focus-visible:ring-2 focus-visible:ring-brand-gold focus-visible:ring-offset-2 focus-visible:ring-offset-brand-champagne motion-reduce:transition-none"${addAttribute(`${service.cardHeadline} \u2014 learn more`, "aria-label")}> <!-- Top-left icon + gold rule --> <div class="mb-6 flex items-center gap-3"> <span class="inline-flex h-11 w-11 items-center justify-center border border-brand-gold/30 bg-brand-gold/5 text-brand-gold transition-colors duration-300 group-hover:border-brand-gold group-hover:bg-brand-gold group-hover:text-white"> <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" width="20" height="20" aria-hidden="true"> <path${addAttribute(service.cardIconPath, "d")}></path> </svg> </span> <span class="h-px flex-1 bg-brand-gold/15" aria-hidden="true"></span> </div> <h3 class="mb-3 font-display text-xl font-medium leading-tight text-brand-forest"> ${service.cardHeadline} </h3> <p class="mb-5 font-sans text-sm font-light leading-relaxed text-brand-forest/75"> ${service.cardDescription} </p> <ul role="list" class="m-0 mb-6 list-none space-y-1.5 p-0"> ${service.cardBullets.map((bullet) => renderTemplate`<li class="flex items-start gap-2 font-sans text-[0.78rem] leading-snug text-brand-forest/70"> <span class="mt-1.5 inline-block h-1 w-1 shrink-0 rounded-full bg-brand-gold" aria-hidden="true"></span> ${bullet} </li>`)} </ul> <span class="mt-auto inline-flex items-center gap-1.5 font-sans text-[0.72rem] font-semibold uppercase tracking-[0.18em] text-brand-gold transition-colors group-hover:text-brand-gold-soft">
Learn more
<svg viewBox="0 0 20 20" fill="currentColor" class="h-3 w-3 transition-transform duration-300 group-hover:translate-x-0.5" aria-hidden="true"> <path fill-rule="evenodd" d="M3 10a.75.75 0 0 1 .75-.75h10.638L10.23 5.29a.75.75 0 1 1 1.04-1.08l5.5 5.25a.75.75 0 0 1 0 1.08l-5.5 5.25a.75.75 0 1 1-1.04-1.08l4.158-3.96H3.75A.75.75 0 0 1 3 10Z" clip-rule="evenodd"></path> </svg> </span> </a> </li>`)} </ul> </div> </section>`;
}, "/home/josh/Documents/emerald-update/src/components/services/ServicesGrid.astro", void 0);

const $$Services = createComponent(($$result, $$props, $$slots) => {
  const stats = [
    { value: "24/7", label: "Dispatch availability" },
    { value: "50K+", label: "Rides delivered" },
    { value: "4.9 / 5", label: "Average rating" },
    { value: "$1.5M", label: "Liability coverage" }
  ];
  return renderTemplate`${renderComponent($$result, "MainLayout", $$MainLayout, { "title": "Luxury Chauffeur Services Seattle | Emerald City Limos", "description": "Airport transfers, hourly chauffeur, weddings, corporate travel, cruise transfers, game day and special occasions. Licensed Washington carrier, $1.5M insured, 24/7 dispatch.", "keywords": "seattle limo services, airport transfer seattle, wedding transportation seattle, corporate car service seattle, hourly charter seattle" }, { "default": ($$result2) => renderTemplate` ${renderComponent($$result2, "PageHero", $$PageHero, { "eyebrow": "What We Do", "headline": "Luxury Transportation,", "headlineAccent": "every occasion", "supporting": "Airport transfers, hourly charters, weddings, corporate travel, cruise transfers, game day and special occasions \u2014 professional chauffeurs, 24/7.", "image": {
    src: serviceHero,
    alt: "Emerald City Limos professional chauffeur service Seattle"
  }, "size": "page", "id": "services-hero", "breadcrumbs": [{ label: "Home", href: "/" }, { label: "Services" }] })} ${renderComponent($$result2, "TrustStrip", $$TrustStrip, {})} ${renderComponent($$result2, "ServicesGrid", $$ServicesGrid, {})}  ${maybeRenderHead()}<section class="relative overflow-hidden bg-brand-forest py-16 text-brand-champagne sm:py-20 lg:py-24" aria-labelledby="services-trust-heading"> <div class="pointer-events-none absolute inset-0" style="background: radial-gradient(ellipse 60% 50% at 50% 0%, rgba(163,126,44,0.16) 0%, transparent 70%);" aria-hidden="true"></div> <div class="relative mx-auto max-w-7xl px-6 sm:px-8 lg:px-12"> <div class="mb-12 text-center sm:mb-14"> <div class="mb-3 flex items-center justify-center gap-3"> <span class="h-px w-8 bg-brand-gold-soft" aria-hidden="true"></span> <p class="font-sans text-[10px] font-semibold uppercase tracking-[0.22em] text-brand-gold-soft">
By the Numbers
</p> <span class="h-px w-8 bg-brand-gold-soft" aria-hidden="true"></span> </div> <h2 id="services-trust-heading" class="font-display font-light leading-[1.1] text-white" style="font-size: clamp(1.85rem, 3.8vw, 2.6rem); letter-spacing: -0.01em;">
Built on
<em class="italic text-brand-gold-soft">repeat rides.</em> </h2> </div> <ul role="list" class="m-0 grid list-none grid-cols-2 gap-px overflow-hidden border border-white/8 bg-white/8 p-0 lg:grid-cols-4"> ${stats.map((stat) => renderTemplate`<li class="flex flex-col items-center justify-center gap-2 bg-brand-forest px-6 py-10 text-center sm:py-12"> <p class="font-display text-3xl font-light tabular-nums text-brand-gold-soft sm:text-4xl"> ${stat.value} </p> <p class="font-sans text-[0.72rem] font-semibold uppercase tracking-[0.18em] text-white/70"> ${stat.label} </p> </li>`)} </ul> </div> </section>  <section class="relative overflow-hidden bg-brand-champagne py-16 sm:py-20 lg:py-24" aria-labelledby="services-cta-heading"> <div class="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-brand-gold/25 to-transparent" aria-hidden="true"></div> <div class="relative mx-auto max-w-3xl px-6 text-center sm:px-8 lg:px-12"> <div class="mb-3 flex items-center justify-center gap-3"> <span class="h-px w-8 bg-brand-gold" aria-hidden="true"></span> <p class="font-sans text-[10px] font-semibold uppercase tracking-[0.22em] text-brand-gold">
Reserve Now
</p> <span class="h-px w-8 bg-brand-gold" aria-hidden="true"></span> </div> <h2 id="services-cta-heading" class="mb-4 font-display font-light leading-[1.1] text-brand-forest" style="font-size: clamp(1.85rem, 3.8vw, 2.6rem); letter-spacing: -0.01em;">
Pick a service.
<em class="italic text-brand-gold">We'll handle the rest.</em> </h2> <p class="mx-auto mb-8 max-w-xl font-sans text-[0.98rem] font-light leading-relaxed text-brand-forest/75">
Online in under two minutes, or call dispatch — a human picks up,
        every hour of every day.
</p> <div class="flex flex-col items-stretch justify-center gap-3 sm:flex-row sm:items-center sm:gap-4" role="group" aria-label="Book or call"> <a href="https://customer.moovs.app/a1-charters-1/new/info" target="_blank" rel="noopener noreferrer" class="inline-flex min-h-[52px] items-center justify-center gap-2 border border-brand-gold bg-brand-gold px-8 font-sans text-[11px] font-semibold uppercase tracking-[0.2em] text-brand-forest outline-none transition-[background-color,box-shadow] duration-200 hover:bg-brand-gold-soft hover:shadow-[0_12px_28px_-12px_rgba(163,126,44,0.5)] focus-visible:ring-2 focus-visible:ring-brand-gold focus-visible:ring-offset-2 focus-visible:ring-offset-brand-champagne motion-reduce:transition-none">
Reserve a Ride
<span aria-hidden="true">→</span> </a> <a href="tel:+12065959675" class="inline-flex min-h-[52px] items-center justify-center gap-2 border border-brand-forest/25 bg-white px-8 font-sans text-[11px] font-semibold uppercase tracking-[0.2em] text-brand-forest outline-none transition-colors duration-200 hover:border-brand-gold focus-visible:ring-2 focus-visible:ring-brand-gold focus-visible:ring-offset-2 focus-visible:ring-offset-brand-champagne motion-reduce:transition-none" aria-label="Call Emerald City Limos at (206) 595-9675, available 24 hours"> <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" width="14" height="14" class="text-brand-gold" aria-hidden="true"> <path d="M2.25 6.75c0 8.284 6.716 15 15 15h2.25a2.25 2.25 0 0 0 2.25-2.25v-1.372c0-.516-.351-.966-.852-1.091l-4.423-1.106c-.44-.11-.902.055-1.173.417l-.97 1.293c-.282.376-.769.542-1.21.38a12.035 12.035 0 0 1-7.143-7.143c-.162-.441.004-.928.38-1.21l1.293-.97c.363-.271.527-.734.417-1.173L6.963 3.102a1.125 1.125 0 0 0-1.091-.852H4.5A2.25 2.25 0 0 0 2.25 4.5v2.25Z"></path> </svg> <span class="tabular-nums">(206) 595-9675</span> </a> </div> </div> </section> ` })}`;
}, "/home/josh/Documents/emerald-update/src/pages/services.astro", void 0);

const $$file = "/home/josh/Documents/emerald-update/src/pages/services.astro";
const $$url = "/services";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$Services,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };

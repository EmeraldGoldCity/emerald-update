import { b as createAstro, c as createComponent, r as renderComponent, a as renderTemplate, m as maybeRenderHead, d as addAttribute } from '../../chunks/astro/server_7-PjRNDj.mjs';
import 'piccolore';
import { $ as $$MainLayout } from '../../chunks/MainLayout_BwP3NZXh.mjs';
import { a as allLocations } from '../../chunks/locations_DWBKRY71.mjs';
export { renderers } from '../../renderers.mjs';

const ENHANCED_LOCATIONS = [
  // KING COUNTY - Premium Eastside
  {
    name: "Bellevue",
    slug: "bellevue",
    county: "King County",
    zipCodes: ["98004", "98005", "98006", "98007", "98008", "98009"],
    population: 15e4,
    medianIncome: 138750,
    distance: 10,
    coordinates: { lat: 47.6101, lng: -122.2015 },
    landmarks: [
      "Bellevue Square",
      "Bellevue Downtown Park",
      "Meydenbauer Center",
      "The Bravern",
      "Lincoln Square"
    ],
    neighborhoods: ["Downtown", "Crossroads", "Eastgate", "Somerset", "West Bellevue"],
    description: "Premium Bellevue limousine service to Bellevue Square, downtown hotels, Lincoln Square, corporate offices, and Meydenbauer Center. Professional transportation for business executives and special occasions throughout all Bellevue neighborhoods including Downtown, Somerset, and Crossroads.",
    metaDescription: "Luxury Bellevue limo service from $110. Airport transfers, corporate car service, wedding limos. Serving all Bellevue ZIP codes 98004-98009. Book 24/7.",
    keywords: [
      "bellevue limo service",
      "bellevue car service",
      "bellevue airport limo",
      "luxury transportation bellevue",
      "bellevue corporate car service",
      "bellevue wedding limo"
    ]
  },
  {
    name: "Mercer Island",
    slug: "mercer-island",
    county: "King County",
    zipCodes: ["98040"],
    population: 25820,
    medianIncome: 168333,
    distance: 8,
    coordinates: { lat: 47.5707, lng: -122.2221 },
    landmarks: [
      "Luther Burbank Park",
      "Mercer Island Community Center",
      "Mercer Island Country Club",
      "Clarke Beach Park"
    ],
    neighborhoods: ["North End", "Town Center", "South End", "East Seattle"],
    description: "Exclusive Mercer Island luxury limousine service to waterfront estates, Luther Burbank Park, Country Club, and premium island destinations. Elite chauffeur service for high-net-worth residents and guests.",
    metaDescription: "Premium Mercer Island limo service from $100. Luxury car service for waterfront estates. Serving ZIP 98040. Elite chauffeur service 24/7.",
    keywords: [
      "mercer island limo",
      "mercer island car service",
      "mercer island luxury transportation",
      "mercer island airport service",
      "mercer island chauffeur"
    ]
  },
  {
    name: "Kirkland",
    slug: "kirkland",
    county: "King County",
    zipCodes: ["98033", "98034", "98083"],
    population: 92175,
    medianIncome: 125833,
    distance: 12,
    coordinates: { lat: 47.6815, lng: -122.2087 },
    landmarks: [
      "Kirkland Waterfront",
      "Marina Park",
      "Google Kirkland Campus",
      "Juanita Beach Park",
      "Carillon Point"
    ],
    neighborhoods: ["Downtown", "Juanita", "Totem Lake", "Finn Hill", "Kingsgate"],
    description: "Luxury Kirkland limo service to waterfront hotels, downtown Kirkland, Marina Park, Google campus, and Lake Washington venues. Executive transportation and wedding car service throughout Juanita, Totem Lake, and all Kirkland neighborhoods.",
    metaDescription: "Kirkland limo service from $115. Waterfront transportation, corporate car service, event limos. Serving all Kirkland ZIP codes. Book now!",
    keywords: [
      "kirkland limo service",
      "kirkland car service",
      "kirkland waterfront transportation",
      "kirkland corporate limo",
      "kirkland airport service"
    ]
  },
  {
    name: "Redmond",
    slug: "redmond",
    county: "King County",
    zipCodes: ["98052", "98053", "98073"],
    population: 73256,
    medianIncome: 131250,
    distance: 16,
    coordinates: { lat: 47.674, lng: -122.1215 },
    landmarks: [
      "Microsoft Campus",
      "Marymoor Park",
      "Redmond Town Center",
      "Sammamish River Trail",
      "Nintendo of America"
    ],
    neighborhoods: ["Downtown", "Overlake", "Grass Lawn", "Education Hill", "Bear Creek"],
    description: "Professional Redmond limousine service to Microsoft campus, corporate headquarters, Redmond Town Center, Marymoor Park, and tech company events. Executive car service for business travel throughout Overlake and all Redmond neighborhoods.",
    metaDescription: "Redmond limo service from $125. Microsoft campus transportation, corporate car service, airport transfers. Serving ZIP 98052-98073. 24/7 availability.",
    keywords: [
      "redmond limo service",
      "microsoft campus transportation",
      "redmond corporate car service",
      "redmond airport limo",
      "redmond chauffeur service"
    ]
  },
  {
    name: "Medina",
    slug: "medina",
    county: "King County",
    zipCodes: ["98039"],
    population: 3267,
    medianIncome: 186929,
    distance: 10,
    coordinates: { lat: 47.6165, lng: -122.238 },
    landmarks: [
      "Medina Beach Park",
      "Medina Golf & Country Club",
      "Overlake Golf & Country Club",
      "Lake Washington Estates"
    ],
    neighborhoods: ["The Point", "Evergreen Point", "Fairweather Bay"],
    description: "Ultra-exclusive Medina luxury limousine service to waterfront estates, private clubs, and premium lakefront destinations. Discreet, professional chauffeur service for Seattle's most affluent community.",
    metaDescription: "Exclusive Medina limo service from $110. Ultra-luxury transportation for waterfront estates. ZIP 98039. Elite discretion guaranteed.",
    keywords: [
      "medina limo service",
      "medina luxury car service",
      "medina chauffeur",
      "medina waterfront transportation",
      "medina private transportation"
    ]
  },
  {
    name: "Sammamish",
    slug: "sammamish",
    county: "King County",
    zipCodes: ["98074", "98075"],
    population: 67455,
    medianIncome: 142500,
    distance: 20,
    coordinates: { lat: 47.6163, lng: -122.0356 },
    landmarks: [
      "Beaver Lake Park",
      "Pine Lake",
      "Sammamish Commons",
      "Big Rock Park",
      "Klahanie Shopping Center"
    ],
    neighborhoods: ["Klahanie", "Sahalee", "Trossachs", "East Sammamish Plateau"],
    description: "Exclusive Sammamish limousine service to Plateau communities, Sahalee estates, corporate events, and luxury homes. Premium chauffeur service for executives and special occasions throughout Klahanie and East Sammamish.",
    metaDescription: "Sammamish limo service from $130. Plateau luxury transportation, corporate car service. Serving ZIP 98074-98075. Professional chauffeurs 24/7.",
    keywords: [
      "sammamish limo service",
      "sammamish car service",
      "sammamish plateau transportation",
      "sammamish airport limo",
      "sahalee limo service"
    ]
  },
  {
    name: "Issaquah",
    slug: "issaquah",
    county: "King County",
    zipCodes: ["98027", "98029"],
    population: 39509,
    medianIncome: 132500,
    distance: 18,
    coordinates: { lat: 47.5301, lng: -122.0326 },
    landmarks: [
      "Gilman Village",
      "Tiger Mountain",
      "Cougar Mountain Zoo",
      "Issaquah Salmon Hatchery",
      "Village Theatre"
    ],
    neighborhoods: ["Central Issaquah", "Talus", "Providence Point", "Grand Ridge"],
    description: "Premium Issaquah limousine service to Gilman Village, Tiger Mountain venues, corporate events, and Issaquah wedding locations. Professional transportation throughout Providence Point and all Issaquah communities.",
    metaDescription: "Issaquah limo service from $125. Luxury transportation to Tiger Mountain, corporate events, weddings. ZIP 98027-98029. Book online now!",
    keywords: [
      "issaquah limo service",
      "issaquah car service",
      "issaquah airport transportation",
      "issaquah wedding limo",
      "issaquah corporate transportation"
    ]
  },
  {
    name: "Woodinville",
    slug: "woodinville",
    county: "King County",
    zipCodes: ["98072", "98077"],
    population: 13069,
    medianIncome: 118750,
    distance: 20,
    coordinates: { lat: 47.7543, lng: -122.1632 },
    landmarks: [
      "Chateau Ste. Michelle",
      "Columbia Winery",
      "Redhook Brewery",
      "Hollywood Schoolhouse",
      "TPC Snoqualmie Ridge"
    ],
    neighborhoods: ["Downtown", "Wellington", "Trilogy at Redmond Ridge"],
    description: "Premier Woodinville limo service to TPC Snoqualmie Ridge golf events, wine country tours, Chateau Ste. Michelle, Columbia Winery, wedding venues, and corporate golf tournaments. Luxury transportation for PGA events and wine tasting tours throughout Woodinville wine country.",
    metaDescription: "Woodinville limo service from $140. Wine tour transportation, golf event limos, winery tours. Designated driver service. Book your tour!",
    keywords: [
      "woodinville limo service",
      "woodinville wine tour transportation",
      "woodinville winery limo",
      "chateau ste michelle transportation",
      "woodinville golf event limo"
    ]
  },
  {
    name: "Renton",
    slug: "renton",
    county: "King County",
    zipCodes: ["98055", "98056", "98057", "98058", "98059"],
    population: 105700,
    medianIncome: 101250,
    distance: 12,
    coordinates: { lat: 47.4829, lng: -122.2171 },
    landmarks: [
      "The Landing",
      "Gene Coulon Memorial Beach Park",
      "Renton Municipal Airport",
      "Boeing Renton Factory",
      "Henry Moses Aquatic Center"
    ],
    neighborhoods: ["Downtown", "Highlands", "Kennydale", "Fairwood", "East Renton"],
    description: "Reliable Renton limo service to Boeing facilities, The Landing shopping center, Renton hotels, corporate campuses, and SEA-TAC Airport transfers. Professional transportation throughout Fairwood, Highlands, and all Renton neighborhoods.",
    metaDescription: "Renton limo service from $100. Boeing transportation, airport transfers, corporate car service. All Renton ZIP codes. Book 24/7.",
    keywords: [
      "renton limo service",
      "renton car service",
      "renton airport transportation",
      "boeing renton transportation",
      "renton corporate limo"
    ]
  },
  {
    name: "Kent",
    slug: "kent",
    county: "King County",
    zipCodes: ["98030", "98031", "98032", "98035", "98042"],
    population: 136588,
    medianIncome: 100500,
    distance: 20,
    coordinates: { lat: 47.3809, lng: -122.2348 },
    landmarks: [
      "ShoWare Center",
      "Woodland Park",
      "Green River Natural Resources Area",
      "Kent Station",
      "accesso ShoWare Center"
    ],
    neighborhoods: ["Downtown", "East Hill", "West Hill", "Valley", "Panther Lake"],
    description: "Quality Kent limousine service to ShoWare Center events, Kent Station, corporate facilities, hotels, and event venues throughout Kent Valley. Professional airport transportation to SEA-TAC and Boeing Field.",
    metaDescription: "Kent limo service from $115. Event transportation, corporate car service, airport transfers. Serving all Kent ZIP codes. Book online!",
    keywords: [
      "kent limo service",
      "kent car service",
      "showare center transportation",
      "kent airport limo",
      "kent corporate transportation"
    ]
  },
  {
    name: "Auburn",
    slug: "auburn",
    county: "King County",
    zipCodes: ["98001", "98002", "98092"],
    population: 82446,
    medianIncome: 100250,
    distance: 25,
    coordinates: { lat: 47.3073, lng: -122.2285 },
    landmarks: [
      "White River Valley Museum",
      "Muckleshoot Casino",
      "Emerald Downs",
      "Game Farm Park",
      "Auburn Performing Arts Center"
    ],
    neighborhoods: ["Downtown", "Lea Hill", "West Hill", "Lakeland Hills"],
    description: "Elegant Auburn limo service to Muckleshoot Casino, Emerald Downs racing events, corporate events, and Auburn wedding venues. Luxury transportation for special occasions, casino trips, and horseracing events.",
    metaDescription: "Auburn limo service from $120. Casino transportation, Emerald Downs limos, corporate car service. All Auburn areas. Book 24/7!",
    keywords: [
      "auburn limo service",
      "muckleshoot casino transportation",
      "emerald downs limo",
      "auburn car service",
      "auburn wedding limo"
    ]
  },
  {
    name: "Federal Way",
    slug: "federal-way",
    county: "King County",
    zipCodes: ["98003", "98023", "98063"],
    population: 101030,
    medianIncome: 103750,
    distance: 25,
    coordinates: { lat: 47.3223, lng: -122.3126 },
    landmarks: [
      "Wild Waves Theme Park",
      "Dash Point State Park",
      "Celebration Park",
      "Kobayashi Park",
      "Weyerhaeuser Campus"
    ],
    neighborhoods: ["Steel Lake", "Twin Lakes", "Brooklake", "Campus"],
    description: "Premium Federal Way limousine service to hotels, The Commons shopping center, Wild Waves Theme Park, corporate locations, and SEA-TAC Airport. Professional family transportation and corporate car service.",
    metaDescription: "Federal Way limo service from $120. Theme park transportation, corporate car service, airport transfers. All ZIP codes. Book now!",
    keywords: [
      "federal way limo service",
      "federal way car service",
      "wild waves transportation",
      "federal way airport limo",
      "federal way corporate transportation"
    ]
  },
  // SNOHOMISH COUNTY
  {
    name: "Bothell",
    slug: "bothell",
    county: "Snohomish County",
    zipCodes: ["98011", "98012", "98021", "98041"],
    population: 47505,
    medianIncome: 112500,
    distance: 15,
    coordinates: { lat: 47.7623, lng: -122.2054 },
    landmarks: [
      "McMenamins Anderson School",
      "Bothell Landing",
      "Burke-Gilman Trail",
      "University of Washington Bothell",
      "North Creek Trail"
    ],
    neighborhoods: ["Downtown", "Canyon Park", "North Creek", "Queensborough"],
    description: "Luxury Bothell limousine service to McMenamins Anderson School, corporate campuses, hotels, University of Washington Bothell, and business events spanning King and Snohomish counties. Professional transportation throughout Canyon Park and North Creek business districts.",
    metaDescription: "Bothell limo service from $105. UW Bothell transportation, corporate car service, airport transfers. All Bothell ZIP codes. Book 24/7!",
    keywords: [
      "bothell limo service",
      "bothell car service",
      "uw bothell transportation",
      "bothell corporate limo",
      "bothell airport service"
    ]
  },
  {
    name: "Edmonds",
    slug: "edmonds",
    county: "Snohomish County",
    zipCodes: ["98020", "98026"],
    population: 42853,
    medianIncome: 104500,
    distance: 15,
    coordinates: { lat: 47.8107, lng: -122.3774 },
    landmarks: [
      "Edmonds Ferry Terminal",
      "Edmonds Underwater Park",
      "Brackett's Landing",
      "Olympic Beach",
      "Edmonds Center for the Arts"
    ],
    neighborhoods: ["Downtown", "Woodway", "Five Corners", "Bowl"],
    description: "Elegant Edmonds limo service to waterfront hotels, ferry terminal, downtown restaurants, wedding venues, and scenic waterfront events. Luxury transportation for special occasions, ferry connections, and waterfront dining.",
    metaDescription: "Edmonds limo service from $105. Waterfront transportation, ferry terminal service, wedding limos. ZIP 98020-98026. Book online!",
    keywords: [
      "edmonds limo service",
      "edmonds car service",
      "edmonds ferry transportation",
      "edmonds waterfront limo",
      "edmonds wedding transportation"
    ]
  },
  {
    name: "Lynnwood",
    slug: "lynnwood",
    county: "Snohomish County",
    zipCodes: ["98036", "98037", "98046", "98087"],
    population: 38568,
    medianIncome: 106250,
    distance: 12,
    coordinates: { lat: 47.8209, lng: -122.3151 },
    landmarks: [
      "Alderwood Mall",
      "Lynnwood Convention Center",
      "Wilcox Park",
      "Lynnwood Recreation Center",
      "Scriber Lake Park"
    ],
    neighborhoods: ["Alderwood", "Meadowdale", "Scriber Lake", "Martha Lake"],
    description: "Premium Lynnwood limousine service to Convention Center, Alderwood Mall, hotels, corporate facilities, and SEA-TAC Airport transfers. Professional business car service throughout Alderwood and all Lynnwood neighborhoods.",
    metaDescription: "Lynnwood limo service from $100. Convention center transportation, corporate car service, mall events. All ZIP codes. Book 24/7!",
    keywords: [
      "lynnwood limo service",
      "lynnwood car service",
      "lynnwood convention center transportation",
      "alderwood mall limo",
      "lynnwood airport service"
    ]
  },
  {
    name: "Everett",
    slug: "everett",
    county: "Snohomish County",
    zipCodes: ["98201", "98203", "98204", "98208"],
    population: 111475,
    medianIncome: 108750,
    distance: 30,
    coordinates: { lat: 47.979, lng: -122.2021 },
    landmarks: [
      "Boeing Factory Tour",
      "Paine Field Airport",
      "Everett Marina",
      "Schack Art Center",
      "Jetty Island",
      "Angel of the Winds Arena"
    ],
    neighborhoods: ["Downtown", "Port Gardner", "Riverside", "Silver Lake", "Rucker Hill"],
    description: "Professional Everett limousine service to Paine Field Airport, Boeing Everett Factory tours, Angel of the Winds Arena, waterfront hotels, and corporate events. Premium transportation for Boeing tours and Paine Field commercial flights.",
    metaDescription: "Everett limo service from $145. Boeing tour transportation, Paine Field airport service, arena events. All Everett ZIP codes. Book now!",
    keywords: [
      "everett limo service",
      "paine field transportation",
      "boeing tour limo",
      "everett car service",
      "angel of the winds transportation"
    ]
  },
  // PIERCE COUNTY
  {
    name: "Tacoma",
    slug: "tacoma",
    county: "Pierce County",
    zipCodes: ["98402", "98403", "98404", "98405", "98406", "98407", "98408", "98409"],
    population: 219346,
    medianIncome: 107500,
    distance: 35,
    coordinates: { lat: 47.2529, lng: -122.4443 },
    landmarks: [
      "Museum of Glass",
      "Point Defiance Park",
      "Tacoma Dome",
      "Ruston Way Waterfront",
      "Joint Base Lewis-McChord",
      "LeMay Car Museum",
      "Tacoma Art Museum"
    ],
    neighborhoods: ["Downtown", "Stadium District", "Old Town", "North End", "Proctor"],
    description: "Premier Tacoma limousine service to Joint Base Lewis-McChord (JBLM), military bases, Point Defiance Park, Museum of Glass, Tacoma Dome, downtown hotels, Convention Center, and SEA-TAC Airport. Military transport for service members, veterans, and defense contractors.",
    metaDescription: "Tacoma limo service from $145. JBLM military transportation, airport transfers, event limos. All Tacoma ZIP codes. 24/7 service!",
    keywords: [
      "tacoma limo service",
      "jblm transportation",
      "tacoma car service",
      "tacoma dome limo",
      "tacoma military transportation",
      "tacoma airport service"
    ]
  },
  {
    name: "Puyallup",
    slug: "puyallup",
    county: "Pierce County",
    zipCodes: ["98371", "98372", "98373", "98374"],
    population: 42973,
    medianIncome: 103750,
    distance: 40,
    coordinates: { lat: 47.1854, lng: -122.2929 },
    landmarks: [
      "Washington State Fair",
      "Ezra Meeker Mansion",
      "Pioneer Park",
      "Puyallup Fair & Events Center",
      "Bradley Lake"
    ],
    neighborhoods: ["Downtown", "South Hill", "Summit", "Firgrove"],
    description: "Quality Puyallup limousine service to Washington State Fair, downtown hotels, corporate events, casino transportation, and scenic valley locations. Airport transfers to SEA-TAC and special event transportation.",
    metaDescription: "Puyallup limo service from $150. State Fair transportation, corporate car service, airport transfers. All ZIP codes. Book your ride!",
    keywords: [
      "puyallup limo service",
      "washington state fair transportation",
      "puyallup car service",
      "puyallup airport limo",
      "puyallup event transportation"
    ]
  },
  {
    name: "Gig Harbor",
    slug: "gig-harbor",
    county: "Pierce County",
    zipCodes: ["98329", "98332", "98335"],
    population: 11301,
    medianIncome: 115e3,
    distance: 45,
    coordinates: { lat: 47.3295, lng: -122.5807 },
    landmarks: [
      "Gig Harbor Waterfront",
      "Harbor History Museum",
      "Sehmel Homestead Park",
      "Kopachuck State Park",
      "Canterwood Golf Club"
    ],
    neighborhoods: ["Downtown", "Artondale", "Wollochet", "Purdy"],
    description: "Elegant Gig Harbor limousine service to waterfront hotels, Harbor History Museum, Canterwood estates, wedding venues, and scenic peninsula destinations. Luxury transportation for special occasions and waterfront events.",
    metaDescription: "Gig Harbor limo service from $155. Waterfront transportation, wedding limos, corporate car service. All peninsula areas. Book now!",
    keywords: [
      "gig harbor limo service",
      "gig harbor car service",
      "gig harbor waterfront transportation",
      "canterwood limo",
      "gig harbor wedding transportation"
    ]
  },
  {
    name: "Olympia",
    slug: "olympia",
    county: "Thurston County",
    zipCodes: ["98501", "98502", "98503", "98506", "98512", "98513", "98516"],
    population: 55605,
    medianIncome: 108750,
    distance: 60,
    coordinates: { lat: 47.0379, lng: -122.9007 },
    landmarks: [
      "Washington State Capitol",
      "Percival Landing",
      "Tumwater Falls Park",
      "Billy Frank Jr. Nisqually Wildlife Refuge",
      "Hands On Children's Museum"
    ],
    neighborhoods: ["Downtown", "West Olympia", "Eastside", "Northeast"],
    description: "Premium Olympia limousine service to Washington State Capitol, government facilities, Percival Landing, hotels, corporate events, and SEA-TAC Airport. Professional transportation for state officials and business travelers.",
    metaDescription: "Olympia limo service from $165. State Capitol transportation, government car service, airport transfers. All Olympia ZIP codes. Book 24/7!",
    keywords: [
      "olympia limo service",
      "olympia car service",
      "washington state capitol transportation",
      "olympia airport limo",
      "olympia government transportation"
    ]
  }
];
function getLocationBySlug(slug) {
  return ENHANCED_LOCATIONS.find((loc) => loc.slug === slug);
}
function calculatePricing(distance) {
  const baseFare = 75;
  const perMile = 2;
  const sedan = baseFare + Math.round(distance * perMile);
  const suv = sedan + 35;
  return { sedan, suv };
}

const $$Astro = createAstro("https://emeraldcitylimos.com");
async function getStaticPaths() {
  return allLocations.map((location) => ({
    params: { slug: location.slug },
    props: { slug: location.slug }
  }));
}
const $$slug = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$slug;
  const { slug } = Astro2.props;
  const basicLocation = allLocations.find((loc) => loc.slug === slug);
  const enhancedLocation = getLocationBySlug(slug);
  const location = enhancedLocation || basicLocation;
  const pricing = enhancedLocation ? calculatePricing(enhancedLocation.distance) : null;
  return renderTemplate`${renderComponent($$result, "MainLayout", $$MainLayout, { "title": `${location.name} Limo Service | Luxury Car Service | Emerald City Limos`, "description": enhancedLocation ? enhancedLocation.metaDescription : `Premium limo service in ${location.name}. Airport transfers, corporate car service, weddings. Book 24/7.`, "keywords": enhancedLocation ? enhancedLocation.keywords.join(", ") : `${location.name} limo service, ${location.name} limousine, luxury transportation ${location.name}` }, { "default": ($$result2) => renderTemplate`  ${maybeRenderHead()}<section class="relative h-[500px] flex items-center justify-center overflow-hidden"> <div class="absolute inset-0 bg-gradient-to-r from-emerald-950/80 to-emerald-900/60 z-10"></div> <img src="/images/cad1.webp"${addAttribute(`${location.name} Limousine Service`, "alt")} class="absolute inset-0 w-full h-full object-cover" loading="eager"> <div class="relative z-20 text-center text-white max-w-4xl mx-auto px-4"> <h1 class="text-5xl md:text-6xl font-bold mb-4 drop-shadow-2xl"> ${location.name} <span class="text-[#d4af37]">Limo Service</span> </h1> ${enhancedLocation && renderTemplate`<p class="text-xl text-gray-200 drop-shadow-lg mb-2">${enhancedLocation.county}</p>`} <p class="text-lg text-gray-200 drop-shadow-lg mb-8">
Premium luxury transportation serving ${location.name} and surrounding areas
</p> <div class="flex flex-col sm:flex-row gap-4 justify-center"> <a href="/book-now" class="bg-[#d4af37] hover:bg-[#b8941f] text-black px-8 py-4 rounded-lg font-bold transition-all inline-block">
BOOK NOW
</a> <a href="tel:+12065959675" class="bg-transparent border-2 border-white hover:bg-white hover:text-emerald-900 text-white px-8 py-4 rounded-lg font-bold transition-all inline-block">
(206) 595-9675
</a> </div> </div> </section>  ${enhancedLocation && renderTemplate`<section class="py-10 bg-gradient-to-r from-emerald-900 to-emerald-800 text-white"> <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8"> <div class="grid grid-cols-2 md:grid-cols-4 gap-6 text-center"> <div class="bg-white/10 rounded-xl p-4"> <div class="text-3xl font-bold text-[#d4af37] mb-1">${enhancedLocation.distance}</div> <p class="text-gray-300 text-sm">Miles from Seattle</p> </div> <div class="bg-white/10 rounded-xl p-4"> <div class="text-3xl font-bold text-[#d4af37] mb-1">24/7</div> <p class="text-gray-300 text-sm">Available</p> </div> <div class="bg-white/10 rounded-xl p-4"> <div class="text-3xl font-bold text-[#d4af37] mb-1">${enhancedLocation.zipCodes.length}</div> <p class="text-gray-300 text-sm">ZIP Codes Covered</p> </div> <div class="bg-white/10 rounded-xl p-4"> <div class="text-3xl font-bold text-[#d4af37] mb-1"> <span class="text-yellow-400">★</span> 4.9
</div> <p class="text-gray-300 text-sm">Customer Rating</p> </div> </div> </div> </section>`} <section class="py-16 bg-white"> <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8"> <p class="text-xl text-gray-700 leading-relaxed mb-8"> ${enhancedLocation ? enhancedLocation.description : location.description} </p> ${enhancedLocation && enhancedLocation.landmarks.length > 0 && renderTemplate`<div class="bg-emerald-50 rounded-xl p-6 mb-6"> <h3 class="text-lg font-bold text-gray-900 mb-3">Key Landmarks We Serve</h3> <div class="flex flex-wrap gap-2"> ${enhancedLocation.landmarks.map((landmark) => renderTemplate`<span class="bg-white border border-emerald-200 text-emerald-800 px-3 py-1 rounded-full text-sm font-medium"> ${landmark} </span>`)} </div> </div>`} ${enhancedLocation && enhancedLocation.neighborhoods.length > 0 && renderTemplate`<div class="bg-gray-50 rounded-xl p-6"> <h3 class="text-lg font-bold text-gray-900 mb-3">Neighborhoods Covered</h3> <div class="flex flex-wrap gap-2"> ${enhancedLocation.neighborhoods.map((neighborhood) => renderTemplate`<span class="bg-white border border-gray-200 text-gray-700 px-3 py-1 rounded-full text-sm"> ${neighborhood} </span>`)} </div> </div>`} </div> </section>  ${pricing && renderTemplate`<section class="py-16 bg-gray-50"> <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8"> <div class="text-center mb-10"> <h2 class="text-4xl font-bold text-gray-900 mb-4">${location.name} Limo Service Pricing</h2> <p class="text-xl text-gray-600">Flat-rate pricing from ${location.name} to SeaTac Airport and beyond</p> </div> <div class="grid grid-cols-1 md:grid-cols-2 gap-6"> <div class="bg-white rounded-xl p-8 shadow-lg border-2 border-gray-200"> <div class="flex justify-between items-start mb-4"> <h3 class="text-xl font-bold text-gray-900">Executive Sedan</h3> <span class="text-gray-400"> <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"> <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z"></path> </svg> </span> </div> <div class="text-5xl font-bold text-emerald-700 mb-2">$${pricing.sedan}</div> <p class="text-gray-500 text-sm mb-6">Starting price to SeaTac Airport</p> <ul class="space-y-2 text-sm text-gray-600 mb-6"> <li class="flex items-center gap-2"><span class="text-emerald-700">✓</span> Up to 3 passengers</li> <li class="flex items-center gap-2"><span class="text-emerald-700">✓</span> Mercedes S-Class or similar</li> <li class="flex items-center gap-2"><span class="text-emerald-700">✓</span> Flight tracking included</li> <li class="flex items-center gap-2"><span class="text-emerald-700">✓</span> Meet and greet available</li> </ul> <a href="/book-now" class="block text-center bg-emerald-700 hover:bg-emerald-800 text-white py-3 rounded-lg font-semibold transition-all">
Book Sedan
</a> </div> <div class="bg-white rounded-xl p-8 shadow-lg border-2 border-[#d4af37] relative"> <div class="absolute -top-3 right-6"> <span class="bg-[#d4af37] text-black px-4 py-1 rounded-full text-sm font-bold">POPULAR</span> </div> <div class="flex justify-between items-start mb-4"> <h3 class="text-xl font-bold text-gray-900">Luxury SUV</h3> </div> <div class="text-5xl font-bold text-emerald-700 mb-2">$${pricing.suv}</div> <p class="text-gray-500 text-sm mb-6">Starting price to SeaTac Airport</p> <ul class="space-y-2 text-sm text-gray-600 mb-6"> <li class="flex items-center gap-2"><span class="text-emerald-700">✓</span> Up to 6 passengers</li> <li class="flex items-center gap-2"><span class="text-emerald-700">✓</span> Cadillac Escalade ESV</li> <li class="flex items-center gap-2"><span class="text-emerald-700">✓</span> Extra luggage space</li> <li class="flex items-center gap-2"><span class="text-emerald-700">✓</span> Flight tracking included</li> </ul> <a href="/book-now" class="block text-center bg-[#d4af37] hover:bg-[#b8941f] text-black py-3 rounded-lg font-semibold transition-all">
Book SUV
</a> </div> </div> <p class="text-center text-gray-500 text-sm mt-4">Prices are estimates. Get exact quote at booking.</p> </div> </section>`} <section class="py-16 bg-white"> <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8"> <h2 class="text-4xl font-bold text-center text-gray-900 mb-12">
Services Available in ${location.name} </h2> <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"> <div class="bg-white rounded-xl p-6 shadow-lg hover:shadow-xl transition-all"> <div class="w-16 h-16 bg-emerald-700 rounded-lg flex items-center justify-center mb-4"> <svg class="w-10 h-10 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"> <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 12h14M12 5l7 7-7 7"></path> </svg> </div> <h3 class="text-xl font-bold text-gray-900 mb-2">Airport Transfers</h3> <p class="text-gray-600 mb-4">Reliable transportation to/from SEA-TAC, Boeing Field, and Paine Field airports.</p> <a href="/airport-transfers" class="text-emerald-700 font-semibold hover:text-emerald-800">Learn More →</a> </div> <div class="bg-white rounded-xl p-6 shadow-lg hover:shadow-xl transition-all"> <div class="w-16 h-16 bg-emerald-700 rounded-lg flex items-center justify-center mb-4"> <svg class="w-10 h-10 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"> <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path> </svg> </div> <h3 class="text-xl font-bold text-gray-900 mb-2">Hourly Charters</h3> <p class="text-gray-600 mb-4">Flexible luxury transportation for business meetings, tours, and special events.</p> <a href="/service/hourly-charters" class="text-emerald-700 font-semibold hover:text-emerald-800">Learn More →</a> </div> <div class="bg-white rounded-xl p-6 shadow-lg hover:shadow-xl transition-all"> <div class="w-16 h-16 bg-emerald-700 rounded-lg flex items-center justify-center mb-4"> <svg class="w-10 h-10 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"> <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"></path> </svg> </div> <h3 class="text-xl font-bold text-gray-900 mb-2">Executive Transportation</h3> <p class="text-gray-600 mb-4">Professional chauffeur service for executives and business professionals.</p> <a href="/service/executive-transportation" class="text-emerald-700 font-semibold hover:text-emerald-800">Learn More →</a> </div> <div class="bg-white rounded-xl p-6 shadow-lg hover:shadow-xl transition-all"> <div class="w-16 h-16 bg-emerald-700 rounded-lg flex items-center justify-center mb-4"> <svg class="w-10 h-10 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"> <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"></path> </svg> </div> <h3 class="text-xl font-bold text-gray-900 mb-2">Wedding Transportation</h3> <p class="text-gray-600 mb-4">Elegant limousine service for your special day with champagne and red carpet.</p> <a href="/service/wedding-transportation" class="text-emerald-700 font-semibold hover:text-emerald-800">Learn More →</a> </div> <div class="bg-white rounded-xl p-6 shadow-lg hover:shadow-xl transition-all"> <div class="w-16 h-16 bg-emerald-700 rounded-lg flex items-center justify-center mb-4"> <svg class="w-10 h-10 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"> <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z"></path> </svg> </div> <h3 class="text-xl font-bold text-gray-900 mb-2">Special Occasions</h3> <p class="text-gray-600 mb-4">Luxury transportation for birthdays, proms, anniversaries, and celebrations.</p> <a href="/service/special-occasions" class="text-emerald-700 font-semibold hover:text-emerald-800">Learn More →</a> </div> <div class="bg-white rounded-xl p-6 shadow-lg hover:shadow-xl transition-all"> <div class="w-16 h-16 bg-emerald-700 rounded-lg flex items-center justify-center mb-4"> <svg class="w-10 h-10 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"> <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z"></path> </svg> </div> <h3 class="text-xl font-bold text-gray-900 mb-2">Game Day Transport</h3> <p class="text-gray-600 mb-4">Safe transportation to Seahawks, Mariners, Sounders, and Kraken games.</p> <a href="/service/game-day-transport" class="text-emerald-700 font-semibold hover:text-emerald-800">Learn More →</a> </div> </div> </div> </section>  ${enhancedLocation && enhancedLocation.zipCodes.length > 0 && renderTemplate`<section class="py-12 bg-gray-50"> <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center"> <h2 class="text-2xl font-bold text-gray-900 mb-4"> ${location.name} ZIP Codes We Serve
</h2> <div class="flex flex-wrap justify-center gap-3"> ${enhancedLocation.zipCodes.map((zip) => renderTemplate`<span class="bg-white border border-gray-200 text-gray-700 px-4 py-2 rounded-lg text-sm font-medium shadow-sm"> ${zip} </span>`)} </div> </div> </section>`} <section class="py-16 bg-white"> <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8"> <h2 class="text-4xl font-bold text-center text-gray-900 mb-12">
Why Choose Emerald City Limos in ${location.name} </h2> <div class="grid grid-cols-1 md:grid-cols-3 gap-8"> <div class="text-center"> <div class="w-20 h-20 bg-gradient-to-br from-emerald-700 to-emerald-600 rounded-full flex items-center justify-center mx-auto mb-4"> <svg class="w-10 h-10 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"> <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path> </svg> </div> <h3 class="text-2xl font-bold text-gray-900 mb-2">24/7 Availability</h3> <p class="text-gray-600">Round-the-clock service whenever you need us in ${location.name}</p> </div> <div class="text-center"> <div class="w-20 h-20 bg-gradient-to-br from-emerald-700 to-emerald-600 rounded-full flex items-center justify-center mx-auto mb-4"> <svg class="w-10 h-10 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"> <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"></path> </svg> </div> <h3 class="text-2xl font-bold text-gray-900 mb-2">Professional Chauffeurs</h3> <p class="text-gray-600">Experienced drivers familiar with all ${location.name} routes</p> </div> <div class="text-center"> <div class="w-20 h-20 bg-gradient-to-br from-emerald-700 to-emerald-600 rounded-full flex items-center justify-center mx-auto mb-4"> <svg class="w-10 h-10 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"> <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z"></path> </svg> </div> <h3 class="text-2xl font-bold text-gray-900 mb-2">Luxury Fleet</h3> <p class="text-gray-600">Premium vehicles maintained to the highest standards</p> </div> </div> </div> </section>  <section class="py-20 bg-gradient-to-r from-emerald-900 to-emerald-800 text-white"> <div class="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8"> <h2 class="text-4xl font-bold mb-6">Book Your ${location.name} Limo Service</h2> <p class="text-xl mb-8 text-gray-200">
Experience premium luxury transportation in ${location.name} </p> <div class="flex flex-col sm:flex-row gap-4 justify-center"> <a href="/book-now" class="bg-[#d4af37] hover:bg-[#b8941f] text-black px-8 py-4 rounded-lg font-semibold transition-all inline-block">
BOOK NOW
</a> <a href="tel:+12065959675" class="bg-transparent border-2 border-white hover:bg-white hover:text-emerald-900 text-white px-8 py-4 rounded-lg font-semibold transition-all inline-block">
Call: (206) 595-9675
</a> </div> </div> </section>  <section class="py-16 bg-white"> <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center"> <h2 class="text-3xl font-bold text-gray-900 mb-8">Other Locations We Serve</h2> <a href="/locations" class="inline-flex items-center text-emerald-700 hover:text-emerald-800 font-semibold text-lg">
View All Locations
<svg class="ml-2 w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"> <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 8l4 4m0 0l-4 4m4-4H3"></path> </svg> </a> </div> </section> ` })}`;
}, "/home/josh/Documents/emerald-update/src/pages/location/[slug].astro", void 0);

const $$file = "/home/josh/Documents/emerald-update/src/pages/location/[slug].astro";
const $$url = "/location/[slug]";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$slug,
  file: $$file,
  getStaticPaths,
  url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };

import { a as createComponent, b as renderComponent, r as renderTemplate } from '../../chunks/astro/server_owM8yI1X.mjs';
import 'piccolore';
import { $ as $$MainLayout } from '../../chunks/MainLayout_DKPM6Kn3.mjs';
import { $ as $$PageHero, a as $$TrustStrip } from '../../chunks/TrustStrip_D24AF8bj.mjs';
import { $ as $$AirportQuickStats, a as $$AirportIntro, b as $$AirportRoutes, c as $$AirportPickupInfo, d as $$AirportFAQ, e as $$AirportCTA, f as $$AirportSchema } from '../../chunks/AirportSchema_BKrELUXj.mjs';
import { g as getAirport } from '../../chunks/airports_Bk5YNRFV.mjs';
export { renderers } from '../../renderers.mjs';

const $$BoeingField = createComponent(($$result, $$props, $$slots) => {
  const airport = getAirport("boeing-field");
  if (!airport) throw new Error('Airport "boeing-field" not found in src/data/airports.ts');
  return renderTemplate`${renderComponent($$result, "MainLayout", $$MainLayout, { "title": airport.meta.title, "description": airport.meta.description, "keywords": airport.meta.keywords.join(", ") }, { "default": ($$result2) => renderTemplate` ${renderComponent($$result2, "PageHero", $$PageHero, { "eyebrow": airport.eyebrow, "headline": airport.headline, "headlineAccent": airport.headlineAccent, "supporting": airport.heroSupporting, "ctaPrimary": { label: `Book ${airport.code} Transfer`, href: "https://customer.moovs.app/a1-charters-1/new/info", id: `cta-${airport.slug}-book` }, "ctaSecondary": {
    label: "Get a Quote",
    href: "tel:+12065959675",
    id: `cta-${airport.slug}-call`,
    phone: "(206) 595-9675"
  }, "image": airport.heroImage, "size": "page", "id": `${airport.slug}-hero`, "breadcrumbs": [{ label: "Home", href: "/" }, { label: "Airports", href: "/airport" }, { label: airport.name }] })} ${renderComponent($$result2, "TrustStrip", $$TrustStrip, {})} ${renderComponent($$result2, "AirportQuickStats", $$AirportQuickStats, { "airport": airport })} ${renderComponent($$result2, "AirportIntro", $$AirportIntro, { "airport": airport })} ${renderComponent($$result2, "AirportRoutes", $$AirportRoutes, { "airport": airport })} ${renderComponent($$result2, "AirportPickupInfo", $$AirportPickupInfo, { "airport": airport })} ${renderComponent($$result2, "AirportFAQ", $$AirportFAQ, { "airport": airport })} ${renderComponent($$result2, "AirportCTA", $$AirportCTA, { "airport": airport })} ${renderComponent($$result2, "AirportSchema", $$AirportSchema, { "airport": airport })} ` })}`;
}, "/home/josh/Documents/emerald-update/src/pages/airport/boeing-field.astro", void 0);

const $$file = "/home/josh/Documents/emerald-update/src/pages/airport/boeing-field.astro";
const $$url = "/airport/boeing-field";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$BoeingField,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };

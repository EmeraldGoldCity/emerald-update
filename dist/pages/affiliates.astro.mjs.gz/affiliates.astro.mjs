import { a as createComponent, b as renderComponent, r as renderTemplate } from '../chunks/astro/server_Cr-soRLN.mjs';
import 'piccolore';
import { $ as $$MainLayout } from '../chunks/MainLayout_BeVVz_FQ.mjs';
import { jsx, Fragment, jsxs } from 'react/jsx-runtime';
import * as React from 'react';
import { useState } from 'react';
import { cva } from 'class-variance-authority';
import { clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';
import 'react-dom';
import { c as createLucideIcon, M as Mail, P as Phone } from '../chunks/Footer_QzGe42d0.mjs';
export { renderers } from '../renderers.mjs';

/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const __iconNode$3 = [
  ["rect", { width: "16", height: "20", x: "4", y: "2", rx: "2", ry: "2", key: "76otgf" }],
  ["path", { d: "M9 22v-4h6v4", key: "r93iot" }],
  ["path", { d: "M8 6h.01", key: "1dz90k" }],
  ["path", { d: "M16 6h.01", key: "1x0f13" }],
  ["path", { d: "M12 6h.01", key: "1vi96p" }],
  ["path", { d: "M12 10h.01", key: "1nrarc" }],
  ["path", { d: "M12 14h.01", key: "1etili" }],
  ["path", { d: "M16 10h.01", key: "1m94wz" }],
  ["path", { d: "M16 14h.01", key: "1gbofw" }],
  ["path", { d: "M8 10h.01", key: "19clt8" }],
  ["path", { d: "M8 14h.01", key: "6423bh" }]
];
const Building = createLucideIcon("building", __iconNode$3);

/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const __iconNode$2 = [
  ["path", { d: "M21.801 10A10 10 0 1 1 17 3.335", key: "yps3ct" }],
  ["path", { d: "m9 11 3 3L22 4", key: "1pflzl" }]
];
const CircleCheckBig = createLucideIcon("circle-check-big", __iconNode$2);

/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const __iconNode$1 = [
  ["path", { d: "M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z", key: "1rqfz7" }],
  ["path", { d: "M14 2v4a2 2 0 0 0 2 2h4", key: "tnqrlb" }],
  ["path", { d: "M10 9H8", key: "b1mrlr" }],
  ["path", { d: "M16 13H8", key: "t4e002" }],
  ["path", { d: "M16 17H8", key: "z1uh3a" }]
];
const FileText = createLucideIcon("file-text", __iconNode$1);

/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const __iconNode = [
  ["path", { d: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4", key: "ih7n3h" }],
  ["polyline", { points: "17 8 12 3 7 8", key: "t8dd8p" }],
  ["line", { x1: "12", x2: "12", y1: "3", y2: "15", key: "widbto" }]
];
const Upload = createLucideIcon("upload", __iconNode);

// packages/react/compose-refs/src/composeRefs.tsx
function setRef(ref, value) {
  if (typeof ref === "function") {
    return ref(value);
  } else if (ref !== null && ref !== void 0) {
    ref.current = value;
  }
}
function composeRefs(...refs) {
  return (node) => {
    let hasCleanup = false;
    const cleanups = refs.map((ref) => {
      const cleanup = setRef(ref, node);
      if (!hasCleanup && typeof cleanup == "function") {
        hasCleanup = true;
      }
      return cleanup;
    });
    if (hasCleanup) {
      return () => {
        for (let i = 0; i < cleanups.length; i++) {
          const cleanup = cleanups[i];
          if (typeof cleanup == "function") {
            cleanup();
          } else {
            setRef(refs[i], null);
          }
        }
      };
    }
  };
}

// packages/react/slot/src/slot.tsx
var Slot = React.forwardRef((props, forwardedRef) => {
  const { children, ...slotProps } = props;
  const childrenArray = React.Children.toArray(children);
  const slottable = childrenArray.find(isSlottable);
  if (slottable) {
    const newElement = slottable.props.children;
    const newChildren = childrenArray.map((child) => {
      if (child === slottable) {
        if (React.Children.count(newElement) > 1) return React.Children.only(null);
        return React.isValidElement(newElement) ? newElement.props.children : null;
      } else {
        return child;
      }
    });
    return /* @__PURE__ */ jsx(SlotClone, { ...slotProps, ref: forwardedRef, children: React.isValidElement(newElement) ? React.cloneElement(newElement, void 0, newChildren) : null });
  }
  return /* @__PURE__ */ jsx(SlotClone, { ...slotProps, ref: forwardedRef, children });
});
Slot.displayName = "Slot";
var SlotClone = React.forwardRef((props, forwardedRef) => {
  const { children, ...slotProps } = props;
  if (React.isValidElement(children)) {
    const childrenRef = getElementRef(children);
    const props2 = mergeProps(slotProps, children.props);
    if (children.type !== React.Fragment) {
      props2.ref = forwardedRef ? composeRefs(forwardedRef, childrenRef) : childrenRef;
    }
    return React.cloneElement(children, props2);
  }
  return React.Children.count(children) > 1 ? React.Children.only(null) : null;
});
SlotClone.displayName = "SlotClone";
var Slottable = ({ children }) => {
  return /* @__PURE__ */ jsx(Fragment, { children });
};
function isSlottable(child) {
  return React.isValidElement(child) && child.type === Slottable;
}
function mergeProps(slotProps, childProps) {
  const overrideProps = { ...childProps };
  for (const propName in childProps) {
    const slotPropValue = slotProps[propName];
    const childPropValue = childProps[propName];
    const isHandler = /^on[A-Z]/.test(propName);
    if (isHandler) {
      if (slotPropValue && childPropValue) {
        overrideProps[propName] = (...args) => {
          childPropValue(...args);
          slotPropValue(...args);
        };
      } else if (slotPropValue) {
        overrideProps[propName] = slotPropValue;
      }
    } else if (propName === "style") {
      overrideProps[propName] = { ...slotPropValue, ...childPropValue };
    } else if (propName === "className") {
      overrideProps[propName] = [slotPropValue, childPropValue].filter(Boolean).join(" ");
    }
  }
  return { ...slotProps, ...overrideProps };
}
function getElementRef(element) {
  let getter = Object.getOwnPropertyDescriptor(element.props, "ref")?.get;
  let mayWarn = getter && "isReactWarning" in getter && getter.isReactWarning;
  if (mayWarn) {
    return element.ref;
  }
  getter = Object.getOwnPropertyDescriptor(element, "ref")?.get;
  mayWarn = getter && "isReactWarning" in getter && getter.isReactWarning;
  if (mayWarn) {
    return element.props.ref;
  }
  return element.props.ref || element.ref;
}

function cn(...inputs) {
  return twMerge(clsx(inputs));
}

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-all disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg:not([class*='size-'])]:size-4 shrink-0 [&_svg]:shrink-0 outline-none focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:ring-[3px] aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive",
  {
    variants: {
      variant: {
        default: "bg-primary text-primary-foreground hover:bg-primary/90",
        destructive: "bg-destructive text-white hover:bg-destructive/90 focus-visible:ring-destructive/20 dark:focus-visible:ring-destructive/40 dark:bg-destructive/60",
        outline: "border bg-background text-foreground hover:bg-accent hover:text-accent-foreground dark:bg-input/30 dark:border-input dark:hover:bg-input/50",
        secondary: "bg-secondary text-secondary-foreground hover:bg-secondary/80",
        ghost: "hover:bg-accent hover:text-accent-foreground dark:hover:bg-accent/50",
        link: "text-primary underline-offset-4 hover:underline"
      },
      size: {
        default: "h-9 px-4 py-2 has-[>svg]:px-3",
        sm: "h-8 rounded-md gap-1.5 px-3 has-[>svg]:px-2.5",
        lg: "h-10 rounded-md px-6 has-[>svg]:px-4",
        icon: "size-9 rounded-md"
      }
    },
    defaultVariants: {
      variant: "default",
      size: "default"
    }
  }
);
function Button({
  className,
  variant,
  size,
  asChild = false,
  ...props
}) {
  const Comp = asChild ? Slot : "button";
  return /* @__PURE__ */ jsx(
    Comp,
    {
      "data-slot": "button",
      className: cn(buttonVariants({ variant, size, className })),
      ...props
    }
  );
}

function Input({ className, type, ...props }) {
  return /* @__PURE__ */ jsx(
    "input",
    {
      type,
      "data-slot": "input",
      className: cn(
        "file:text-foreground placeholder:text-muted-foreground selection:bg-primary selection:text-primary-foreground dark:bg-input/30 border-input flex h-9 w-full min-w-0 rounded-md border px-3 py-1 text-base bg-input-background transition-[color,box-shadow] outline-none file:inline-flex file:h-7 file:border-0 file:bg-transparent file:text-sm file:font-medium disabled:pointer-events-none disabled:cursor-not-allowed disabled:opacity-50 md:text-sm",
        "focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:ring-[3px]",
        "aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive",
        className
      ),
      ...props
    }
  );
}

// packages/react/primitive/src/primitive.tsx
var NODES = [
  "a",
  "button",
  "div",
  "form",
  "h2",
  "h3",
  "img",
  "input",
  "label",
  "li",
  "nav",
  "ol",
  "p",
  "span",
  "svg",
  "ul"
];
var Primitive = NODES.reduce((primitive, node) => {
  const Node = React.forwardRef((props, forwardedRef) => {
    const { asChild, ...primitiveProps } = props;
    const Comp = asChild ? Slot : node;
    if (typeof window !== "undefined") {
      window[Symbol.for("radix-ui")] = true;
    }
    return /* @__PURE__ */ jsx(Comp, { ...primitiveProps, ref: forwardedRef });
  });
  Node.displayName = `Primitive.${node}`;
  return { ...primitive, [node]: Node };
}, {});

var NAME = "Label";
var Label$1 = React.forwardRef((props, forwardedRef) => {
  return /* @__PURE__ */ jsx(
    Primitive.label,
    {
      ...props,
      ref: forwardedRef,
      onMouseDown: (event) => {
        const target = event.target;
        if (target.closest("button, input, select, textarea")) return;
        props.onMouseDown?.(event);
        if (!event.defaultPrevented && event.detail > 1) event.preventDefault();
      }
    }
  );
});
Label$1.displayName = NAME;
var Root = Label$1;

function Label({
  className,
  ...props
}) {
  return /* @__PURE__ */ jsx(
    Root,
    {
      "data-slot": "label",
      className: cn(
        "flex items-center gap-2 text-sm leading-none font-medium select-none group-data-[disabled=true]:pointer-events-none group-data-[disabled=true]:opacity-50 peer-disabled:cursor-not-allowed peer-disabled:opacity-50",
        className
      ),
      ...props
    }
  );
}

function AffiliatesPage() {
  const [formData, setFormData] = useState({
    companyName: "",
    dotNumber: "",
    email: "",
    phone: ""
  });
  const [insuranceFile, setInsuranceFile] = useState(null);
  const [submitted, setSubmitted] = useState(false);
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };
  const handleFileChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      setInsuranceFile(e.target.files[0]);
    }
  };
  const handleSubmit = (e) => {
    e.preventDefault();
    setSubmitted(true);
    setTimeout(() => {
      setSubmitted(false);
      setFormData({ companyName: "", dotNumber: "", email: "", phone: "" });
      setInsuranceFile(null);
    }, 3e3);
  };
  const benefits = [
    "Access to our premium client base",
    "Competitive commission structure",
    "Marketing and promotional support",
    "Flexible partnership terms",
    "Professional training provided",
    "Dedicated affiliate support team"
  ];
  return /* @__PURE__ */ jsxs("div", { className: "min-h-screen bg-white", children: [
    /* @__PURE__ */ jsx("section", { className: "bg-gradient-to-r from-emerald-900 to-emerald-800 text-white py-20", children: /* @__PURE__ */ jsxs("div", { className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center", children: [
      /* @__PURE__ */ jsxs("h1", { className: "text-5xl md:text-6xl font-bold mb-6", children: [
        /* @__PURE__ */ jsx("span", { className: "text-[#d4af37]", children: "Affiliate" }),
        " Program"
      ] }),
      /* @__PURE__ */ jsx("p", { className: "text-xl text-gray-200 max-w-3xl mx-auto", children: "Join our network of transportation partners and grow your business with Emerald City Limos" })
    ] }) }),
    /* @__PURE__ */ jsx("section", { className: "py-20", children: /* @__PURE__ */ jsx("div", { className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8", children: /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 lg:grid-cols-2 gap-12", children: [
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx("h2", { className: "text-3xl font-bold text-gray-900 mb-6", children: "Why Partner With Us?" }),
        /* @__PURE__ */ jsx("p", { className: "text-lg text-gray-700 mb-6", children: "Emerald City Limos is looking for professional transportation companies to join our affiliate network. As a partner, you'll gain access to our extensive client base and benefit from our reputation for excellence in luxury transportation." }),
        /* @__PURE__ */ jsx("h3", { className: "text-2xl font-bold text-gray-900 mb-4", children: "Partnership Benefits" }),
        /* @__PURE__ */ jsx("div", { className: "space-y-3 mb-8", children: benefits.map((benefit, index) => /* @__PURE__ */ jsxs("div", { className: "flex items-start space-x-3", children: [
          /* @__PURE__ */ jsx(CircleCheckBig, { className: "w-6 h-6 text-emerald-700 mt-1 flex-shrink-0" }),
          /* @__PURE__ */ jsx("span", { className: "text-gray-700 text-lg", children: benefit })
        ] }, index)) }),
        /* @__PURE__ */ jsxs("div", { className: "bg-gradient-to-br from-emerald-50 to-yellow-50 border-2 border-emerald-200 rounded-xl p-6", children: [
          /* @__PURE__ */ jsx("h4", { className: "text-xl font-bold text-gray-900 mb-3", children: "Requirements" }),
          /* @__PURE__ */ jsxs("ul", { className: "space-y-2 text-gray-700", children: [
            /* @__PURE__ */ jsxs("li", { className: "flex items-start space-x-2", children: [
              /* @__PURE__ */ jsx("span", { className: "text-emerald-700", children: "•" }),
              /* @__PURE__ */ jsx("span", { children: "Valid DOT number" })
            ] }),
            /* @__PURE__ */ jsxs("li", { className: "flex items-start space-x-2", children: [
              /* @__PURE__ */ jsx("span", { className: "text-emerald-700", children: "•" }),
              /* @__PURE__ */ jsx("span", { children: "Current commercial insurance" })
            ] }),
            /* @__PURE__ */ jsxs("li", { className: "flex items-start space-x-2", children: [
              /* @__PURE__ */ jsx("span", { className: "text-emerald-700", children: "•" }),
              /* @__PURE__ */ jsx("span", { children: "Professional chauffeurs" })
            ] }),
            /* @__PURE__ */ jsxs("li", { className: "flex items-start space-x-2", children: [
              /* @__PURE__ */ jsx("span", { className: "text-emerald-700", children: "•" }),
              /* @__PURE__ */ jsx("span", { children: "Quality fleet maintenance" })
            ] }),
            /* @__PURE__ */ jsxs("li", { className: "flex items-start space-x-2", children: [
              /* @__PURE__ */ jsx("span", { className: "text-emerald-700", children: "•" }),
              /* @__PURE__ */ jsx("span", { children: "Commitment to excellence" })
            ] })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsxs("div", { className: "bg-white border-2 border-gray-200 rounded-xl p-8 shadow-xl", children: [
          /* @__PURE__ */ jsx("h3", { className: "text-2xl font-bold text-gray-900 mb-6", children: "Affiliate Application" }),
          submitted ? /* @__PURE__ */ jsxs("div", { className: "bg-emerald-50 border-2 border-emerald-500 rounded-lg p-6 text-center", children: [
            /* @__PURE__ */ jsx(CircleCheckBig, { className: "w-16 h-16 text-emerald-600 mx-auto mb-4" }),
            /* @__PURE__ */ jsx("h4", { className: "text-xl font-bold text-gray-900 mb-2", children: "Application Submitted!" }),
            /* @__PURE__ */ jsx("p", { className: "text-gray-700", children: "Thank you for your interest. We'll review your application and contact you within 2-3 business days." })
          ] }) : /* @__PURE__ */ jsxs("form", { onSubmit: handleSubmit, className: "space-y-6", children: [
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsxs(Label, { htmlFor: "companyName", className: "flex items-center space-x-2 mb-2", children: [
                /* @__PURE__ */ jsx(Building, { className: "w-4 h-4" }),
                /* @__PURE__ */ jsx("span", { children: "Company Name *" })
              ] }),
              /* @__PURE__ */ jsx(
                Input,
                {
                  id: "companyName",
                  name: "companyName",
                  type: "text",
                  value: formData.companyName,
                  onChange: handleInputChange,
                  required: true,
                  placeholder: "Enter your company name",
                  className: "w-full"
                }
              )
            ] }),
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsxs(Label, { htmlFor: "dotNumber", className: "flex items-center space-x-2 mb-2", children: [
                /* @__PURE__ */ jsx(FileText, { className: "w-4 h-4" }),
                /* @__PURE__ */ jsx("span", { children: "DOT Number *" })
              ] }),
              /* @__PURE__ */ jsx(
                Input,
                {
                  id: "dotNumber",
                  name: "dotNumber",
                  type: "text",
                  value: formData.dotNumber,
                  onChange: handleInputChange,
                  required: true,
                  placeholder: "Enter your DOT number",
                  className: "w-full"
                }
              )
            ] }),
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsxs(Label, { htmlFor: "email", className: "flex items-center space-x-2 mb-2", children: [
                /* @__PURE__ */ jsx(Mail, { className: "w-4 h-4" }),
                /* @__PURE__ */ jsx("span", { children: "Email Address *" })
              ] }),
              /* @__PURE__ */ jsx(
                Input,
                {
                  id: "email",
                  name: "email",
                  type: "email",
                  value: formData.email,
                  onChange: handleInputChange,
                  required: true,
                  placeholder: "company@example.com",
                  className: "w-full"
                }
              )
            ] }),
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsxs(Label, { htmlFor: "phone", className: "flex items-center space-x-2 mb-2", children: [
                /* @__PURE__ */ jsx(Phone, { className: "w-4 h-4" }),
                /* @__PURE__ */ jsx("span", { children: "Phone Number *" })
              ] }),
              /* @__PURE__ */ jsx(
                Input,
                {
                  id: "phone",
                  name: "phone",
                  type: "tel",
                  value: formData.phone,
                  onChange: handleInputChange,
                  required: true,
                  placeholder: "(555) 123-4567",
                  className: "w-full"
                }
              )
            ] }),
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsxs(Label, { htmlFor: "insurance", className: "flex items-center space-x-2 mb-2", children: [
                /* @__PURE__ */ jsx(Upload, { className: "w-4 h-4" }),
                /* @__PURE__ */ jsx("span", { children: "Insurance Certificate *" })
              ] }),
              /* @__PURE__ */ jsx(
                Input,
                {
                  id: "insurance",
                  type: "file",
                  onChange: handleFileChange,
                  required: true,
                  accept: ".pdf,.jpg,.jpeg,.png",
                  className: "w-full"
                }
              ),
              /* @__PURE__ */ jsx("p", { className: "text-sm text-gray-500 mt-2", children: "Upload your current insurance certificate (PDF, JPG, or PNG)" }),
              insuranceFile && /* @__PURE__ */ jsxs("p", { className: "text-sm text-emerald-700 mt-2", children: [
                "Selected: ",
                insuranceFile.name
              ] })
            ] }),
            /* @__PURE__ */ jsx(
              Button,
              {
                type: "submit",
                className: "w-full bg-emerald-700 hover:bg-emerald-800 text-white py-6 text-lg",
                children: "Submit Application"
              }
            ),
            /* @__PURE__ */ jsx("p", { className: "text-xs text-gray-500 text-center", children: "By submitting this form, you agree to our terms and conditions for affiliate partnerships." })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "mt-6 bg-gray-50 rounded-lg p-6", children: [
          /* @__PURE__ */ jsx("h4", { className: "font-bold text-gray-900 mb-3", children: "Questions?" }),
          /* @__PURE__ */ jsx("p", { className: "text-gray-700 text-sm mb-4", children: "Contact our affiliate team for more information about partnership opportunities." }),
          /* @__PURE__ */ jsxs("div", { className: "space-y-2 text-sm", children: [
            /* @__PURE__ */ jsxs("a", { href: "tel:+12065959675", className: "flex items-center space-x-2 text-emerald-700 hover:text-emerald-800", children: [
              /* @__PURE__ */ jsx(Phone, { className: "w-4 h-4" }),
              /* @__PURE__ */ jsx("span", { children: "(206) 595-9675" })
            ] }),
            /* @__PURE__ */ jsxs("a", { href: "mailto:client@emeraldcitylimos.com", className: "flex items-center space-x-2 text-emerald-700 hover:text-emerald-800", children: [
              /* @__PURE__ */ jsx(Mail, { className: "w-4 h-4" }),
              /* @__PURE__ */ jsx("span", { children: "client@emeraldcitylimos.com" })
            ] })
          ] })
        ] })
      ] })
    ] }) }) })
  ] });
}

const $$Affiliates = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "MainLayout", $$MainLayout, { "title": "Affiliate Program | Partner With Emerald City Limos", "description": "Join the Emerald City Limos affiliate network. Partner with Seattle's premier luxury transportation company and grow your business.", "keywords": "limo affiliate program seattle, transportation partner program, emerald city limos affiliate" }, { "default": ($$result2) => renderTemplate` ${renderComponent($$result2, "AffiliatesPage", AffiliatesPage, { "client:load": true, "client:component-hydration": "load", "client:component-path": "@/app/pages/AffiliatesPage", "client:component-export": "AffiliatesPage" })} ` })}`;
}, "/home/josh/Documents/emerald-update/src/pages/affiliates.astro", void 0);

const $$file = "/home/josh/Documents/emerald-update/src/pages/affiliates.astro";
const $$url = "/affiliates";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$Affiliates,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };

import { a as createComponent, r as renderTemplate, u as unescapeHTML, b as renderComponent, m as maybeRenderHead, d as addAttribute } from '../chunks/astro/server_owM8yI1X.mjs';
import 'piccolore';
import { $ as $$MainLayout } from '../chunks/MainLayout_DKPM6Kn3.mjs';
import { s as sanityClient, b as BLOG_LIST_QUERY, u as urlFor } from '../chunks/sanity_DfKDg59q.mjs';
export { renderers } from '../renderers.mjs';

var __freeze = Object.freeze;
var __defProp = Object.defineProperty;
var __template = (cooked, raw) => __freeze(__defProp(cooked, "raw", { value: __freeze(cooked.slice()) }));
var _a;
const $$Index = createComponent(async ($$result, $$props, $$slots) => {
  const posts = await sanityClient.fetch(BLOG_LIST_QUERY);
  function formatDate(iso) {
    return new Date(iso).toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric"
    });
  }
  return renderTemplate(_a || (_a = __template(["", ' <script type="application/ld+json">', "<\/script>"])), renderComponent($$result, "MainLayout", $$MainLayout, { "title": "Blog | Emerald City Limos \u2014 Seattle Luxury Transportation", "description": "Travel tips, chauffeur insights, and luxury transportation guides for Seattle, Bellevue, and the greater Pacific Northwest.", "keywords": "seattle limo blog, chauffeur tips, luxury transportation seattle, black car service blog", "canonical": "https://emeraldcitylimos.com/blog" }, { "default": async ($$result2) => renderTemplate`  ${maybeRenderHead()}<section class="bg-brand-forest py-16 sm:py-20 px-6 sm:px-8"> <div class="max-w-6xl mx-auto"> <div class="flex items-center gap-4 mb-6"> <div class="h-px w-10 bg-brand-gold shrink-0" aria-hidden="true"></div> <p class="font-sans text-[10px] sm:text-[11px] font-semibold tracking-[0.22em] uppercase text-brand-gold">
Insights & Guides
</p> </div> <h1 class="font-display font-light text-white leading-[1.08] tracking-[-0.025em] max-w-2xl" style="font-size: clamp(2rem, 4vw, 3.25rem);">
The Emerald City Limos
<em class="italic text-brand-gold"> Journal</em> </h1> <p class="mt-4 font-sans font-light text-white/50 text-sm leading-relaxed max-w-lg">
Travel tips, airport guides, and chauffeur insights for Seattle's most demanding travellers.
</p> </div> </section>  <section class="bg-white py-16 sm:py-20 px-6 sm:px-8" aria-label="Blog posts"> <div class="max-w-6xl mx-auto"> ${posts.length === 0 ? renderTemplate`<p class="font-sans text-neutral-400 text-center py-20">No posts published yet.</p>` : renderTemplate`<ul class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8" role="list"> ${posts.map((post) => renderTemplate`<li role="listitem"> <article class="group flex flex-col h-full bg-white ring-1 ring-brand-forest/10 hover:ring-brand-gold/40 transition-shadow duration-300 hover:shadow-lg"> <!-- Image --> <a${addAttribute(`/blog/${post.slug.current}`, "href")} class="block overflow-hidden aspect-[16/9] bg-brand-champagne"${addAttribute(`Read: ${post.title}`, "aria-label")} tabindex="-1"> ${post.mainImage?.asset ? renderTemplate`<img${addAttribute(urlFor(post.mainImage).width(640).height(360).auto("format").url(), "src")}${addAttribute(post.mainImage.alt ?? post.title, "alt")} width="640" height="360" loading="lazy" decoding="async" class="w-full h-full object-cover transition-transform duration-500 group-hover:scale-[1.03]">` : renderTemplate`<div class="w-full h-full flex items-center justify-center"> <span class="font-display font-light text-brand-forest/20 text-4xl" aria-hidden="true">ECL</span> </div>`} </a> <!-- Content --> <div class="flex flex-col flex-1 p-6"> <!-- Categories --> ${post.categories && post.categories.length > 0 && renderTemplate`<div class="flex flex-wrap gap-2 mb-3"> ${post.categories.slice(0, 2).map((cat) => renderTemplate`<span class="font-sans text-[9px] font-semibold tracking-[0.18em] uppercase text-brand-gold"> ${cat.title} </span>`)} </div>`} <!-- Title --> <h2 class="font-display font-light text-brand-forest leading-[1.2] mb-3" style="font-size: 1.125rem;"> <a${addAttribute(`/blog/${post.slug.current}`, "href")} class="hover:text-brand-gold transition-colors duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-gold"> ${post.title} </a> </h2> <!-- Excerpt --> ${post.excerpt && renderTemplate`<p class="font-sans font-light text-neutral-500 text-sm leading-[1.75] mb-4 flex-1 line-clamp-3"> ${post.excerpt} </p>`} <!-- Meta --> <div class="flex items-center justify-between mt-auto pt-4 border-t border-brand-forest/[.08]"> <time${addAttribute(post.publishedAt, "datetime")} class="font-sans text-[10px] font-medium tracking-[0.1em] text-neutral-400 uppercase"> ${formatDate(post.publishedAt)} </time> ${post.readingTime && renderTemplate`<span class="font-sans text-[10px] text-neutral-400"> ${post.readingTime} min read
</span>`} </div> </div> </article> </li>`)} </ul>`} </div> </section> ` }), unescapeHTML(JSON.stringify({
    "@context": "https://schema.org",
    "@type": "Blog",
    "@id": "https://emeraldcitylimos.com/blog",
    url: "https://emeraldcitylimos.com/blog",
    name: "Emerald City Limos Journal",
    description: "Travel tips, chauffeur insights, and luxury transportation guides for Seattle and the Pacific Northwest.",
    publisher: {
      "@type": "Organization",
      name: "Emerald City Limos",
      url: "https://emeraldcitylimos.com"
    }
  })));
}, "/home/josh/Documents/emerald-update/src/pages/blog/index.astro", void 0);

const $$file = "/home/josh/Documents/emerald-update/src/pages/blog/index.astro";
const $$url = "/blog";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$Index,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };

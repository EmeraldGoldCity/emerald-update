import { c as createComponent, a as renderTemplate, u as unescapeHTML, r as renderComponent, m as maybeRenderHead, F as Fragment } from '../chunks/astro/server_aszwXi13.mjs';
import 'piccolore';
import { $ as $$MainLayout } from '../chunks/MainLayout_DrPNvm8W.mjs';
import { s as sanityClient, F as FEATURED_POST_QUERY, b as POSTS_COUNT_QUERY, P as PAGINATED_POSTS_QUERY, a as PAGE_SIZE, $ as $$PostCard } from '../chunks/PostCard_CTh8mdoc.mjs';
import { $ as $$FeaturedPost, a as $$Pagination } from '../chunks/Pagination_0VhreF3j.mjs';
export { renderers } from '../renderers.mjs';

var __freeze = Object.freeze;
var __defProp = Object.defineProperty;
var __template = (cooked, raw) => __freeze(__defProp(cooked, "raw", { value: __freeze(cooked.slice()) }));
var _a;
const $$Index = createComponent(async ($$result, $$props, $$slots) => {
  const featuredPost = await sanityClient.fetch(FEATURED_POST_QUERY);
  const featuredId = featuredPost?._id ?? null;
  const totalCount = await sanityClient.fetch(POSTS_COUNT_QUERY, { featuredId });
  const totalPages = Math.max(1, Math.ceil(totalCount / PAGE_SIZE));
  const posts = await sanityClient.fetch(PAGINATED_POSTS_QUERY, {
    featuredId,
    start: 0,
    end: PAGE_SIZE
  });
  return renderTemplate(_a || (_a = __template(["", ' <script type="application/ld+json">', "<\/script>"])), renderComponent($$result, "MainLayout", $$MainLayout, { "title": "Blog | Emerald City Limos \u2014 Seattle Luxury Transportation", "description": "Travel tips, chauffeur insights, and luxury transportation guides for Seattle, Bellevue, and the greater Pacific Northwest.", "keywords": "seattle limo blog, chauffeur tips, luxury transportation seattle, black car service blog", "canonical": "https://emeraldcitylimos.com/blog" }, { "default": async ($$result2) => renderTemplate`  ${maybeRenderHead()}<section class="bg-brand-forest py-16 sm:py-20 px-6 sm:px-8"> <div class="max-w-6xl mx-auto"> <div class="flex items-center gap-4 mb-6"> <div class="h-px w-10 bg-brand-gold shrink-0" aria-hidden="true"></div> <p class="font-sans text-[10px] sm:text-[11px] font-semibold tracking-[0.22em] uppercase text-brand-gold">
Insights & Guides
</p> </div> <h1 class="font-display font-light text-white leading-[1.08] tracking-[-0.025em] max-w-2xl" style="font-size: clamp(2rem, 4vw, 3.25rem);">
The Emerald City Limos
<em class="italic text-brand-gold"> Journal</em> </h1> <p class="mt-4 font-sans font-light text-white/50 text-sm leading-relaxed max-w-lg">
Travel tips, airport guides, and chauffeur insights for Seattle's most demanding travellers.
</p> </div> </section>  ${featuredPost && renderTemplate`<section class="bg-white pt-12 pb-0 px-6 sm:px-8" aria-label="Featured article"> <div class="max-w-6xl mx-auto"> <div class="flex items-center gap-4 mb-6"> <div class="h-px w-10 bg-brand-gold shrink-0" aria-hidden="true"></div> <p class="font-sans text-[10px] font-semibold tracking-[0.22em] uppercase text-brand-gold">
Featured
</p> </div> ${renderComponent($$result2, "FeaturedPost", $$FeaturedPost, { "post": featuredPost })} </div> </section>`} <section class="bg-white py-16 sm:py-20 px-6 sm:px-8" aria-label="Blog posts"> <div class="max-w-6xl mx-auto"> ${posts.length === 0 && !featuredPost ? renderTemplate`<p class="font-sans text-neutral-400 text-center py-20">No posts published yet.</p>` : posts.length > 0 ? renderTemplate`${renderComponent($$result2, "Fragment", Fragment, {}, { "default": async ($$result3) => renderTemplate` <ul class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8" role="list"> ${posts.map((post) => renderTemplate`<li role="listitem"> ${renderComponent($$result3, "PostCard", $$PostCard, { "post": post })} </li>`)} </ul> ${renderComponent($$result3, "Pagination", $$Pagination, { "currentPage": 1, "totalPages": totalPages })} ` })}` : null} </div> </section> ` }), unescapeHTML(JSON.stringify({
    "@context": "https://schema.org",
    "@type": "Blog",
    "@id": "https://emeraldcitylimos.com/blog",
    url: "https://emeraldcitylimos.com/blog",
    name: "Emerald City Limos Journal",
    description: "Travel tips, chauffeur insights, and luxury transportation guides for Seattle and the Pacific Northwest.",
    publisher: {
      "@type": "Organization",
      name: "Emerald City Limos",
      url: "https://emeraldcitylimos.com"
    }
  })));
}, "/home/josh/Documents/emerald-update/src/pages/blog/index.astro", void 0);

const $$file = "/home/josh/Documents/emerald-update/src/pages/blog/index.astro";
const $$url = "/blog";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$Index,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };

import { a as createComponent, m as maybeRenderHead, d as addAttribute, b as renderComponent, r as renderTemplate } from '../chunks/astro/server_owM8yI1X.mjs';
import 'piccolore';
import { $ as $$MainLayout } from '../chunks/MainLayout_DKPM6Kn3.mjs';
import { b as $$Image, $ as $$PageHero, a as $$TrustStrip } from '../chunks/TrustStrip_D24AF8bj.mjs';
import { f as fleet, a as fleetHeroBg } from '../chunks/fleet_By0VELwI.mjs';
export { renderers } from '../renderers.mjs';

const $$FleetGrid = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<section class="bg-brand-champagne py-16 sm:py-20 lg:py-24" aria-labelledby="fleet-grid-heading"> <div class="mx-auto max-w-7xl px-6 sm:px-8 lg:px-12"> <div class="mb-12 max-w-2xl sm:mb-14"> <div class="mb-4 flex items-center gap-3"> <span class="h-px w-8 bg-brand-gold" aria-hidden="true"></span> <p class="font-sans text-[10px] font-semibold uppercase tracking-[0.22em] text-brand-gold">
The Fleet
</p> </div> <h2 id="fleet-grid-heading" class="font-display font-light leading-[1.08] text-brand-forest" style="font-size: clamp(1.85rem, 3.4vw, 2.5rem); letter-spacing: -0.01em;">
Choose the right
<em class="italic text-brand-gold">vehicle.</em> </h2> </div> <ul role="list" class="m-0 grid list-none grid-cols-1 gap-5 p-0 sm:grid-cols-2 lg:grid-cols-3"> ${fleet.map((vehicle) => renderTemplate`<li class="m-0 p-0"> <a${addAttribute(vehicle.href, "href")} class="group relative flex h-full flex-col overflow-hidden border border-brand-forest/8 bg-white outline-none transition-[border-color,box-shadow,transform] duration-300 hover:border-brand-gold/45 hover:shadow-[0_24px_48px_-32px_rgba(10,35,24,0.28)] focus-visible:border-brand-gold focus-visible:ring-2 focus-visible:ring-brand-gold focus-visible:ring-offset-2 focus-visible:ring-offset-brand-champagne motion-reduce:transition-none"${addAttribute(`${vehicle.name} \u2014 ${vehicle.category}, ${vehicle.capacityLabel.toLowerCase()}`, "aria-label")}> <!-- Image area (4:3) --> <div class="relative aspect-[4/3] w-full overflow-hidden bg-brand-forest"> ${vehicle.imageSrc ? renderTemplate`${renderComponent($$result, "Image", $$Image, { "src": vehicle.imageSrc, "alt": vehicle.imageAlt, "loading": "lazy", "decoding": "async", "width": 800, "height": 600, "class": "absolute inset-0 h-full w-full object-cover object-center transition-transform duration-500 ease-out group-hover:scale-[1.03]" })}` : renderTemplate`<div class="absolute inset-0 flex items-center justify-center" aria-hidden="true"> <span class="absolute inset-0" style="background: radial-gradient(ellipse 60% 55% at center, var(--color-brand-gold-soft) 0%, transparent 70%); opacity: 0.18;"></span> <span class="font-display text-3xl italic text-brand-gold-soft/70"> ${vehicle.category} </span> </div>`} <span class="absolute left-3 top-3 inline-flex items-center gap-1.5 bg-brand-forest/85 px-2 py-1 font-sans text-[0.65rem] font-semibold uppercase tracking-[0.16em] text-brand-gold-soft backdrop-blur-sm"> ${vehicle.category} </span> <span class="absolute bottom-3 right-3 inline-flex items-center gap-1.5 bg-white/85 px-2 py-1 font-sans text-[0.7rem] font-semibold tabular-nums text-brand-forest backdrop-blur-sm"> ${vehicle.capacityLabel} </span> </div> <!-- Body --> <div class="flex flex-1 flex-col gap-3 p-5"> <h3 class="font-display text-xl font-medium leading-tight text-brand-forest"> ${vehicle.name} </h3> <ul role="list" class="m-0 list-none space-y-1 p-0"> ${vehicle.features.slice(0, 3).map((feature) => renderTemplate`<li class="flex items-start gap-2 font-sans text-[0.78rem] leading-snug text-brand-forest/70"> <span class="mt-1.5 inline-block h-1 w-1 shrink-0 rounded-full bg-brand-gold" aria-hidden="true"></span> ${feature} </li>`)} </ul> <span class="mt-auto inline-flex items-center gap-1.5 pt-2 font-sans text-[0.72rem] font-semibold uppercase tracking-[0.18em] text-brand-gold transition-colors group-hover:text-brand-gold-soft">
View vehicle
<svg viewBox="0 0 20 20" fill="currentColor" class="h-3 w-3 transition-transform duration-300 group-hover:translate-x-0.5" aria-hidden="true"> <path fill-rule="evenodd" d="M3 10a.75.75 0 0 1 .75-.75h10.638L10.23 5.29a.75.75 0 1 1 1.04-1.08l5.5 5.25a.75.75 0 0 1 0 1.08l-5.5 5.25a.75.75 0 1 1-1.04-1.08l4.158-3.96H3.75A.75.75 0 0 1 3 10Z" clip-rule="evenodd"></path> </svg> </span> </div> </a> </li>`)} </ul> </div> </section>`;
}, "/home/josh/Documents/emerald-update/src/components/fleet/FleetGrid.astro", void 0);

const $$Fleet = createComponent(($$result, $$props, $$slots) => {
  const stats = [
    { value: "9", label: "Vehicles in service" },
    { value: "3\u201357", label: "Passenger range" },
    { value: "$1.5M", label: "Liability coverage" },
    { value: "24/7", label: "Dispatch availability" }
  ];
  return renderTemplate`${renderComponent($$result, "MainLayout", $$MainLayout, { "title": "Luxury Fleet Seattle | Emerald City Limos", "description": "Explore the Emerald City Limos fleet \u2014 Cadillac Escalade ESV, Mercedes S-Class, Sprinter, motorcoaches and more. Licensed Washington carrier, $1.5M insured, 24/7.", "keywords": "seattle luxury fleet, cadillac escalade limo, mercedes sprinter seattle, seattle motorcoach, seattle party bus" }, { "default": ($$result2) => renderTemplate` ${renderComponent($$result2, "PageHero", $$PageHero, { "eyebrow": "The Fleet", "headline": "Premium vehicles,", "headlineAccent": "meticulously maintained", "supporting": "From Cadillac Escalades and Mercedes S-Class sedans to Sprinter executive vans, minibuses, and motorcoaches \u2014 for parties of 3 to 57, every vehicle is detailed and safety-checked between every ride.", "image": {
    src: fleetHeroBg,
    alt: "Emerald City Limos luxury fleet \u2014 Cadillac Escalade with Seattle skyline backdrop"
  }, "size": "page", "id": "fleet-hero", "breadcrumbs": [{ label: "Home", href: "/" }, { label: "Fleet" }] })} ${renderComponent($$result2, "TrustStrip", $$TrustStrip, {})} ${renderComponent($$result2, "FleetGrid", $$FleetGrid, {})}  ${maybeRenderHead()}<section class="relative overflow-hidden bg-brand-forest py-16 text-brand-champagne sm:py-20 lg:py-24" aria-labelledby="fleet-trust-heading"> <div class="pointer-events-none absolute inset-0" style="background: radial-gradient(ellipse 60% 50% at 50% 0%, rgba(163,126,44,0.16) 0%, transparent 70%);" aria-hidden="true"></div> <div class="relative mx-auto max-w-7xl px-6 sm:px-8 lg:px-12"> <div class="mb-12 text-center sm:mb-14"> <div class="mb-3 flex items-center justify-center gap-3"> <span class="h-px w-8 bg-brand-gold-soft" aria-hidden="true"></span> <p class="font-sans text-[10px] font-semibold uppercase tracking-[0.22em] text-brand-gold-soft">
Fleet Standards
</p> <span class="h-px w-8 bg-brand-gold-soft" aria-hidden="true"></span> </div> <h2 id="fleet-trust-heading" class="font-display font-light leading-[1.1] text-white" style="font-size: clamp(1.85rem, 3.8vw, 2.6rem); letter-spacing: -0.01em;">
Licensed, insured,
<em class="italic text-brand-gold-soft">and inspected.</em> </h2> </div> <ul role="list" class="m-0 grid list-none grid-cols-2 gap-px overflow-hidden border border-white/8 bg-white/8 p-0 lg:grid-cols-4"> ${stats.map((stat) => renderTemplate`<li class="flex flex-col items-center justify-center gap-2 bg-brand-forest px-6 py-10 text-center sm:py-12"> <p class="font-display text-3xl font-light tabular-nums text-brand-gold-soft sm:text-4xl"> ${stat.value} </p> <p class="font-sans text-[0.72rem] font-semibold uppercase tracking-[0.18em] text-white/70"> ${stat.label} </p> </li>`)} </ul> </div> </section>  <section class="relative overflow-hidden bg-brand-champagne py-16 sm:py-20 lg:py-24" aria-labelledby="fleet-cta-heading"> <div class="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-brand-gold/25 to-transparent" aria-hidden="true"></div> <div class="relative mx-auto max-w-3xl px-6 text-center sm:px-8 lg:px-12"> <div class="mb-3 flex items-center justify-center gap-3"> <span class="h-px w-8 bg-brand-gold" aria-hidden="true"></span> <p class="font-sans text-[10px] font-semibold uppercase tracking-[0.22em] text-brand-gold">
Reserve Now
</p> <span class="h-px w-8 bg-brand-gold" aria-hidden="true"></span> </div> <h2 id="fleet-cta-heading" class="mb-4 font-display font-light leading-[1.1] text-brand-forest" style="font-size: clamp(1.85rem, 3.8vw, 2.6rem); letter-spacing: -0.01em;">
Pick a vehicle.
<em class="italic text-brand-gold">We'll handle the rest.</em> </h2> <p class="mx-auto mb-8 max-w-xl font-sans text-[0.98rem] font-light leading-relaxed text-brand-forest/75">
Online in under two minutes, or call dispatch — a human picks up,
        every hour of every day.
</p> <div class="flex flex-col items-stretch justify-center gap-3 sm:flex-row sm:items-center sm:gap-4" role="group" aria-label="Book or call"> <a href="https://customer.moovs.app/a1-charters-1/new/info" target="_blank" rel="noopener noreferrer" class="inline-flex min-h-[52px] items-center justify-center gap-2 border border-brand-gold bg-brand-gold px-8 font-sans text-[11px] font-semibold uppercase tracking-[0.2em] text-brand-forest outline-none transition-[background-color,box-shadow] duration-200 hover:bg-brand-gold-soft hover:shadow-[0_12px_28px_-12px_rgba(163,126,44,0.5)] focus-visible:ring-2 focus-visible:ring-brand-gold focus-visible:ring-offset-2 focus-visible:ring-offset-brand-champagne motion-reduce:transition-none">
Reserve a Ride
<span aria-hidden="true">→</span> </a> <a href="tel:+12065959675" class="inline-flex min-h-[52px] items-center justify-center gap-2 border border-brand-forest/25 bg-white px-8 font-sans text-[11px] font-semibold uppercase tracking-[0.2em] text-brand-forest outline-none transition-colors duration-200 hover:border-brand-gold focus-visible:ring-2 focus-visible:ring-brand-gold focus-visible:ring-offset-2 focus-visible:ring-offset-brand-champagne motion-reduce:transition-none" aria-label="Call Emerald City Limos at (206) 595-9675, available 24 hours"> <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" width="14" height="14" class="text-brand-gold" aria-hidden="true"> <path d="M2.25 6.75c0 8.284 6.716 15 15 15h2.25a2.25 2.25 0 0 0 2.25-2.25v-1.372c0-.516-.351-.966-.852-1.091l-4.423-1.106c-.44-.11-.902.055-1.173.417l-.97 1.293c-.282.376-.769.542-1.21.38a12.035 12.035 0 0 1-7.143-7.143c-.162-.441.004-.928.38-1.21l1.293-.97c.363-.271.527-.734.417-1.173L6.963 3.102a1.125 1.125 0 0 0-1.091-.852H4.5A2.25 2.25 0 0 0 2.25 4.5v2.25Z"></path> </svg> <span class="tabular-nums">(206) 595-9675</span> </a> </div> </div> </section> ` })}`;
}, "/home/josh/Documents/emerald-update/src/pages/fleet.astro", void 0);

const $$file = "/home/josh/Documents/emerald-update/src/pages/fleet.astro";
const $$url = "/fleet";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$Fleet,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };

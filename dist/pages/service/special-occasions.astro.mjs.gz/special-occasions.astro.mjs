import { a as createComponent, b as renderComponent, r as renderTemplate } from '../../chunks/astro/server_owM8yI1X.mjs';
import 'piccolore';
import { $ as $$MainLayout } from '../../chunks/MainLayout_C6Pe07EU.mjs';
import { $ as $$PageHero, a as $$TrustStrip } from '../../chunks/TrustStrip_D24AF8bj.mjs';
import { $ as $$ServiceIntro, a as $$ServiceFleetMatch, b as $$ServiceFAQ, c as $$ServiceLocations, d as $$ServiceCTA, e as $$ServiceSchema } from '../../chunks/ServiceSchema_CWHL_NDk.mjs';
import { g as getService } from '../../chunks/services_C3iUx6dv.mjs';
export { renderers } from '../../renderers.mjs';

const $$SpecialOccasions = createComponent(($$result, $$props, $$slots) => {
  const service = getService("special-occasions");
  if (!service) throw new Error('Service "special-occasions" not found in src/data/services.ts');
  return renderTemplate`${renderComponent($$result, "MainLayout", $$MainLayout, { "title": service.meta.title, "description": service.meta.description, "keywords": service.meta.keywords.join(", ") }, { "default": ($$result2) => renderTemplate` ${renderComponent($$result2, "PageHero", $$PageHero, { "eyebrow": service.eyebrow, "headline": service.headline, "headlineAccent": service.headlineAccent, "supporting": service.heroSupporting, "ctaPrimary": { label: "Reserve a Ride", href: "https://customer.moovs.app/a1-charters-1/new/info", id: `cta-${service.slug}-book` }, "image": service.heroImage, "size": "page", "id": `${service.slug}-hero`, "breadcrumbs": [{ label: "Home", href: "/" }, { label: "Services", href: "/services" }, { label: service.name }] })} ${renderComponent($$result2, "TrustStrip", $$TrustStrip, {})} ${renderComponent($$result2, "ServiceIntro", $$ServiceIntro, { "service": service })} ${renderComponent($$result2, "ServiceFleetMatch", $$ServiceFleetMatch, { "service": service })} ${renderComponent($$result2, "ServiceFAQ", $$ServiceFAQ, { "service": service })} ${renderComponent($$result2, "ServiceLocations", $$ServiceLocations, { "service": service })} ${renderComponent($$result2, "ServiceCTA", $$ServiceCTA, { "service": service })} ${renderComponent($$result2, "ServiceSchema", $$ServiceSchema, { "service": service })} ` })}`;
}, "/home/josh/Documents/emerald-update/src/pages/service/special-occasions.astro", void 0);

const $$file = "/home/josh/Documents/emerald-update/src/pages/service/special-occasions.astro";
const $$url = "/service/special-occasions";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$SpecialOccasions,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };

import { a as createComponent, b as renderComponent, r as renderTemplate } from '../../chunks/astro/server_Cr-soRLN.mjs';
import 'piccolore';
import { $ as $$MainLayout } from '../../chunks/MainLayout_BHrzvkR-.mjs';
import { $ as $$PageHero, a as $$TrustStrip } from '../../chunks/TrustStrip_Dq_tv6BA.mjs';
import { $ as $$ServiceIntro, a as $$ServiceFleetMatch, b as $$ServiceFAQ, c as $$ServiceCTA, d as $$ServiceSchema } from '../../chunks/ServiceSchema_CE1U53WT.mjs';
import { g as getService } from '../../chunks/services_CjdIbWe5.mjs';
export { renderers } from '../../renderers.mjs';

const $$HourlyCharters = createComponent(($$result, $$props, $$slots) => {
  const service = getService("hourly-charters");
  if (!service) throw new Error('Service "hourly-charters" not found in src/data/services.ts');
  return renderTemplate`${renderComponent($$result, "MainLayout", $$MainLayout, { "title": service.meta.title, "description": service.meta.description, "keywords": service.meta.keywords.join(", ") }, { "default": ($$result2) => renderTemplate` ${renderComponent($$result2, "PageHero", $$PageHero, { "eyebrow": service.eyebrow, "headline": service.headline, "headlineAccent": service.headlineAccent, "supporting": service.heroSupporting, "ctaPrimary": { label: "Reserve a Ride", href: "/book-now", id: `cta-${service.slug}-book` }, "image": service.heroImage, "size": "page", "id": `${service.slug}-hero`, "breadcrumbs": [{ label: "Home", href: "/" }, { label: "Services", href: "/services" }, { label: service.name }] })} ${renderComponent($$result2, "TrustStrip", $$TrustStrip, {})} ${renderComponent($$result2, "ServiceIntro", $$ServiceIntro, { "service": service })} ${renderComponent($$result2, "ServiceFleetMatch", $$ServiceFleetMatch, { "service": service })} ${renderComponent($$result2, "ServiceFAQ", $$ServiceFAQ, { "service": service })} ${renderComponent($$result2, "ServiceCTA", $$ServiceCTA, { "service": service })} ${renderComponent($$result2, "ServiceSchema", $$ServiceSchema, { "service": service })} ` })}`;
}, "/home/josh/Documents/emerald-update/src/pages/service/hourly-charters.astro", void 0);

const $$file = "/home/josh/Documents/emerald-update/src/pages/service/hourly-charters.astro";
const $$url = "/service/hourly-charters";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$HourlyCharters,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };

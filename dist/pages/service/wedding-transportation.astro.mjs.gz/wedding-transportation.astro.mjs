import { c as createComponent, r as renderComponent, a as renderTemplate, m as maybeRenderHead } from '../../chunks/astro/server_DL3Tye_C.mjs';
import 'piccolore';
import { $ as $$MainLayout } from '../../chunks/MainLayout_B3UWJLyy.mjs';
import { $ as $$PageHero, a as $$TrustStrip } from '../../chunks/TrustStrip_B_sgXsCD.mjs';
export { renderers } from '../../renderers.mjs';

const $$WeddingTransportation = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "MainLayout", $$MainLayout, { "title": "Wedding Transportation - Emerald City Limos Seattle", "description": "Elegant wedding limousine service in Seattle. Red carpet service, champagne, professional chauffeurs, and luxury vehicles for your special day.", "keywords": "wedding limo seattle, wedding transportation seattle, wedding car service seattle, bridal transportation, emerald city limos wedding" }, { "default": ($$result2) => renderTemplate` ${renderComponent($$result2, "PageHero", $$PageHero, { "eyebrow": "Weddings", "headline": "Wedding", "headlineAccent": "Transportation", "supporting": "Red-carpet arrivals, bridal-party logistics handled like a venue coordinator. Pacific Northwest weddings deserve chauffeurs who think two steps ahead \u2014 and dress the part.", "ctaPrimary": { label: "Book Wedding Transport", href: "/book-now", id: "cta-wedding-book" }, "image": {
    src: "https://images.unsplash.com/photo-1507309270028-9121e9937409?w=1920&h=1080&fit=crop&q=80",
    alt: "Bride arriving at wedding venue in elegant white luxury limousine"
  }, "size": "page", "id": "wedding-hero" })} ${renderComponent($$result2, "TrustStrip", $$TrustStrip, {})} ${maybeRenderHead()}<section class="py-16 bg-white"> <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8"> <p class="text-xl text-gray-700 leading-relaxed">
Your wedding day deserves nothing less than perfection. Our elegant wedding limousines provide luxurious transportation for the wedding party, family, and guests. From the ceremony to the reception and beyond, we ensure every moment is magical.
</p> </div> </section> <section class="py-16 bg-gray-50"> <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8"> <div class="grid grid-cols-1 lg:grid-cols-2 gap-12"> <div> <h2 class="text-3xl font-bold text-gray-900 mb-6">Service Features</h2> <div class="bg-white rounded-xl p-8 shadow-lg"> <ul class="space-y-3"> <li class="flex items-start space-x-3"> <span class="text-emerald-700 text-2xl">✓</span> <span class="text-gray-700">White stretch limousines</span> </li> <li class="flex items-start space-x-3"> <span class="text-emerald-700 text-2xl">✓</span> <span class="text-gray-700">Decorated vehicles upon request</span> </li> <li class="flex items-start space-x-3"> <span class="text-emerald-700 text-2xl">✓</span> <span class="text-gray-700">Red carpet service</span> </li> <li class="flex items-start space-x-3"> <span class="text-emerald-700 text-2xl">✓</span> <span class="text-gray-700">Complimentary champagne</span> </li> <li class="flex items-start space-x-3"> <span class="text-emerald-700 text-2xl">✓</span> <span class="text-gray-700">Professional uniformed chauffeurs</span> </li> <li class="flex items-start space-x-3"> <span class="text-emerald-700 text-2xl">✓</span> <span class="text-gray-700">Ribbons and bows</span> </li> <li class="flex items-start space-x-3"> <span class="text-emerald-700 text-2xl">✓</span> <span class="text-gray-700">"Just Married" signs available</span> </li> <li class="flex items-start space-x-3"> <span class="text-emerald-700 text-2xl">✓</span> <span class="text-gray-700">Flexible timing for photos</span> </li> </ul> </div> </div> <div> <h2 class="text-3xl font-bold text-gray-900 mb-6">Why Choose This Service</h2> <div class="bg-white rounded-xl p-8 shadow-lg"> <ul class="space-y-3"> <li class="flex items-start space-x-3"> <div class="w-6 h-6 rounded-full bg-[#d4af37] flex items-center justify-center flex-shrink-0 mt-0.5"> <span class="text-white text-sm font-bold">✓</span> </div> <span class="text-gray-700">Arrive in style and elegance</span> </li> <li class="flex items-start space-x-3"> <div class="w-6 h-6 rounded-full bg-[#d4af37] flex items-center justify-center flex-shrink-0 mt-0.5"> <span class="text-white text-sm font-bold">✓</span> </div> <span class="text-gray-700">Keep the wedding party together</span> </li> <li class="flex items-start space-x-3"> <div class="w-6 h-6 rounded-full bg-[#d4af37] flex items-center justify-center flex-shrink-0 mt-0.5"> <span class="text-white text-sm font-bold">✓</span> </div> <span class="text-gray-700">Professional photography opportunities</span> </li> <li class="flex items-start space-x-3"> <div class="w-6 h-6 rounded-full bg-[#d4af37] flex items-center justify-center flex-shrink-0 mt-0.5"> <span class="text-white text-sm font-bold">✓</span> </div> <span class="text-gray-700">Stress-free transportation</span> </li> <li class="flex items-start space-x-3"> <div class="w-6 h-6 rounded-full bg-[#d4af37] flex items-center justify-center flex-shrink-0 mt-0.5"> <span class="text-white text-sm font-bold">✓</span> </div> <span class="text-gray-700">Punctual and reliable service</span> </li> <li class="flex items-start space-x-3"> <div class="w-6 h-6 rounded-full bg-[#d4af37] flex items-center justify-center flex-shrink-0 mt-0.5"> <span class="text-white text-sm font-bold">✓</span> </div> <span class="text-gray-700">Create unforgettable memories</span> </li> </ul> </div> </div> </div> </div> </section> <section class="py-20 bg-gradient-to-r from-emerald-900 to-emerald-800 text-white"> <div class="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8"> <h2 class="text-4xl font-bold mb-6">Ready to Book Wedding Transportation?</h2> <p class="text-xl mb-8 text-gray-200">
Contact us today to reserve your luxury wedding limousine
</p> <div class="flex flex-col sm:flex-row gap-4 justify-center"> <a href="/book-now" class="bg-[#d4af37] hover:bg-[#b8941f] text-black px-8 py-4 rounded-lg font-semibold transition-all">
BOOK NOW
</a> <a href="tel:+12065959675" class="bg-transparent border-2 border-white hover:bg-white hover:text-emerald-900 text-white px-8 py-4 rounded-lg font-semibold transition-all">
Call: (206) 595-9675
</a> </div> </div> </section> ` })}`;
}, "/home/josh/Documents/emerald-update/src/pages/service/wedding-transportation.astro", void 0);

const $$file = "/home/josh/Documents/emerald-update/src/pages/service/wedding-transportation.astro";
const $$url = "/service/wedding-transportation";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$WeddingTransportation,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };

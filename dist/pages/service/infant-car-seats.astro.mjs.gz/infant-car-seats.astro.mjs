import { a as createComponent, b as renderComponent, r as renderTemplate } from '../../chunks/astro/server_owM8yI1X.mjs';
import 'piccolore';
import { $ as $$MainLayout } from '../../chunks/MainLayout_DKPM6Kn3.mjs';
import { $ as $$PageHero, a as $$TrustStrip } from '../../chunks/TrustStrip_D24AF8bj.mjs';
import { $ as $$ServiceIntro, a as $$ServiceFleetMatch, b as $$ServiceFAQ, c as $$ServiceCTA, d as $$ServiceSchema } from '../../chunks/ServiceSchema_CICECCru.mjs';
import { g as getService } from '../../chunks/services_CeNJA2ly.mjs';
export { renderers } from '../../renderers.mjs';

const $$InfantCarSeats = createComponent(($$result, $$props, $$slots) => {
  const service = getService("infant-car-seats");
  if (!service) throw new Error('Service "infant-car-seats" not found in src/data/services.ts');
  return renderTemplate`${renderComponent($$result, "MainLayout", $$MainLayout, { "title": service.meta.title, "description": service.meta.description, "keywords": service.meta.keywords.join(", ") }, { "default": ($$result2) => renderTemplate` ${renderComponent($$result2, "PageHero", $$PageHero, { "eyebrow": service.eyebrow, "headline": service.headline, "headlineAccent": service.headlineAccent, "supporting": service.heroSupporting, "ctaPrimary": { label: "Reserve a Ride", href: "https://customer.moovs.app/a1-charters-1/new/info", id: `cta-${service.slug}-book` }, "image": service.heroImage, "size": "page", "id": `${service.slug}-hero`, "breadcrumbs": [{ label: "Home", href: "/" }, { label: "Services", href: "/services" }, { label: service.name }] })} ${renderComponent($$result2, "TrustStrip", $$TrustStrip, {})} ${renderComponent($$result2, "ServiceIntro", $$ServiceIntro, { "service": service })} ${renderComponent($$result2, "ServiceFleetMatch", $$ServiceFleetMatch, { "service": service })} ${renderComponent($$result2, "ServiceFAQ", $$ServiceFAQ, { "service": service })} ${renderComponent($$result2, "ServiceCTA", $$ServiceCTA, { "service": service })} ${renderComponent($$result2, "ServiceSchema", $$ServiceSchema, { "service": service })} ` })}`;
}, "/home/josh/Documents/emerald-update/src/pages/service/infant-car-seats.astro", void 0);

const $$file = "/home/josh/Documents/emerald-update/src/pages/service/infant-car-seats.astro";
const $$url = "/service/infant-car-seats";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$InfantCarSeats,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };

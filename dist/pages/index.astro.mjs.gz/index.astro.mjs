import { c as createAstro, a as createComponent, m as maybeRenderHead, b as renderComponent, r as renderTemplate, d as addAttribute } from '../chunks/astro/server_Cr-soRLN.mjs';
import 'piccolore';
import { $ as $$PageHero, a as $$TrustStrip, b as $$Image } from '../chunks/TrustStrip_BQ1W8xK4.mjs';
import { $ as $$MainLayout } from '../chunks/MainLayout_DkzFgEQf.mjs';
import { f as fleet, c as fleetCategoryTabs } from '../chunks/fleet_B_nO1wAE.mjs';
import { $ as $$FleetCard } from '../chunks/FleetCard_MXN8Ly--.mjs';
import { jsx, jsxs } from 'react/jsx-runtime';
import { useState, useRef, useEffect } from 'react';
/* empty css                                 */
import { a as aboutImage } from '../chunks/about_CTfBA9NS.mjs';
export { renderers } from '../renderers.mjs';

function FleetFilterTabs({
  tabs,
  initial = "All",
  layoutSelector = "[data-fleet-layout]"
}) {
  const [active, setActive] = useState(initial);
  const buttonRefs = useRef([]);
  useEffect(() => {
    if (typeof document === "undefined") return;
    const layout = document.querySelector(layoutSelector);
    if (!layout) return;
    layout.dataset.activeCategory = active;
    const cards = layout.querySelectorAll("[data-fleet-card-wrap]");
    cards.forEach((wrap) => {
      const cat = wrap.dataset.category ?? "";
      wrap.hidden = active !== "All" && cat !== active;
    });
  }, [active, layoutSelector]);
  function onKeyDown(e) {
    const idx = tabs.findIndex((t) => t.value === active);
    if (idx < 0) return;
    let next = idx;
    if (e.key === "ArrowRight" || e.key === "ArrowDown") {
      next = (idx + 1) % tabs.length;
    } else if (e.key === "ArrowLeft" || e.key === "ArrowUp") {
      next = (idx - 1 + tabs.length) % tabs.length;
    } else if (e.key === "Home") {
      next = 0;
    } else if (e.key === "End") {
      next = tabs.length - 1;
    } else {
      return;
    }
    e.preventDefault();
    const nextValue = tabs[next].value;
    setActive(nextValue);
    buttonRefs.current[next]?.focus();
  }
  return /* @__PURE__ */ jsx(
    "div",
    {
      role: "tablist",
      "aria-label": "Filter vehicles by category",
      onKeyDown,
      className: "flex flex-wrap items-center justify-center gap-x-7 gap-y-3 sm:gap-x-9",
      children: tabs.map((tab, i) => {
        const isActive = active === tab.value;
        return /* @__PURE__ */ jsxs(
          "button",
          {
            type: "button",
            role: "tab",
            id: `fleet-tab-${tab.value.replace(/\s+/g, "-").toLowerCase()}`,
            "aria-selected": isActive,
            tabIndex: isActive ? 0 : -1,
            ref: (el) => {
              buttonRefs.current[i] = el;
            },
            onClick: () => setActive(tab.value),
            className: "ecl-focusable group relative inline-flex items-center pb-2 font-sans text-xs font-medium uppercase tracking-[0.2em] transition-colors duration-300",
            children: [
              /* @__PURE__ */ jsx(
                "span",
                {
                  className: isActive ? "text-brand-forest" : "text-neutral-500 group-hover:text-brand-forest",
                  children: tab.label
                }
              ),
              /* @__PURE__ */ jsx(
                "span",
                {
                  "aria-hidden": "true",
                  className: `absolute inset-x-0 bottom-0 h-px origin-center bg-brand-gold transition-transform duration-500 ease-out ${isActive ? "scale-x-100" : "scale-x-0"}`
                }
              )
            ]
          },
          tab.value
        );
      })
    }
  );
}

const $$Astro = createAstro("https://emeraldcitylimos.com");
const $$FleetSection = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$FleetSection;
  const { showFilters = true, limit } = Astro2.props;
  const vehicles = limit ? fleet.slice(0, limit) : fleet;
  return renderTemplate`${maybeRenderHead()}<section class="ecl-fleet-section relative bg-brand-champagne py-20 sm:py-24 lg:py-32" aria-labelledby="fleet-heading" data-astro-cid-2dvte3xk> <div class="mx-auto max-w-7xl px-6 sm:px-8" data-astro-cid-2dvte3xk>  <header class="mx-auto mb-12 max-w-2xl text-center sm:mb-14 lg:mb-16" data-astro-cid-2dvte3xk> <p class="font-sans text-xs font-semibold uppercase tracking-[0.22em] text-brand-gold" data-astro-cid-2dvte3xk>
Our Fleet
</p> <h2 id="fleet-heading" class="mt-4 font-display text-3xl font-light leading-[1.08] tracking-tight text-brand-forest sm:text-4xl lg:text-5xl" data-astro-cid-2dvte3xk>
Travel in Absolute
<em class="italic text-brand-gold" data-astro-cid-2dvte3xk>Comfort</em>.
</h2> <p class="mt-5 font-sans text-base font-light leading-relaxed text-neutral-700 sm:text-lg" data-astro-cid-2dvte3xk>
Five distinct vehicles. One consistent standard — meticulously
        maintained, professionally chauffeured, ready when you are.
</p> </header>  ${showFilters && renderTemplate`<div class="mb-12 flex justify-center sm:mb-14" data-astro-cid-2dvte3xk> ${renderComponent($$result, "FleetFilterTabs", FleetFilterTabs, { "client:visible": true, "tabs": fleetCategoryTabs, "client:component-hydration": "visible", "client:component-path": "/home/josh/Documents/emerald-update/src/components/fleet/FleetFilterTabs", "client:component-export": "FleetFilterTabs", "data-astro-cid-2dvte3xk": true })} </div>`}  <ul role="list" data-fleet-layout data-active-category="All" class="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4" data-astro-cid-2dvte3xk> ${vehicles.map((v) => renderTemplate`<li data-fleet-card-wrap${addAttribute(v.category, "data-category")} class="flex" data-astro-cid-2dvte3xk> ${renderComponent($$result, "FleetCard", $$FleetCard, { "vehicle": v, "data-astro-cid-2dvte3xk": true })} </li>`)} </ul>  <div class="mt-16 text-center sm:mt-20" data-astro-cid-2dvte3xk> <p class="font-sans text-base font-light text-neutral-700" data-astro-cid-2dvte3xk>
Explore our complete fleet of luxury vehicles.
</p> <a href="/fleet" data-cta="fleet_view_all" class="ecl-focusable mt-6 inline-flex min-h-[48px] items-center justify-center gap-2 border border-brand-forest bg-transparent px-8 font-sans text-xs font-semibold uppercase tracking-[0.2em] text-brand-forest transition-colors duration-300 hover:bg-brand-forest hover:text-white" data-astro-cid-2dvte3xk>
View Full Fleet
<span aria-hidden="true" data-astro-cid-2dvte3xk>&rarr;</span> </a> </div> </div> </section> `;
}, "/home/josh/Documents/emerald-update/src/components/fleet/FleetSection.astro", void 0);

const heroImage = new Proxy({"src":"/_astro/emerald-city-hero.nELiKHIE.png","width":1672,"height":941,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/josh/Documents/emerald-update/src/assets/images/hero/emerald-city-hero.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/josh/Documents/emerald-update/src/assets/images/hero/emerald-city-hero.png");
							return target[name];
						}
					});

const mobileHero = new Proxy({"src":"/_astro/emerald-city-hero.Dtg5iFb5.webp","width":1672,"height":941,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/josh/Documents/emerald-update/src/assets/images/hero/emerald-city-hero.webp";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/josh/Documents/emerald-update/src/assets/images/hero/emerald-city-hero.webp");
							return target[name];
						}
					});

const $$Index = createComponent(($$result, $$props, $$slots) => {
  const PHONE_DISPLAY = "(206) 595-9675";
  const PHONE_TEL = "tel:+12065959675";
  const services = [
    {
      href: "/airport-transfers",
      title: "Airport Transfers",
      blurb: "Flat-rate SeaTac and Boeing Field service. Flight tracking and meet-and-greet 24/7.",
      icon: "plane"
    },
    {
      href: "/service/executive-transportation",
      title: "Executive Transport",
      blurb: "Discreet black-car service for Seattle business travel and corporate events.",
      icon: "briefcase"
    },
    {
      href: "/service/wedding-transportation",
      title: "Weddings",
      blurb: "Red-carpet arrivals, bridal-party logistics, and venue coordination.",
      icon: "rings"
    },
    {
      href: "/service/hourly-charters",
      title: "Hourly Charters",
      blurb: "Flexible by-the-hour service for tours, meetings, and a night on the town.",
      icon: "clock"
    },
    {
      href: "/service/cruise-transportation",
      title: "Cruise Transfers",
      blurb: "Smith Cove and Bell Street pier transfers, luggage handled.",
      icon: "ship"
    },
    {
      href: "/service/game-day-transport",
      title: "Game Day",
      blurb: "Seahawks, Mariners, Sounders and Kraken \u2014 arrive without the parking.",
      icon: "trophy"
    },
    {
      href: "/service/special-occasions",
      title: "Special Occasions",
      blurb: "Birthdays, anniversaries, prom \u2014 every milestone in measured luxury.",
      icon: "sparkles"
    },
    {
      href: "/service/infant-car-seats",
      title: "Infant & Booster Seats",
      blurb: "Pre-installed, properly fitted car seats for safe family travel.",
      icon: "baby"
    }
  ];
  const ICONS = {
    plane: "M6 12L3.269 3.125A59.769 59.769 0 0121.485 12 59.768 59.768 0 013.27 20.875L5.999 12zm0 0h7.5",
    briefcase: "M20.25 14.15v4.07a2.25 2.25 0 01-2.25 2.25h-12a2.25 2.25 0 01-2.25-2.25v-4.07m16.5 0a24.094 24.094 0 01-8.25 1.45 24.094 24.094 0 01-8.25-1.45m16.5 0v-2.62a2.25 2.25 0 00-1.632-2.163l-3.05-.872a2.25 2.25 0 01-1.632-2.163V5.625A2.625 2.625 0 0014.625 3h-5.25A2.625 2.625 0 006.75 5.625v.755a2.25 2.25 0 01-1.632 2.163l-3.05.872A2.25 2.25 0 00.436 11.578v2.572m19.814 0H3.75",
    rings: "M21 12a9 9 0 11-18 0 9 9 0 0118 0zm-9-7.5l3.5 3-3.5 3-3.5-3 3.5-3z",
    clock: "M12 6v6h4.5m4.5 0a9 9 0 11-18 0 9 9 0 0118 0z",
    ship: "M21 12.75a9 9 0 11-18 0 9 9 0 0118 0zm-3 0H6m12 4.5H6m12-9H6",
    trophy: "M16.5 18.75h-9m9 0a3 3 0 013 3h-15a3 3 0 013-3m9 0v-3.375c0-.621-.503-1.125-1.125-1.125h-.871M7.5 18.75v-3.375c0-.621.504-1.125 1.125-1.125h.872m5.007 0H9.497m5.007 0a7.454 7.454 0 01-.982-3.172M9.497 14.25a7.454 7.454 0 00.981-3.172M5.25 4.236c-.982.143-1.954.317-2.916.52A6.003 6.003 0 007.73 9.728M5.25 4.236V4.5c0 2.108.966 3.99 2.48 5.228M5.25 4.236V2.721C7.456 2.41 9.71 2.25 12 2.25c2.291 0 4.545.16 6.75.47v1.516M7.73 9.728a6.726 6.726 0 002.748 1.35m8.272-6.842V4.5c0 2.108-.966 3.99-2.48 5.228m2.48-5.492a46.32 46.32 0 012.916.52 6.003 6.003 0 01-5.395 4.972m0 0a6.726 6.726 0 01-2.749 1.35m0 0a6.772 6.772 0 01-3.044 0",
    sparkles: "M9.813 15.904L9 18.75l-.813-2.846a4.5 4.5 0 00-3.09-3.09L2.25 12l2.846-.813a4.5 4.5 0 003.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 003.09 3.09L15.75 12l-2.846.813a4.5 4.5 0 00-3.09 3.09zM18.259 8.715L18 9.75l-.259-1.035a3.375 3.375 0 00-2.455-2.456L14.25 6l1.036-.259a3.375 3.375 0 002.455-2.456L18 2.25l.259 1.035a3.375 3.375 0 002.456 2.456L21.75 6l-1.035.259a3.375 3.375 0 00-2.456 2.456z",
    baby: "M15.182 16.318A4.486 4.486 0 0012.016 15a4.486 4.486 0 00-3.198 1.318M21 12a9 9 0 11-18 0 9 9 0 0118 0zM9.75 9.75c0 .414-.168.75-.375.75S9 10.164 9 9.75 9.168 9 9.375 9s.375.336.375.75zm-.375 0h.008v.015h-.008V9.75zm5.625 0c0 .414-.168.75-.375.75s-.375-.336-.375-.75.168-.75.375-.75.375.336.375.75zm-.375 0h.008v.015h-.008V9.75z"
  };
  const areas = [
    { name: "Seattle", href: "/locations/seattle" },
    { name: "Bellevue", href: "/locations/bellevue" },
    { name: "Redmond", href: "/locations/redmond" },
    { name: "Kirkland", href: "/locations/kirkland" },
    { name: "Renton", href: "/locations/renton" },
    { name: "Tacoma", href: "/locations/tacoma" },
    { name: "Everett", href: "/locations/everett" },
    { name: "Lynnwood", href: "/locations/lynnwood" },
    { name: "Edmonds", href: "/locations/edmonds" },
    { name: "Bothell", href: "/locations/bothell" },
    { name: "Woodinville", href: "/locations/woodinville" },
    { name: "Auburn", href: "/locations/auburn" },
    { name: "Federal Way", href: "/locations/federal-way" },
    { name: "Sammamish", href: "/locations/sammamish" },
    { name: "Kent", href: "/locations/kent" },
    { name: "Lakewood", href: "/locations/lakewood" },
    { name: "Puyallup", href: "/locations/puyallup" },
    { name: "Marysville", href: "/locations/marysville" },
    { name: "SeaTac Airport", href: "/airport/sea-tac" },
    { name: "Boeing Field", href: "/airport/boeing-field" }
  ];
  return renderTemplate`${renderComponent($$result, "MainLayout", $$MainLayout, { "title": "Seattle Limo Service | Airport Transfers & Black Car | Emerald City Limos", "description": "Seattle's premium luxury chauffeur service since 2010. Flat-rate SeaTac airport transfers, executive black-car service, weddings and special events. Licensed, insured, available 24/7.", "keywords": "seattle limo service, seatac airport limo, luxury car service seattle, black car service seattle, seattle airport transportation, corporate limo seattle, wedding limo seattle", "data-astro-cid-j7pv25f6": true }, { "default": ($$result2) => renderTemplate`  ${renderComponent($$result2, "PageHero", $$PageHero, { "eyebrow": "Seattle Luxury Chauffeur & Airport Transportation", "headline": "Refined Private Transportation", "headlineAccent": "Across Greater Seattle", "supporting": "Executive airport transfers, corporate travel, cruise transportation, and private chauffeur service tailored for Seattle\u2019s business travelers, visitors, and special occasions.", "ctaPrimary": { label: "Reserve Your Ride", href: "https://customer.moovs.app/a1-charters-1/new/info", id: "cta-hero-book" }, "ctaSecondary": { label: PHONE_DISPLAY, href: PHONE_TEL, id: "cta-hero-call", phone: PHONE_DISPLAY }, "image": {
    src: heroImage,
    srcMobile: mobileHero,
    alt: "Professional chauffeur beside a luxury black SUV with Seattle skyline and Mount Rainier in the background",
    width: 1672,
    height: 941
  }, "size": "full", "id": "hero-headline", "data-astro-cid-j7pv25f6": true })} ${renderComponent($$result2, "TrustStrip", $$TrustStrip, { "data-astro-cid-j7pv25f6": true })}  ${maybeRenderHead()}<section class="relative bg-white py-20 sm:py-24 lg:py-32" aria-labelledby="services-heading" data-astro-cid-j7pv25f6> <div class="mx-auto max-w-7xl px-6 sm:px-8" data-astro-cid-j7pv25f6> <header class="mx-auto mb-14 max-w-2xl text-center sm:mb-16 lg:mb-20" data-astro-cid-j7pv25f6> <p class="font-sans text-xs font-semibold uppercase tracking-widest text-brand-gold" data-astro-cid-j7pv25f6>
Our Services
</p> <h2 id="services-heading" class="mt-4 font-display text-3xl font-light leading-tight tracking-tight text-brand-forest sm:text-4xl lg:text-5xl" data-astro-cid-j7pv25f6>
Every journey,
<em class="italic text-brand-gold" data-astro-cid-j7pv25f6>perfected</em>.
</h2> <p class="mt-5 font-sans text-base font-light leading-relaxed text-neutral-700 sm:text-lg" data-astro-cid-j7pv25f6>
From SeaTac at dawn to a Pike Place wedding at dusk &mdash; white-glove transport for every occasion.
</p> </header> <ul role="list" class="grid grid-cols-1 gap-5 sm:grid-cols-2 sm:gap-6 lg:grid-cols-4" data-astro-cid-j7pv25f6> ${services.map((s) => renderTemplate`<li data-astro-cid-j7pv25f6> <a${addAttribute(s.href, "href")} class="ecl-focusable group relative flex h-full flex-col bg-white p-7 ring-1 ring-brand-forest/10 transition duration-300 hover:ring-brand-gold sm:p-8" data-astro-cid-j7pv25f6> <span class="absolute inset-x-0 top-0 h-px origin-left scale-x-0 bg-brand-gold transition-transform duration-500 ease-out group-hover:scale-x-100 group-focus-visible:scale-x-100" aria-hidden="true" data-astro-cid-j7pv25f6></span> <span class="mb-6 inline-flex h-12 w-12 items-center justify-center bg-brand-champagne text-brand-gold transition-colors duration-300 group-hover:bg-brand-gold group-hover:text-white" data-astro-cid-j7pv25f6> <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.25" width="24" height="24" aria-hidden="true" data-astro-cid-j7pv25f6> <path stroke-linecap="round" stroke-linejoin="round"${addAttribute(ICONS[s.icon], "d")} data-astro-cid-j7pv25f6></path> </svg> </span> <h3 class="font-display text-2xl font-medium leading-snug text-brand-forest transition-colors duration-300 group-hover:text-brand-gold" data-astro-cid-j7pv25f6> ${s.title} </h3> <p class="mt-3 font-sans text-sm leading-relaxed text-neutral-600" data-astro-cid-j7pv25f6> ${s.blurb} </p> <span class="mt-auto inline-flex items-center gap-2 pt-6 font-sans text-xs font-semibold uppercase tracking-widest text-brand-forest transition-colors duration-300 group-hover:text-brand-gold" data-astro-cid-j7pv25f6>
Learn more
<span aria-hidden="true" class="transition-transform duration-300 group-hover:translate-x-1" data-astro-cid-j7pv25f6>&rarr;</span> </span> </a> </li>`)} </ul> <div class="mt-14 text-center sm:mt-16" data-astro-cid-j7pv25f6> <a href="/services" class="ecl-focusable inline-flex items-center gap-2 border-b border-brand-gold pb-1 font-sans text-xs font-semibold uppercase tracking-widest text-brand-forest transition-colors hover:text-brand-gold" data-astro-cid-j7pv25f6>
View all services
<span aria-hidden="true" data-astro-cid-j7pv25f6>&rarr;</span> </a> </div> </div> </section> ${renderComponent($$result2, "FleetSection", $$FleetSection, { "showFilters": false, "limit": 4, "data-astro-cid-j7pv25f6": true })}  <section class="relative bg-brand-forest overflow-hidden py-20 sm:py-28 px-6 sm:px-8" aria-labelledby="about-heading" data-astro-cid-j7pv25f6> <!-- Full-bleed background image --> ${renderComponent($$result2, "Image", $$Image, { "src": aboutImage, "alt": "", "width": 1200, "height": 900, "loading": "lazy", "decoding": "async", "class": "absolute inset-0 w-full h-full object-cover object-center", "aria-hidden": "true", "data-astro-cid-j7pv25f6": true })} <!-- Dark overlay for readability --> <div class="absolute inset-0 bg-brand-forest/70" aria-hidden="true" data-astro-cid-j7pv25f6></div> <!-- Vertical rule — decorative left spine, desktop only --> <div class="absolute left-0 top-0 hidden lg:block h-full w-px bg-white/[.07]" aria-hidden="true" data-astro-cid-j7pv25f6></div> <div class="max-w-6xl mx-auto relative z-10" data-astro-cid-j7pv25f6> <!-- ── Top row: eyebrow + running headline ── --> <div class="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-4 mb-14 sm:mb-16 lg:mb-20" data-astro-cid-j7pv25f6> <div class="flex items-center gap-4" data-astro-cid-j7pv25f6> <div class="hidden sm:block h-px w-10 bg-brand-gold shrink-0" aria-hidden="true" data-astro-cid-j7pv25f6></div> <p class="font-sans text-[10px] sm:text-[11px] font-semibold tracking-[0.22em] uppercase text-brand-gold" data-astro-cid-j7pv25f6>
Established Seattle &rsquo;10
</p> </div> <p class="font-sans text-[11px] font-medium tracking-[0.16em] uppercase text-white/40 sm:text-right" data-astro-cid-j7pv25f6>
King &middot; Snohomish &middot; Pierce
</p> </div> <!-- ── Main editorial grid ── --> <div class="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start" data-astro-cid-j7pv25f6> <!-- Left column: stacked content --> <div class="flex flex-col" data-astro-cid-j7pv25f6> <!-- Dominant heading --> <h2 id="about-heading" class="font-display font-light text-white leading-[1.04] tracking-[-0.025em] mb-10 lg:mb-0" style="font-size: clamp(2.75rem, 6vw, 5rem);" data-astro-cid-j7pv25f6>
A quieter<br data-astro-cid-j7pv25f6>
standard of<br data-astro-cid-j7pv25f6> <em class="text-brand-gold italic" data-astro-cid-j7pv25f6>arrival</em>.
</h2> <!-- Stat cards — desktop only --> <div class="hidden lg:flex flex-col gap-3 mt-10" aria-label="Company statistics" data-astro-cid-j7pv25f6> ${[
    { value: "15+", label: "Years serving Seattle" },
    { value: "24/7", label: "Available year-round" }
  ].map((stat) => renderTemplate`<div class="group flex items-center gap-5 bg-white px-6 py-4 ring-1 ring-brand-forest/10 transition-all duration-300text-ring-brand-gold w-[260px]" role="listitem"${addAttribute(`${stat.value} \u2014 ${stat.label}`, "aria-label")} data-astro-cid-j7pv25f6> <span class="font-display font-light text-brand-forest leading-none transition-colors duration-300 group-hover:text-brand-gold" style="font-size: clamp(1.5rem, 2.5vw, 2rem);" data-astro-cid-j7pv25f6> ${stat.value} </span> <div class="h-8 w-px bg-brand-forest/10 shrink-0" aria-hidden="true" data-astro-cid-j7pv25f6></div> <span class="font-sans text-[10px] font-medium tracking-[0.14em] uppercase text-brand-forest/50" data-astro-cid-j7pv25f6> ${stat.label} </span> </div>`)} </div> </div> <!-- Right column: copy card --> <div class="relative mt-10 lg:mt-0" data-astro-cid-j7pv25f6> <div class="relative bg-white ring-1 ring-brand-forest/10 px-7 py-8 sm:px-8 sm:py-9" data-astro-cid-j7pv25f6> <!-- Animated gold hairline --> <div class="absolute inset-x-0 top-0 h-px origin-left bg-brand-gold scale-x-0 transition-transform duration-700 ease-out" style="animation: scaleIn 1.2s cubic-bezier(0.25,0.46,0.45,0.94) 0.3s forwards;" aria-hidden="true" data-astro-cid-j7pv25f6></div> <p class="font-sans text-sm sm:text-base leading-[1.78] text-neutral-700 mb-5" data-astro-cid-j7pv25f6>
For over a decade, Emerald City Limos has served the Greater Seattle area with chauffeurs who anticipate, vehicles that perform, and a standard of service that doesn&rsquo;t announce itself.
</p> <p class="font-sans text-sm sm:text-base leading-[1.78] text-neutral-700 mb-7" data-astro-cid-j7pv25f6>
Whether the destination is SeaTac at 4&nbsp;a.m., a Pike Place wedding, a Seahawks Sunday, or a downtown board meeting &mdash; we deliver the same answer. Quietly, every time.
</p> <div class="flex flex-col sm:flex-row sm:items-center gap-4 sm:gap-8" data-astro-cid-j7pv25f6> <a href="/about" class="ecl-focusable inline-flex items-center gap-2 font-sans text-[11px] font-semibold tracking-[0.2em] uppercase text-brand-forest border-b border-brand-gold pb-1 transition-colors hover:text-brand-gold focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-gold focus-visible:ring-offset-2" aria-label="Learn more about Emerald City Limos" data-astro-cid-j7pv25f6>
Our story
<span aria-hidden="true" data-astro-cid-j7pv25f6>→</span> </a> <a href="/locations" class="ecl-focusable inline-flex items-center gap-2 font-sans text-[11px] font-semibold tracking-[0.2em] uppercase text-brand-forest/50 border-b border-brand-forest/20 pb-1 transition-colors hover:text-brand-forest hover:border-brand-gold focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-gold focus-visible:ring-offset-2" aria-label="View all service areas" data-astro-cid-j7pv25f6>
Service areas
<span aria-hidden="true" data-astro-cid-j7pv25f6>→</span> </a> </div> </div> </div> </div> <!-- Mobile stat row — shown below the grid on small screens --> <div class="lg:hidden mt-10 grid grid-cols-3 gap-px bg-white/10" aria-label="Company statistics" data-astro-cid-j7pv25f6> ${[
    { value: "15+", label: "Years" },
    { value: "24/7", label: "Available" }
  ].map((stat) => renderTemplate`<div class="bg-white/10 flex flex-col items-center justify-center py-5 px-2 text-center" role="listitem"${addAttribute(`${stat.value} \u2014 ${stat.label}`, "aria-label")} data-astro-cid-j7pv25f6> <span class="font-display font-light text-white text-2xl leading-none mb-1" data-astro-cid-j7pv25f6> ${stat.value} </span> <span class="font-sans text-[9px] font-medium tracking-[0.14em] uppercase text-white/50" data-astro-cid-j7pv25f6> ${stat.label} </span> </div>`)} </div> </div> </section>  <section class="relative bg-brand-forest overflow-hidden py-20 sm:py-28 px-6 sm:px-8" aria-labelledby="areas-heading" data-astro-cid-j7pv25f6> <!-- Top gold rule --> <div class="absolute top-0 inset-x-0 h-px pointer-events-none" style="background: linear-gradient(90deg, transparent, rgba(195,154,69,0.45), transparent);" aria-hidden="true" data-astro-cid-j7pv25f6></div> <!-- Subtle texture --> <div class="pointer-events-none absolute inset-0 opacity-[.03]" style="background-image: repeating-linear-gradient(45deg,#fff 0px,#fff 1px,transparent 1px,transparent 8px);" aria-hidden="true" data-astro-cid-j7pv25f6></div> <div class="relative z-10 max-w-6xl mx-auto" data-astro-cid-j7pv25f6> <!-- ── Header row ── --> <div class="grid grid-cols-1 lg:grid-cols-[1fr_auto] gap-8 lg:gap-16 items-end mb-16 sm:mb-20" data-astro-cid-j7pv25f6> <div data-astro-cid-j7pv25f6> <p class="font-sans text-[10px] sm:text-[11px] font-semibold tracking-[0.22em] uppercase text-brand-gold mb-4" data-astro-cid-j7pv25f6>
Coverage
</p> <h2 id="areas-heading" class="font-display font-light text-white leading-[1.04] tracking-[-0.025em]" style="font-size: clamp(2.25rem, 5vw, 4rem);" data-astro-cid-j7pv25f6>
Greater Seattle&nbsp;&mdash;<br data-astro-cid-j7pv25f6> <em class="not-italic" style="font-style: italic !important; color: rgba(195,154,69,0.85);" data-astro-cid-j7pv25f6>
end to end
</em>.
</h2> </div> <a href="/locations" class="ecl-focusable shrink-0 inline-flex items-center gap-2 font-sans text-[11px] font-semibold tracking-[0.2em] uppercase text-white/60 border-b border-white/20 pb-1 transition-colors hover:text-brand-gold hover:border-brand-gold focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-gold focus-visible:ring-offset-2 focus-visible:ring-offset-brand-forest self-end" aria-label="View all service area locations" data-astro-cid-j7pv25f6>
All locations
<span aria-hidden="true" data-astro-cid-j7pv25f6>→</span> </a> </div> <!-- ── Three-county columns ── --> <div class="grid grid-cols-1 sm:grid-cols-3 gap-px bg-white/[.06] mb-14" role="list" aria-label="Service area counties" data-astro-cid-j7pv25f6> ${[
    {
      county: "King County",
      note: "incl. SeaTac Airport",
      cities: ["Seattle", "Bellevue", "Redmond", "Kirkland", "Renton", "Auburn", "Federal Way", "Sammamish", "Kenmore", "Bothell", "SeaTac", "Tukwila", "Mercer Island", "Issaquah", "Burien"]
    },
    {
      county: "Snohomish County",
      note: "incl. Paine Field",
      cities: ["Everett", "Lynnwood", "Edmonds", "Mukilteo", "Marysville", "Mountlake Terrace", "Shoreline", "Woodinville", "Mill Creek", "Snohomish", "Monroe", "Arlington", "Bothell North"]
    },
    {
      county: "Pierce County",
      note: "incl. Tacoma Dome",
      cities: ["Tacoma", "Lakewood", "Puyallup", "Gig Harbor", "Bonney Lake", "Sumner", "Fife", "Milton", "Edgewood", "University Place", "Steilacoom", "DuPont"]
    }
  ].map((col) => renderTemplate`<div class="group relative bg-brand-forest px-7 py-8 sm:px-8 sm:py-10 transition-colors duration-300 hover:bg-white/[.04]" role="listitem"${addAttribute(`${col.county} service area`, "aria-label")} data-astro-cid-j7pv25f6> <!-- Animated gold top hairline --> <span class="absolute inset-x-0 top-0 h-px origin-left scale-x-0 bg-brand-gold transition-transform duration-500 ease-out group-hover:scale-x-100" aria-hidden="true" data-astro-cid-j7pv25f6></span> <!-- County heading --> <div class="flex items-start justify-between gap-4 mb-6" data-astro-cid-j7pv25f6> <div data-astro-cid-j7pv25f6> <h3 class="font-display font-normal text-white text-xl leading-snug mb-1" data-astro-cid-j7pv25f6> ${col.county} </h3> <p class="font-sans text-[9px] font-medium tracking-[0.18em] uppercase text-brand-gold/70" data-astro-cid-j7pv25f6> ${col.note} </p> </div> <span class="shrink-0 mt-1 font-display font-light text-white/15 leading-none select-none" style="font-size: 2.5rem;" aria-hidden="true" data-astro-cid-j7pv25f6> ${col.cities.length} </span> </div> <!-- City list --> <ul class="list-none m-0 p-0 flex flex-col gap-2"${addAttribute(`Cities served in ${col.county}`, "aria-label")} data-astro-cid-j7pv25f6> ${col.cities.map((city) => renderTemplate`<li class="flex items-center gap-2.5 font-sans font-light text-white/55 text-sm transition-colors duration-200 group-hover:text-white/65" data-astro-cid-j7pv25f6> <span class="w-1 h-1 rounded-full bg-brand-gold/50 shrink-0" aria-hidden="true" data-astro-cid-j7pv25f6></span> ${city} </li>`)} </ul> </div>`)} </div> <!-- ── Chip strip ── --> <div class="flex flex-col items-center gap-6" data-astro-cid-j7pv25f6> <p class="font-sans text-[9px] font-medium tracking-[0.22em] uppercase text-white/30" data-astro-cid-j7pv25f6>
All covered cities at a glance
</p> <ul class="flex flex-wrap justify-center gap-2 list-none m-0 p-0" role="list" aria-label="All service area cities" data-astro-cid-j7pv25f6> ${areas.map((area) => renderTemplate`<li data-astro-cid-j7pv25f6> <a${addAttribute(area.href, "href")} class="inline-flex items-center px-3.5 py-1.5 font-sans text-[10px] sm:text-[11px] font-medium tracking-[0.08em] text-white/55 border border-white/10 transition-colors duration-300 hover:border-brand-gold/60 hover:text-white/80" role="listitem" data-astro-cid-j7pv25f6> ${area.name} </a> </li>`)} </ul> <p class="font-sans font-light text-white/30 text-xs text-center max-w-sm" data-astro-cid-j7pv25f6>
Interstate transfers to Portland, OR and Vancouver, BC available on request.
</p> </div> </div> <!-- Bottom gold rule --> <div class="absolute bottom-0 inset-x-0 h-px pointer-events-none" style="background: linear-gradient(90deg, transparent, rgba(195,154,69,0.25), transparent);" aria-hidden="true" data-astro-cid-j7pv25f6></div> </section>  <section class="relative bg-brand-champagne overflow-hidden py-20 sm:py-28 px-6 sm:px-8" aria-labelledby="cta-heading" data-astro-cid-j7pv25f6> <!-- Top forest rule --> <div class="absolute top-0 left-0 right-0 h-px" style="background: linear-gradient(90deg, transparent, rgba(10,35,24,0.15), transparent);" aria-hidden="true" data-astro-cid-j7pv25f6></div> <!-- Subtle vertical spines — decorative only --> <div class="pointer-events-none absolute inset-y-0 left-1/4 w-px bg-brand-forest/[.05] hidden lg:block" aria-hidden="true" data-astro-cid-j7pv25f6></div> <div class="pointer-events-none absolute inset-y-0 right-1/4 w-px bg-brand-forest/[.05] hidden lg:block" aria-hidden="true" data-astro-cid-j7pv25f6></div> <div class="relative z-10 max-w-6xl mx-auto" data-astro-cid-j7pv25f6> <!-- ── Asymmetric editorial grid ── --> <div class="grid grid-cols-1 lg:grid-cols-[1fr_auto] gap-12 lg:gap-20 items-end" data-astro-cid-j7pv25f6> <!-- Left: heading block --> <div data-astro-cid-j7pv25f6> <!-- Eyebrow with leading rule --> <div class="flex items-center gap-4 mb-6" data-astro-cid-j7pv25f6> <div class="h-px w-10 bg-brand-gold shrink-0" aria-hidden="true" data-astro-cid-j7pv25f6></div> <p class="font-sans text-[10px] sm:text-[11px] font-semibold tracking-[0.22em] uppercase text-brand-gold" data-astro-cid-j7pv25f6>
Reserve Now
</p> </div> <h2 id="cta-heading" class="font-display font-light text-brand-forest leading-[1.04] tracking-[-0.025em] mb-6" style="font-size: clamp(2.5rem, 5.5vw, 4.5rem);" data-astro-cid-j7pv25f6>
Ready to ride<br data-astro-cid-j7pv25f6> <em class="italic text-brand-gold" data-astro-cid-j7pv25f6>
in luxury?
</em> </h2> <p class="font-sans font-light text-neutral-600 leading-relaxed max-w-lg" style="font-size: clamp(0.9375rem, 1.4vw, 1.0625rem);" data-astro-cid-j7pv25f6>
Book online in under 60 seconds — or speak to a chauffeur dispatcher 24&hairsp;/&hairsp;7.
</p> </div> <!-- Right: action card --> <div class="shrink-0 w-full lg:w-[340px]" data-astro-cid-j7pv25f6> <div class="relative bg-white ring-1 ring-brand-forest/10 px-8 py-9" data-astro-cid-j7pv25f6> <!-- Animated gold hairline — consistent with card pattern --> <span class="absolute inset-x-0 top-0 h-px origin-left scale-x-0 bg-brand-gold transition-transform duration-700 ease-out" style="animation: scaleIn 1.2s cubic-bezier(0.25,0.46,0.45,0.94) 0.2s forwards;" aria-hidden="true" data-astro-cid-j7pv25f6></span> <!-- Reassurances --> <ul class="list-none m-0 p-0 flex flex-col gap-3 mb-8" aria-label="Booking reassurances" data-astro-cid-j7pv25f6> ${[
    "Flat-rate \u2014 your quote is your final charge",
    "Response within 60 minutes",
    "Free cancellation up to 4 hours prior"
  ].map((item) => renderTemplate`<li class="flex items-start gap-3 font-sans text-sm font-light text-neutral-600" data-astro-cid-j7pv25f6> <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" width="14" height="14" class="shrink-0 mt-[2px] text-brand-gold" aria-hidden="true" data-astro-cid-j7pv25f6> <path fill-rule="evenodd" d="M16.704 4.153a.75.75 0 01.143 1.052l-8 10.5a.75.75 0 01-1.127.075l-4.5-4.5a.75.75 0 011.06-1.06l3.894 3.893 7.48-9.817a.75.75 0 011.05-.143z" clip-rule="evenodd" data-astro-cid-j7pv25f6></path> </svg> ${item} </li>`)} </ul> <!-- Divider --> <div class="h-px bg-brand-forest/[.08] mb-8" aria-hidden="true" data-astro-cid-j7pv25f6></div> <!-- Buttons --> <div class="flex flex-col gap-3" role="group" aria-label="Booking options" data-astro-cid-j7pv25f6> <a href="https://customer.moovs.app/a1-charters-1/new/info" target="_blank" rel="noopener noreferrer" data-cta="footer_book_now" aria-label="Reserve your ride — Emerald City Limos" class="ecl-btn-primary ecl-focusable inline-flex items-center justify-center gap-2 min-h-[52px] px-8 font-sans text-[11px] font-semibold tracking-[0.2em] uppercase bg-brand-forest text-white border border-brand-forest rounded-none transition-colors duration-200 hover:bg-brand-forest/90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-gold focus-visible:ring-offset-2" data-astro-cid-j7pv25f6>
Reserve Your Ride
<span aria-hidden="true" class="ecl-arrow transition-transform duration-200 group-hover:translate-x-0.5" data-astro-cid-j7pv25f6>→</span> </a> <a${addAttribute(PHONE_TEL, "href")} data-cta="footer_call_now"${addAttribute(`Call us at ${PHONE_DISPLAY}`, "aria-label")} class="ecl-btn-secondary ecl-focusable inline-flex items-center justify-center gap-2.5 min-h-[52px] px-8 font-sans text-[11px] font-semibold tracking-[0.2em] uppercase bg-transparent text-brand-forest border border-brand-forest/25 rounded-none transition-colors duration-200 hover:border-brand-gold hover:text-brand-gold focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-gold focus-visible:ring-offset-2" data-astro-cid-j7pv25f6> <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" width="14" height="14" aria-hidden="true" data-astro-cid-j7pv25f6> <path stroke-linecap="round" stroke-linejoin="round" d="M2.25 6.75c0 8.284 6.716 15 15 15h2.25a2.25 2.25 0 002.25-2.25v-1.372c0-.516-.351-.966-.852-1.091l-4.423-1.106c-.44-.11-.902.055-1.173.417l-.97 1.293c-.282.376-.769.542-1.21.38a12.035 12.035 0 01-7.143-7.143c-.162-.441.004-.928.38-1.21l1.293-.97c.363-.271.527-.734.417-1.173L6.963 3.102a1.125 1.125 0 00-1.091-.852H4.5A2.25 2.25 0 002.25 4.5v2.25z" data-astro-cid-j7pv25f6></path> </svg> <span class="tabular-nums" data-astro-cid-j7pv25f6>${PHONE_DISPLAY}</span> </a> </div> <!-- Sub-note --> <p class="mt-5 font-sans text-[10px] font-light text-neutral-400 text-center tracking-[0.04em]" data-astro-cid-j7pv25f6>
No payment until you confirm &middot; Corporate invoicing available
</p> </div> </div> </div> </div> <!-- Bottom forest rule --> <div class="absolute bottom-0 left-0 right-0 h-px" style="background: linear-gradient(90deg, transparent, rgba(10,35,24,0.12), transparent);" aria-hidden="true" data-astro-cid-j7pv25f6></div> </section>  ` })}`;
}, "/home/josh/Documents/emerald-update/src/pages/index.astro", void 0);

const $$file = "/home/josh/Documents/emerald-update/src/pages/index.astro";
const $$url = "";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$Index,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };

import { b as createAstro, c as createComponent, a as renderTemplate, d as addAttribute, m as maybeRenderHead, r as renderComponent } from '../chunks/astro/server_7-PjRNDj.mjs';
import 'piccolore';
import { $ as $$MainLayout } from '../chunks/MainLayout_BwP3NZXh.mjs';
import 'clsx';
import { jsx, jsxs } from 'react/jsx-runtime';
import { useState, useRef, useEffect } from 'react';
/* empty css                                 */
export { renderers } from '../renderers.mjs';

var __freeze = Object.freeze;
var __defProp = Object.defineProperty;
var __template = (cooked, raw) => __freeze(__defProp(cooked, "raw", { value: __freeze(cooked.slice()) }));
var _a;
const $$Astro$3 = createAstro("https://emeraldcitylimos.com");
const $$Hero = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$3, $$props, $$slots);
  Astro2.self = $$Hero;
  const {
    eyebrow = "Seattle's Premier Chauffeur Service",
    headline,
    headlineAccent,
    headlineEnd,
    tagline,
    ctaPrimary,
    ctaSecondary,
    phone,
    trustIndicators = [
      { label: "Since 2010", icon: "clock" },
      { label: "Licensed & Insured", icon: "shield" },
      { label: "SeaTac Specialists", icon: "route" },
      { label: "24/7 Availability", icon: "car" }
    ],
    image,
    showScrollIndicator = true
  } = Astro2.props;
  const ICON_PATHS = {
    shield: "M12 2.25 3.75 6v4.5c0 4.95 3.563 9.578 8.25 10.875 4.688-1.297 8.25-5.925 8.25-10.875V6L12 2.25z",
    clock: "M12 6v6h4.5m4.5 0a9 9 0 11-18 0 9 9 0 0118 0z",
    star: "M11.48 3.499a.562.562 0 011.04 0l2.125 5.111a.563.563 0 00.475.345l5.518.442c.499.04.701.663.321.988l-4.204 3.602a.563.563 0 00-.182.557l1.285 5.385a.562.562 0 01-.84.61l-4.725-2.885a.563.563 0 00-.586 0L6.982 20.54a.562.562 0 01-.84-.61l1.285-5.386a.562.562 0 00-.182-.557L2.78 10.385a.563.563 0 01.321-.988l5.518-.442a.563.563 0 00.475-.345L11.48 3.5z",
    car: "M8.25 18.75a1.5 1.5 0 01-3 0m3 0a1.5 1.5 0 00-3 0m3 0h6m-9 0H3.375a1.125 1.125 0 01-1.125-1.125V14.25m17.25 4.5a1.5 1.5 0 01-3 0m3 0a1.5 1.5 0 00-3 0m3 0h1.125c.621 0 1.129-.504 1.09-1.124a17.902 17.902 0 00-3.213-9.193 2.256 2.256 0 00-1.586-.67H4.25A2.25 2.25 0 002 7.498v6.75z",
    route: "M9 6.75V15m6-6v8.25m.504 3.75c1.245 0 2.246-1.005 2.246-2.25S16.749 16.5 15.504 16.5s-2.246 1.005-2.246 2.25S14.259 19.5 15.504 19.5zm-7.5-15c1.245 0 2.246 1.005 2.246 2.25S9.249 9 8.004 9 5.758 7.995 5.758 6.75 6.759 4.5 8.004 4.5z"
  };
  const telDigits = phone ? phone.replace(/\D/g, "") : "";
  const telHref = telDigits ? `tel:+1${telDigits}` : ctaSecondary.href;
  return renderTemplate(_a || (_a = __template(["<!-- \u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\n     HERO\n     \u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550 -->", '<section class="ecl-hero ecl-noise relative w-full overflow-hidden" aria-labelledby="hero-headline"> <!-- \u2500\u2500 Background image (LCP) \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 --> <picture> ', " <img", "", "", "", ' fetchpriority="high" loading="eager" decoding="async" class="absolute inset-0 w-full h-full object-cover object-center"> </picture> <!-- \u2500\u2500 Three-layer overlay (darken + readability gradient + vignette) \u2500\u2500 --> <div class="absolute inset-0 bg-brand-forest/55" aria-hidden="true"></div> <div class="absolute inset-0" style="background: linear-gradient(to bottom, rgba(10,35,24,0.15) 0%, rgba(10,35,24,0.30) 35%, rgba(10,35,24,0.72) 65%, rgba(10,35,24,0.92) 100%);" aria-hidden="true"></div> <div class="absolute inset-0" style="background: radial-gradient(ellipse 80% 60% at 50% 40%, transparent 0%, rgba(10,35,24,0.35) 100%);" aria-hidden="true"></div> <!-- \u2500\u2500 Top decorative gold rule \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 --> <div class="absolute top-0 left-0 right-0 h-px ecl-anim ecl-anim-line ecl-delay-1" style="background: linear-gradient(90deg, transparent, rgba(163,126,44,0.5), transparent);" aria-hidden="true"></div> <!-- \u2500\u2500 Content \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 --> <div class="relative z-10 flex flex-col min-h-[100svh]"> <div class="flex-1 flex flex-col justify-end pb-10 sm:pb-14 pt-[10vh] px-6 sm:px-8 md:px-12"></div> <div class="w-full max-w-4xl mx-auto text-center"> <!-- Eyebrow --> <div class="ecl-anim ecl-anim-fade-in ecl-delay-2 mb-5 sm:mb-7 flex items-center justify-center gap-3"> <span class="hidden sm:block h-px w-12" style="background: linear-gradient(to right, transparent, rgba(163,126,44,0.6));" aria-hidden="true"></span> <p class="font-sans text-[10px] sm:text-[11px] font-semibold tracking-[0.22em] uppercase text-brand-gold-soft"> ', ' </p> <span class="hidden sm:block h-px w-12" style="background: linear-gradient(to left, transparent, rgba(163,126,44,0.6));" aria-hidden="true"></span> </div> <!-- H1 \u2014 three-line cinematic; line 2 is the emotional accent --> <h1 id="hero-headline" class="font-display font-extra-light text-white leading-[1.04] tracking-[-0.02em] mb-4 sm:mb-6" style="font-size: clamp(2rem, 5.2vw + 0.35rem, 4.25rem);"> <span class="ecl-anim ecl-anim-fade-up ecl-delay-2 block">', '</span> <span class="ecl-anim ecl-anim-fade-up ecl-delay-3 block text-brand-gold-soft" style="font-style: italic;"> ', ' </span> </h1> <!-- Tagline --> <p class="ecl-anim ecl-anim-fade-up ecl-delay-5 font-sans font-light text-white/75 leading-relaxed tracking-[0.01em] mb-4 sm:mb-8 mx-auto max-w-xl" style="font-size: clamp(0.95rem, 1.6vw, 1.075rem);"> ', ' </p> <!-- CTAs (plain HTML, group role for screen readers) --> <div class="ecl-anim ecl-anim-fade-up ecl-delay-6 mb-10 sm:mb-12 flex flex-col sm:flex-row items-center justify-center gap-3 sm:gap-4" role="group" aria-label="Booking options"> <a', "", ' data-cta="hero_book_now"', ' class="ecl-btn-primary ecl-focusable inline-flex items-center justify-center gap-2 w-full sm:w-auto min-h-[52px] px-8 font-sans text-[11px] font-semibold tracking-[0.2em] uppercase bg-brand-gold-soft text-brand-forest border border-brand-gold-soft rounded-sm"> ', ' <span aria-hidden="true" class="ecl-arrow">\u2192</span> </a> <a', "", "", "", ' class="ecl-btn-secondary ecl-focusable inline-flex items-center justify-center gap-2 w-full sm:w-auto min-h-[52px] px-8 font-sans text-[11px] font-semibold tracking-[0.2em] uppercase bg-transparent text-white border border-white/40 hover:border-white/70 rounded-sm"> ', ' <span class="tabular-nums">', '</span> </a> </div> <!-- Trust strip --> <div class="ecl-anim ecl-anim-fade-in ecl-delay-7"> <div class="mx-auto mb-6 w-px h-6 opacity-30 bg-brand-gold-soft" aria-hidden="true"></div> <ul class="flex flex-wrap items-center justify-center gap-x-6 gap-y-3 sm:gap-x-8 list-none p-0 m-0" role="list" aria-label="Service credentials"> ', " </ul> </div> </div> </div> <!-- Scroll indicator --> ", ` <!-- Bottom decorative gold rule --> <div class="absolute bottom-0 left-0 right-0 h-px" style="background: linear-gradient(90deg, transparent, rgba(163,126,44,0.3), transparent);" aria-hidden="true"></div> </section> <!-- Inline analytics (zero JS framework cost) --> <script>
  document.querySelectorAll('a[data-cta]').forEach((el) => {
    el.addEventListener('click', () => {
      const label = el.getAttribute('data-cta');
      if (window.gtag) window.gtag('event', 'click', { event_category: 'hero_cta', event_label: label });
    });
  });
<\/script>`])), maybeRenderHead(), image.srcMobile && renderTemplate`<source media="(max-width: 767px)"${addAttribute(image.srcMobile, "srcset")} type="image/webp">`, addAttribute(image.src, "src"), addAttribute(image.alt, "alt"), addAttribute(image.width ?? 1920, "width"), addAttribute(image.height ?? 1080, "height"), eyebrow, headline, headlineAccent, tagline, addAttribute(ctaPrimary.href, "href"), addAttribute(ctaPrimary.id ?? "cta-hero-primary", "id"), addAttribute(`${ctaPrimary.label} \u2014 Emerald City Limos`, "aria-label"), ctaPrimary.label, addAttribute(phone ? telHref : ctaSecondary.href, "href"), addAttribute(ctaSecondary.id ?? "cta-hero-secondary", "id"), addAttribute(phone ? "hero_call_now" : "hero_secondary", "data-cta"), addAttribute(phone ? `Call us at ${phone}` : `${ctaSecondary.label} \u2014 Emerald City Limos`, "aria-label"), phone && renderTemplate`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" width="14" height="14" aria-hidden="true"> <path stroke-linecap="round" stroke-linejoin="round" d="M2.25 6.75c0 8.284 6.716 15 15 15h2.25a2.25 2.25 0 002.25-2.25v-1.372c0-.516-.351-.966-.852-1.091l-4.423-1.106c-.44-.11-.902.055-1.173.417l-.97 1.293c-.282.376-.769.542-1.21.38a12.035 12.035 0 01-7.143-7.143c-.162-.441.004-.928.38-1.21l1.293-.97c.363-.271.527-.734.417-1.173L6.963 3.102a1.125 1.125 0 00-1.091-.852H4.5A2.25 2.25 0 002.25 4.5v2.25z"></path> </svg>`, phone ?? ctaSecondary.label, trustIndicators.map((item) => renderTemplate`<li class="flex items-center gap-2 text-white/60 hover:text-white/85 font-sans text-[10px] sm:text-[11px] font-medium tracking-[0.14em] uppercase transition-colors duration-300"> <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" width="13" height="13" class="text-brand-gold flex-shrink-0" aria-hidden="true"> <path stroke-linecap="round" stroke-linejoin="round"${addAttribute(ICON_PATHS[item.icon], "d")}></path> </svg> ${item.label} </li>`), showScrollIndicator && renderTemplate`<div class="ecl-anim ecl-anim-fade-in ecl-delay-8 hidden sm:flex flex-col items-center pb-8 gap-2" aria-hidden="true"> <span class="font-sans text-[9px] font-medium tracking-[0.2em] uppercase text-white/30">
Scroll
</span> <span class="ecl-scroll-indicator flex flex-col items-center gap-1"> <span class="block w-px h-8" style="background: linear-gradient(to bottom, rgba(163,126,44,0.5), transparent);"></span> <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" width="12" height="12" class="text-brand-gold/60"> <path stroke-linecap="round" stroke-linejoin="round" d="M19.5 8.25l-7.5 7.5-7.5-7.5"></path> </svg> </span> </div>`);
}, "/home/josh/Documents/emerald-update/src/components/hero/Hero.astro", void 0);

const fleet = [
  {
    id: "escalade-esv",
    name: "Cadillac Escalade ESV",
    category: "Luxury SUV",
    capacity: 6,
    capacityLabel: "Up to 6 passengers",
    features: [
      "Massaging executive seats",
      "Bose Studio audio",
      "Ambient cabin lighting",
      "Extended wheelbase"
    ],
    bestFor: ["Corporate", "VIP transport", "Airport"],
    imageSrc: "/images/cadl2.webp",
    imageAlt: "Black Cadillac Escalade ESV luxury SUV — Emerald City Limos chauffeur fleet",
    featured: true,
    href: "/fleet#escalade-esv"
  },
  {
    id: "navigator-l",
    name: "Lincoln Navigator L",
    category: "SUV",
    capacity: 6,
    capacityLabel: "Up to 6 passengers",
    features: [
      "Premium leather interior",
      "Panoramic roof",
      "In-vehicle WiFi",
      "Dual climate zones"
    ],
    bestFor: ["Airport transfers", "Corporate groups"],
    // imageSrc: '/images/fleet/navigator.webp',
    imageAlt: "Black Lincoln Navigator L luxury SUV — Emerald City Limos chauffeur fleet",
    featured: false,
    href: "/fleet#navigator-l"
  },
  {
    id: "sprinter",
    name: "Mercedes-Benz Sprinter",
    category: "Executive Van",
    capacity: 12,
    capacityLabel: "Up to 12 passengers",
    features: [
      "Club seating",
      "Privacy glass",
      "USB charging at every seat",
      "Bar setup"
    ],
    bestFor: ["Groups", "Events", "Wine tours"],
    imageSrc: "/images/SPRINTER.jpeg",
    imageAlt: "Mercedes-Benz Sprinter executive edition van — Emerald City Limos chauffeur fleet",
    featured: false,
    href: "/fleet#sprinter"
  },
  {
    id: "s-class-s580",
    name: "Mercedes-Benz S‑Class S580",
    category: "Luxury Sedan",
    capacity: 3,
    capacityLabel: "Up to 3 passengers",
    features: [
      "Executive rear seating",
      "Burmester surround audio",
      "Seat massage",
      "Ambient cabin lighting"
    ],
    bestFor: ["Solo executive travel", "Airport", "VIP"],
    imageSrc: "/images/merc.webp",
    imageAlt: "Mercedes-Benz S-Class S580 luxury sedan — Emerald City Limos chauffeur fleet",
    featured: false,
    href: "/fleet#s-class-s580"
  },
  {
    id: "town-car-stretch",
    name: "Lincoln Town Car Stretch",
    category: "Limousine",
    capacity: 10,
    capacityLabel: "Up to 10 passengers",
    features: [
      "Fiber-optic lighting",
      "Wet bar",
      "Privacy divider",
      "Rear entertainment system"
    ],
    bestFor: ["Weddings", "Proms", "Special occasions"],
    imageSrc: "/images/party1.webp",
    imageAlt: "Lincoln Town Car stretch limousine — Emerald City Limos chauffeur fleet",
    featured: false,
    href: "/fleet#town-car-stretch"
  }
];
const defaultFeaturedId = "escalade-esv";
const fleetCategoryTabs = [
  { value: "All", label: "All" },
  { value: "Luxury Sedan", label: "Sedan" },
  { value: "SUV", label: "SUV" },
  { value: "Luxury SUV", label: "Luxury SUV" },
  { value: "Executive Van", label: "Van" },
  { value: "Limousine", label: "Limousine" }
];

const $$Astro$2 = createAstro("https://emeraldcitylimos.com");
const $$FleetFeaturedCard = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$2, $$props, $$slots);
  Astro2.self = $$FleetFeaturedCard;
  const { vehicle } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<article data-fleet-featured${addAttribute(vehicle.category, "data-category")} role="article"${addAttribute(`${vehicle.name} \u2014 ${vehicle.category}`, "aria-label")} class="group relative flex h-full flex-col overflow-hidden border-l-2 border-brand-gold bg-white shadow-[0_1px_0_0_rgba(10,35,24,0.04)] ring-1 ring-brand-forest/10 transition-shadow duration-500 hover:ring-brand-gold/40">  <div class="relative aspect-[16/9] w-full overflow-hidden bg-brand-forest"> ${vehicle.imageSrc ? renderTemplate`<img${addAttribute(vehicle.imageSrc, "src")}${addAttribute(vehicle.imageAlt, "alt")} loading="lazy" decoding="async" width="1280" height="720" class="absolute inset-0 h-full w-full object-cover object-center transition-transform duration-700 ease-out group-hover:scale-[1.02]">` : renderTemplate`<div class="absolute inset-0 flex items-center justify-center" aria-hidden="true"> <span class="absolute inset-0" style="background: radial-gradient(ellipse 60% 55% at center, var(--color-brand-gold-soft) 0%, transparent 70%); opacity: 0.18;"></span> <span class="absolute left-5 top-5 h-px w-10 bg-brand-gold/50"></span> <span class="absolute left-5 top-5 h-10 w-px bg-brand-gold/50"></span> <span class="absolute bottom-5 right-5 h-px w-10 bg-brand-gold/50"></span> <span class="absolute bottom-5 right-5 h-10 w-px bg-brand-gold/50"></span> <span class="relative font-sans text-xs font-semibold uppercase tracking-[0.22em] text-brand-gold-soft"> ${vehicle.category} </span> </div>`} </div>  <div class="flex flex-1 flex-col gap-5 p-7 sm:p-9 lg:p-10"> <div class="flex items-center justify-between gap-4"> <p class="font-sans text-xs font-semibold uppercase tracking-[0.22em] text-brand-gold"> ${vehicle.category} </p> <span class="inline-flex items-center border border-brand-forest/15 px-3 py-1 font-sans text-[11px] font-medium uppercase tracking-[0.18em] text-brand-forest tabular-nums"> ${vehicle.capacity} pax
</span> </div> <h3 class="font-display text-3xl font-light leading-[1.1] tracking-tight text-brand-forest sm:text-4xl"> ${vehicle.name} </h3> <p class="font-sans text-sm font-light text-neutral-600"> ${vehicle.capacityLabel} &middot; ${vehicle.bestFor.join(" \xB7 ")} </p> <ul role="list" class="mt-1 grid grid-cols-1 gap-x-6 gap-y-2.5 sm:grid-cols-2"> ${vehicle.features.map((f) => renderTemplate`<li class="flex items-start gap-3 font-sans text-sm font-light text-neutral-700"> <span aria-hidden="true" class="mt-2 h-px w-3 flex-shrink-0 bg-brand-gold"></span> <span>${f}</span> </li>`)} </ul> <div class="mt-3 flex flex-wrap items-center gap-x-6 gap-y-3 border-t border-brand-forest/10 pt-6"> <a href="/book-now" data-cta="fleet_featured_book"${addAttribute(`Book the ${vehicle.name}`, "aria-label")} class="ecl-btn-primary ecl-focusable inline-flex min-h-[48px] items-center gap-2 border border-brand-gold-soft bg-brand-gold-soft px-7 font-sans text-xs font-semibold uppercase tracking-[0.2em] text-brand-forest">
Book This Vehicle
<span class="ecl-arrow" aria-hidden="true">&rarr;</span> </a> <a${addAttribute(vehicle.href, "href")} class="ecl-focusable inline-flex items-center gap-2 border-b border-brand-gold pb-1 font-sans text-xs font-semibold uppercase tracking-[0.2em] text-brand-forest transition-colors duration-300 hover:text-brand-gold">
Vehicle details
<span aria-hidden="true">&rarr;</span> </a> </div> </div> </article>`;
}, "/home/josh/Documents/emerald-update/src/components/fleet/FleetFeaturedCard.astro", void 0);

const $$Astro$1 = createAstro("https://emeraldcitylimos.com");
const $$FleetCard = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$1, $$props, $$slots);
  Astro2.self = $$FleetCard;
  const { vehicle } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<article data-fleet-card${addAttribute(vehicle.category, "data-category")} role="article"${addAttribute(`${vehicle.name} \u2014 ${vehicle.category}`, "aria-label")} class="ecl-fleet-card group relative flex h-full flex-col overflow-hidden border-l-2 border-brand-gold/60 bg-white ring-1 ring-brand-forest/10 transition-[border-color,box-shadow] duration-300 hover:border-brand-gold hover:shadow-[0_8px_28px_-12px_rgba(10,35,24,0.18)] focus-within:border-brand-gold">  <a${addAttribute(vehicle.href, "href")} class="ecl-focusable absolute inset-0 z-10"${addAttribute(`View details for ${vehicle.name} (${vehicle.category}, ${vehicle.capacityLabel})`, "aria-label")}> <span class="sr-only">View details</span> </a>  <div class="relative aspect-[4/3] w-full overflow-hidden bg-brand-forest"> ${vehicle.imageSrc ? renderTemplate`<img${addAttribute(vehicle.imageSrc, "src")}${addAttribute(vehicle.imageAlt, "alt")} loading="lazy" decoding="async" width="800" height="600" class="absolute inset-0 h-full w-full object-cover object-center transition-transform duration-500 ease-out group-hover:scale-[1.03]">` : renderTemplate`<div class="absolute inset-0 flex items-center justify-center" aria-hidden="true"> <span class="absolute inset-0" style="background: radial-gradient(ellipse 60% 55% at center, var(--color-brand-gold-soft) 0%, transparent 70%); opacity: 0.16;"></span> <span class="absolute left-3 top-3 h-px w-6 bg-brand-gold/50"></span> <span class="absolute left-3 top-3 h-6 w-px bg-brand-gold/50"></span> <span class="absolute bottom-3 right-3 h-px w-6 bg-brand-gold/50"></span> <span class="absolute bottom-3 right-3 h-6 w-px bg-brand-gold/50"></span> <span class="relative font-sans text-[11px] font-semibold uppercase tracking-[0.22em] text-brand-gold-soft"> ${vehicle.category} </span> </div>`}  <span aria-hidden="true" class="ecl-fleet-card__reveal pointer-events-none absolute inset-x-0 bottom-0 flex translate-y-full items-center justify-between bg-brand-forest/92 px-4 py-3 font-sans text-xs font-semibold uppercase tracking-[0.2em] text-white opacity-0 transition-[transform,opacity] duration-300 ease-out group-hover:translate-y-0 group-hover:opacity-100 group-focus-within:translate-y-0 group-focus-within:opacity-100">
View Details
<span class="text-brand-gold-soft">&rarr;</span> </span> </div>  <div class="flex flex-1 flex-col gap-2 p-5 sm:p-6"> <p class="font-sans text-[11px] font-semibold uppercase tracking-[0.22em] text-brand-gold"> ${vehicle.category} </p> <h3 class="font-display text-xl font-medium leading-snug text-brand-forest transition-colors duration-300 group-hover:text-brand-gold"> ${vehicle.name} </h3> <p class="font-sans text-xs font-light text-neutral-600 tabular-nums"> ${vehicle.capacityLabel} </p> </div> </article>`;
}, "/home/josh/Documents/emerald-update/src/components/fleet/FleetCard.astro", void 0);

function FleetFilterTabs({
  tabs,
  initial = "All",
  layoutSelector = "[data-fleet-layout]"
}) {
  const [active, setActive] = useState(initial);
  const buttonRefs = useRef([]);
  useEffect(() => {
    if (typeof document === "undefined") return;
    const layout = document.querySelector(layoutSelector);
    if (!layout) return;
    layout.dataset.activeCategory = active;
    const featured = layout.querySelector("[data-fleet-featured-wrap]");
    if (featured) {
      featured.hidden = active !== "All";
    }
    const cards = layout.querySelectorAll("[data-fleet-card-wrap]");
    cards.forEach((wrap) => {
      const cat = wrap.dataset.category ?? "";
      wrap.hidden = active !== "All" && cat !== active;
    });
  }, [active, layoutSelector]);
  function onKeyDown(e) {
    const idx = tabs.findIndex((t) => t.value === active);
    if (idx < 0) return;
    let next = idx;
    if (e.key === "ArrowRight" || e.key === "ArrowDown") {
      next = (idx + 1) % tabs.length;
    } else if (e.key === "ArrowLeft" || e.key === "ArrowUp") {
      next = (idx - 1 + tabs.length) % tabs.length;
    } else if (e.key === "Home") {
      next = 0;
    } else if (e.key === "End") {
      next = tabs.length - 1;
    } else {
      return;
    }
    e.preventDefault();
    const nextValue = tabs[next].value;
    setActive(nextValue);
    buttonRefs.current[next]?.focus();
  }
  return /* @__PURE__ */ jsx(
    "div",
    {
      role: "tablist",
      "aria-label": "Filter vehicles by category",
      onKeyDown,
      className: "flex flex-wrap items-center justify-center gap-x-7 gap-y-3 sm:gap-x-9",
      children: tabs.map((tab, i) => {
        const isActive = active === tab.value;
        return /* @__PURE__ */ jsxs(
          "button",
          {
            type: "button",
            role: "tab",
            id: `fleet-tab-${tab.value.replace(/\s+/g, "-").toLowerCase()}`,
            "aria-selected": isActive,
            tabIndex: isActive ? 0 : -1,
            ref: (el) => {
              buttonRefs.current[i] = el;
            },
            onClick: () => setActive(tab.value),
            className: "ecl-focusable group relative inline-flex items-center pb-2 font-sans text-xs font-medium uppercase tracking-[0.2em] transition-colors duration-300",
            children: [
              /* @__PURE__ */ jsx(
                "span",
                {
                  className: isActive ? "text-brand-forest" : "text-neutral-500 group-hover:text-brand-forest",
                  children: tab.label
                }
              ),
              /* @__PURE__ */ jsx(
                "span",
                {
                  "aria-hidden": "true",
                  className: `absolute inset-x-0 bottom-0 h-px origin-center bg-brand-gold transition-transform duration-500 ease-out ${isActive ? "scale-x-100" : "scale-x-0"}`
                }
              )
            ]
          },
          tab.value
        );
      })
    }
  );
}

const $$Astro = createAstro("https://emeraldcitylimos.com");
const $$FleetSection = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$FleetSection;
  const { featuredId = defaultFeaturedId, showFilters = true } = Astro2.props;
  const featured = fleet.find((v) => v.id === featuredId) ?? fleet[0];
  const supporting = fleet.filter((v) => v.id !== featured.id);
  return renderTemplate`${maybeRenderHead()}<section class="ecl-fleet-section relative bg-brand-champagne py-20 sm:py-24 lg:py-32" aria-labelledby="fleet-heading" data-astro-cid-2dvte3xk> <div class="mx-auto max-w-7xl px-6 sm:px-8" data-astro-cid-2dvte3xk>  <header class="mx-auto mb-12 max-w-2xl text-center sm:mb-14 lg:mb-16" data-astro-cid-2dvte3xk> <p class="font-sans text-xs font-semibold uppercase tracking-[0.22em] text-brand-gold" data-astro-cid-2dvte3xk>
Our Fleet
</p> <h2 id="fleet-heading" class="mt-4 font-display text-3xl font-light leading-[1.08] tracking-tight text-brand-forest sm:text-4xl lg:text-5xl" data-astro-cid-2dvte3xk>
Travel in Absolute
<em class="italic text-brand-gold" data-astro-cid-2dvte3xk>Comfort</em>.
</h2> <p class="mt-5 font-sans text-base font-light leading-relaxed text-neutral-700 sm:text-lg" data-astro-cid-2dvte3xk>
Five distinct vehicles. One consistent standard &mdash; meticulously
        maintained, professionally chauffeured, ready when you are.
</p> </header>  ${showFilters && renderTemplate`<div class="mb-12 flex justify-center sm:mb-14" data-astro-cid-2dvte3xk> ${renderComponent($$result, "FleetFilterTabs", FleetFilterTabs, { "client:visible": true, "tabs": fleetCategoryTabs, "client:component-hydration": "visible", "client:component-path": "/home/josh/Documents/emerald-update/src/components/fleet/FleetFilterTabs", "client:component-export": "FleetFilterTabs", "data-astro-cid-2dvte3xk": true })} </div>`}  <div data-fleet-layout data-active-category="All" class="grid grid-cols-1 gap-6 lg:grid-cols-12 lg:gap-8" data-astro-cid-2dvte3xk>  <div data-fleet-featured-wrap${addAttribute(featured.category, "data-category")} class="lg:col-span-7 xl:col-span-8" data-astro-cid-2dvte3xk> ${renderComponent($$result, "FleetFeaturedCard", $$FleetFeaturedCard, { "vehicle": featured, "data-astro-cid-2dvte3xk": true })} </div>  <div data-fleet-supporting class="lg:col-span-5 xl:col-span-4" data-astro-cid-2dvte3xk> <ul role="list" class="ecl-fleet-rail -mx-6 flex snap-x snap-mandatory gap-4 overflow-x-auto px-6 pb-3 sm:mx-0 sm:grid sm:grid-cols-2 sm:gap-5 sm:overflow-visible sm:px-0 sm:pb-0" data-astro-cid-2dvte3xk> ${supporting.map((v) => renderTemplate`<li data-fleet-card-wrap${addAttribute(v.category, "data-category")} class="w-[78%] flex-shrink-0 snap-start sm:w-auto" data-astro-cid-2dvte3xk> ${renderComponent($$result, "FleetCard", $$FleetCard, { "vehicle": v, "data-astro-cid-2dvte3xk": true })} </li>`)} </ul> </div> </div>  <div class="mt-16 text-center sm:mt-20" data-astro-cid-2dvte3xk> <p class="font-sans text-base font-light text-neutral-700" data-astro-cid-2dvte3xk>
Explore our complete fleet of luxury vehicles.
</p> <a href="/fleet" data-cta="fleet_view_all" class="ecl-focusable mt-6 inline-flex min-h-[48px] items-center justify-center gap-2 border border-brand-forest bg-transparent px-8 font-sans text-xs font-semibold uppercase tracking-[0.2em] text-brand-forest transition-colors duration-300 hover:bg-brand-forest hover:text-white" data-astro-cid-2dvte3xk>
View Full Fleet
<span aria-hidden="true" data-astro-cid-2dvte3xk>&rarr;</span> </a> </div> </div> </section> `;
}, "/home/josh/Documents/emerald-update/src/components/fleet/FleetSection.astro", void 0);

const $$Index = createComponent(($$result, $$props, $$slots) => {
  const PHONE_DISPLAY = "(206) 595-9675";
  const PHONE_TEL = "tel:+12065959675";
  const services = [
    {
      href: "/airport-transfers",
      title: "Airport Transfers",
      blurb: "Flat-rate SeaTac and Boeing Field service. Flight tracking and meet-and-greet 24/7.",
      icon: "plane"
    },
    {
      href: "/service/executive-transportation",
      title: "Executive Transport",
      blurb: "Discreet black-car service for Seattle business travel and corporate events.",
      icon: "briefcase"
    },
    {
      href: "/service/wedding-transportation",
      title: "Weddings",
      blurb: "Red-carpet arrivals, bridal-party logistics, and venue coordination.",
      icon: "rings"
    },
    {
      href: "/service/hourly-charters",
      title: "Hourly Charters",
      blurb: "Flexible by-the-hour service for tours, meetings, and a night on the town.",
      icon: "clock"
    },
    {
      href: "/service/cruise-transportation",
      title: "Cruise Transfers",
      blurb: "Smith Cove and Bell Street pier transfers, luggage handled.",
      icon: "ship"
    },
    {
      href: "/service/game-day-transport",
      title: "Game Day",
      blurb: "Seahawks, Mariners, Sounders and Kraken \u2014 arrive without the parking.",
      icon: "trophy"
    },
    {
      href: "/service/special-occasions",
      title: "Special Occasions",
      blurb: "Birthdays, anniversaries, prom \u2014 every milestone in measured luxury.",
      icon: "sparkles"
    },
    {
      href: "/service/infant-car-seats",
      title: "Infant & Booster Seats",
      blurb: "Pre-installed, properly fitted car seats for safe family travel.",
      icon: "baby"
    }
  ];
  const ICONS = {
    plane: "M6 12L3.269 3.125A59.769 59.769 0 0121.485 12 59.768 59.768 0 013.27 20.875L5.999 12zm0 0h7.5",
    briefcase: "M20.25 14.15v4.07a2.25 2.25 0 01-2.25 2.25h-12a2.25 2.25 0 01-2.25-2.25v-4.07m16.5 0a24.094 24.094 0 01-8.25 1.45 24.094 24.094 0 01-8.25-1.45m16.5 0v-2.62a2.25 2.25 0 00-1.632-2.163l-3.05-.872a2.25 2.25 0 01-1.632-2.163V5.625A2.625 2.625 0 0014.625 3h-5.25A2.625 2.625 0 006.75 5.625v.755a2.25 2.25 0 01-1.632 2.163l-3.05.872A2.25 2.25 0 00.436 11.578v2.572m19.814 0H3.75",
    rings: "M21 12a9 9 0 11-18 0 9 9 0 0118 0zm-9-7.5l3.5 3-3.5 3-3.5-3 3.5-3z",
    clock: "M12 6v6h4.5m4.5 0a9 9 0 11-18 0 9 9 0 0118 0z",
    ship: "M21 12.75a9 9 0 11-18 0 9 9 0 0118 0zm-3 0H6m12 4.5H6m12-9H6",
    trophy: "M16.5 18.75h-9m9 0a3 3 0 013 3h-15a3 3 0 013-3m9 0v-3.375c0-.621-.503-1.125-1.125-1.125h-.871M7.5 18.75v-3.375c0-.621.504-1.125 1.125-1.125h.872m5.007 0H9.497m5.007 0a7.454 7.454 0 01-.982-3.172M9.497 14.25a7.454 7.454 0 00.981-3.172M5.25 4.236c-.982.143-1.954.317-2.916.52A6.003 6.003 0 007.73 9.728M5.25 4.236V4.5c0 2.108.966 3.99 2.48 5.228M5.25 4.236V2.721C7.456 2.41 9.71 2.25 12 2.25c2.291 0 4.545.16 6.75.47v1.516M7.73 9.728a6.726 6.726 0 002.748 1.35m8.272-6.842V4.5c0 2.108-.966 3.99-2.48 5.228m2.48-5.492a46.32 46.32 0 012.916.52 6.003 6.003 0 01-5.395 4.972m0 0a6.726 6.726 0 01-2.749 1.35m0 0a6.772 6.772 0 01-3.044 0",
    sparkles: "M9.813 15.904L9 18.75l-.813-2.846a4.5 4.5 0 00-3.09-3.09L2.25 12l2.846-.813a4.5 4.5 0 003.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 003.09 3.09L15.75 12l-2.846.813a4.5 4.5 0 00-3.09 3.09zM18.259 8.715L18 9.75l-.259-1.035a3.375 3.375 0 00-2.455-2.456L14.25 6l1.036-.259a3.375 3.375 0 002.455-2.456L18 2.25l.259 1.035a3.375 3.375 0 002.456 2.456L21.75 6l-1.035.259a3.375 3.375 0 00-2.456 2.456z",
    baby: "M15.182 16.318A4.486 4.486 0 0012.016 15a4.486 4.486 0 00-3.198 1.318M21 12a9 9 0 11-18 0 9 9 0 0118 0zM9.75 9.75c0 .414-.168.75-.375.75S9 10.164 9 9.75 9.168 9 9.375 9s.375.336.375.75zm-.375 0h.008v.015h-.008V9.75zm5.625 0c0 .414-.168.75-.375.75s-.375-.336-.375-.75.168-.75.375-.75.375.336.375.75zm-.375 0h.008v.015h-.008V9.75z"
  };
  const areas = [
    "Seattle",
    "Bellevue",
    "Redmond",
    "Kirkland",
    "Renton",
    "Tacoma",
    "Everett",
    "Lynnwood",
    "Edmonds",
    "Bothell",
    "Woodinville",
    "Auburn",
    "Federal Way",
    "Sammamish",
    "Kent",
    "Lakewood",
    "Puyallup",
    "Marysville",
    "SeaTac Airport",
    "Boeing Field"
  ];
  return renderTemplate`${renderComponent($$result, "MainLayout", $$MainLayout, { "title": "Seattle Limo Service | Airport Transfers & Black Car | Emerald City Limos", "description": "Seattle's premium luxury chauffeur service since 2010. Flat-rate SeaTac airport transfers, executive black-car service, weddings and special events. Licensed, insured, available 24/7.", "keywords": "seattle limo service, seatac airport limo, luxury car service seattle, black car service seattle, seattle airport transportation, corporate limo seattle, wedding limo seattle" }, { "default": ($$result2) => renderTemplate`  ${renderComponent($$result2, "Hero", $$Hero, { "eyebrow": "Premium Chauffeur Service Across Major U.S. Cities", "headline": "Refined Chauffeur Experiences", "headlineAccent": "Wherever You Travel", "tagline": "Arrive impeccably. Every journey crafted with discretion, comfort, and absolute precision \u2014 since 2010.", "ctaPrimary": { label: "Reserve Your Ride", href: "/book-now", id: "cta-hero-book" }, "ctaSecondary": { label: PHONE_DISPLAY, href: PHONE_TEL, id: "cta-hero-call" }, "phone": PHONE_DISPLAY, "image": {
    src: "/images/emerald-hero.webp",
    srcMobile: "/images/hero-mobile.webp",
    alt: "Luxury black chauffeur vehicle at night in Seattle \u2014 Emerald City Limos premium fleet",
    width: 1672,
    height: 941
  } })}  ${maybeRenderHead()}<section class="relative bg-white py-20 sm:py-24 lg:py-32" aria-labelledby="services-heading"> <div class="mx-auto max-w-7xl px-6 sm:px-8"> <header class="mx-auto mb-14 max-w-2xl text-center sm:mb-16 lg:mb-20"> <p class="font-sans text-xs font-semibold uppercase tracking-widest text-brand-gold">
Our Services
</p> <h2 id="services-heading" class="mt-4 font-display text-3xl font-light leading-tight tracking-tight text-brand-forest sm:text-4xl lg:text-5xl">
Every journey,
<em class="italic text-brand-gold">perfected</em>.
</h2> <p class="mt-5 font-sans text-base font-light leading-relaxed text-neutral-700 sm:text-lg">
From SeaTac at dawn to a Pike Place wedding at dusk &mdash; white-glove transport for every occasion.
</p> </header> <ul role="list" class="grid grid-cols-1 gap-5 sm:grid-cols-2 sm:gap-6 lg:grid-cols-4"> ${services.map((s) => renderTemplate`<li> <a${addAttribute(s.href, "href")} class="ecl-focusable group relative flex h-full flex-col bg-white p-7 ring-1 ring-brand-forest/10 transition duration-300 hover:ring-brand-gold sm:p-8"> <span class="absolute inset-x-0 top-0 h-px origin-left scale-x-0 bg-brand-gold transition-transform duration-500 ease-out group-hover:scale-x-100 group-focus-visible:scale-x-100" aria-hidden="true"></span> <span class="mb-6 inline-flex h-12 w-12 items-center justify-center bg-brand-champagne text-brand-gold transition-colors duration-300 group-hover:bg-brand-gold group-hover:text-white"> <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.25" width="24" height="24" aria-hidden="true"> <path stroke-linecap="round" stroke-linejoin="round"${addAttribute(ICONS[s.icon], "d")}></path> </svg> </span> <h3 class="font-display text-2xl font-medium leading-snug text-brand-forest transition-colors duration-300 group-hover:text-brand-gold"> ${s.title} </h3> <p class="mt-3 font-sans text-sm leading-relaxed text-neutral-600"> ${s.blurb} </p> <span class="mt-auto inline-flex items-center gap-2 pt-6 font-sans text-xs font-semibold uppercase tracking-widest text-brand-forest transition-colors duration-300 group-hover:text-brand-gold">
Learn more
<span aria-hidden="true" class="transition-transform duration-300 group-hover:translate-x-1">&rarr;</span> </span> </a> </li>`)} </ul> <div class="mt-14 text-center sm:mt-16"> <a href="/services" class="ecl-focusable inline-flex items-center gap-2 border-b border-brand-gold pb-1 font-sans text-xs font-semibold uppercase tracking-widest text-brand-forest transition-colors hover:text-brand-gold">
View all services
<span aria-hidden="true">&rarr;</span> </a> </div> </div> </section> ${renderComponent($$result2, "FleetSection", $$FleetSection, {})}  <section class="bg-brand-champagne py-20 sm:py-28 px-6 sm:px-8" aria-labelledby="about-heading"> <div class="max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center"> <div class="lg:col-span-6"> <p class="font-sans text-[10px] sm:text-[11px] font-semibold tracking-[0.22em] uppercase text-brand-gold mb-5">
Established 2010
</p> <h2 id="about-heading" class="font-display font-light text-brand-forest leading-[1.08] tracking-[-0.015em] mb-6" style="font-size: clamp(2rem, 4vw, 3rem);">
A quieter standard of
<em class="text-brand-gold not-italic" style="font-style: italic;">arrival</em>.
</h2> <p class="font-sans text-base sm:text-lg leading-[1.75] text-neutral-700 mb-5 max-w-xl">
For over a decade, Emerald City Limos has served the Greater Seattle area with chauffeurs who anticipate, vehicles that perform, and a standard of service that doesn&rsquo;t announce itself.
</p> <p class="font-sans text-base sm:text-lg leading-[1.75] text-neutral-700 mb-8 max-w-xl">
Whether the destination is SeaTac at 4 a.m., a Pike Place wedding, a Seahawks Sunday, or a downtown board meeting — we deliver the same answer. Quietly, every time.
</p> <a href="/locations" class="inline-flex items-center gap-2 font-sans text-[11px] font-semibold tracking-[0.2em] uppercase text-brand-forest border-b border-brand-gold pb-1 hover:text-brand-gold transition-colors">
View all service areas
<span aria-hidden="true">→</span> </a> </div> <div class="lg:col-span-6"> <div class="relative"> <!-- Gold offset border for editorial feel --> <div class="absolute -top-3 -right-3 w-full h-full border border-brand-gold/40" aria-hidden="true"></div> <img src="/images/cad1.webp" alt="Emerald City Limos luxury Cadillac Escalade — Seattle chauffeur fleet" width="800" height="600" loading="lazy" decoding="async" class="relative w-full h-[360px] sm:h-[440px] object-cover"> </div> </div> </div> </section>  <section class="bg-brand-champagne py-20 sm:py-24 px-6 sm:px-8" aria-labelledby="areas-heading"> <div class="max-w-5xl mx-auto text-center"> <p class="font-sans text-[10px] sm:text-[11px] font-semibold tracking-[0.22em] uppercase text-brand-gold mb-4">
Coverage
</p> <h2 id="areas-heading" class="font-display font-light text-brand-forest leading-[1.08] tracking-[-0.015em] mb-4" style="font-size: clamp(1.75rem, 3.5vw, 2.5rem);">
Greater Seattle &mdash;
<em class="text-brand-gold not-italic" style="font-style: italic;">end to end</em>.
</h2> <p class="font-sans font-light text-neutral-700 mb-10 max-w-xl mx-auto">
Serving every major city across King, Snohomish and Pierce counties.
</p> <ul class="flex flex-wrap justify-center gap-2 sm:gap-3 list-none p-0" role="list"> ${areas.map((area) => renderTemplate`<li> <span class="inline-flex items-center px-4 py-2 font-sans text-[11px] sm:text-xs font-medium tracking-[0.08em] text-brand-forest bg-white border border-brand-forest/15 hover:border-brand-gold transition-colors duration-300"> ${area} </span> </li>`)} </ul> <div class="mt-10"> <a href="/locations" class="inline-flex items-center gap-2 font-sans text-[11px] font-semibold tracking-[0.2em] uppercase text-brand-forest border-b border-brand-gold pb-1 hover:text-brand-gold transition-colors">
View all locations
<span aria-hidden="true">→</span> </a> </div> </div> </section>  <section class="relative bg-brand-forest py-20 sm:py-28 px-6 sm:px-8 overflow-hidden" aria-labelledby="cta-heading"> <!-- Top decorative gold rule --> <div class="absolute top-0 left-0 right-0 h-px" style="background: linear-gradient(90deg, transparent, rgba(195,154,69,0.5), transparent);" aria-hidden="true"></div> <div class="max-w-3xl mx-auto text-center"> <p class="font-sans text-[10px] sm:text-[11px] font-semibold tracking-[0.22em] uppercase text-brand-gold-soft mb-5">
Reserve Now
</p> <h2 id="cta-heading" class="font-display font-light text-white leading-[1.08] tracking-[-0.015em] mb-6" style="font-size: clamp(2rem, 4.5vw, 3.25rem);">
Ready to ride
<em class="text-brand-gold-soft not-italic" style="font-style: italic;">in luxury?</em> </h2> <p class="font-sans font-light text-white/75 leading-relaxed mb-10 max-w-xl mx-auto">
Book online in under 60 seconds — or speak to a chauffeur dispatcher 24/7.
</p> <div class="flex flex-col sm:flex-row gap-3 sm:gap-4 justify-center" role="group" aria-label="Booking options"> <a href="/book-now" data-cta="footer_book_now" aria-label="Reserve your ride — Emerald City Limos" class="ecl-btn-primary ecl-focusable inline-flex items-center justify-center gap-2 min-h-[52px] px-8 font-sans text-[11px] font-semibold tracking-[0.2em] uppercase bg-brand-gold-soft text-brand-forest border border-brand-gold-soft rounded-none">
Reserve Your Ride
<span aria-hidden="true" class="ecl-arrow">→</span> </a> <a${addAttribute(PHONE_TEL, "href")} data-cta="footer_call_now"${addAttribute(`Call us at ${PHONE_DISPLAY}`, "aria-label")} class="ecl-btn-secondary ecl-focusable inline-flex items-center justify-center gap-2 min-h-[52px] px-8 font-sans text-[11px] font-semibold tracking-[0.2em] uppercase bg-transparent text-white border border-white/40 hover:border-white/70 rounded-none"> <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" width="14" height="14" aria-hidden="true"> <path stroke-linecap="round" stroke-linejoin="round" d="M2.25 6.75c0 8.284 6.716 15 15 15h2.25a2.25 2.25 0 002.25-2.25v-1.372c0-.516-.351-.966-.852-1.091l-4.423-1.106c-.44-.11-.902.055-1.173.417l-.97 1.293c-.282.376-.769.542-1.21.38a12.035 12.035 0 01-7.143-7.143c-.162-.441.004-.928.38-1.21l1.293-.97c.363-.271.527-.734.417-1.173L6.963 3.102a1.125 1.125 0 00-1.091-.852H4.5A2.25 2.25 0 002.25 4.5v2.25z"></path> </svg> <span class="tabular-nums">${PHONE_DISPLAY}</span> </a> </div> </div> <!-- Bottom decorative gold rule --> <div class="absolute bottom-0 left-0 right-0 h-px" style="background: linear-gradient(90deg, transparent, rgba(195,154,69,0.3), transparent);" aria-hidden="true"></div> </section> ` })}`;
}, "/home/josh/Documents/emerald-update/src/pages/index.astro", void 0);

const $$file = "/home/josh/Documents/emerald-update/src/pages/index.astro";
const $$url = "";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$Index,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };

import { a as createComponent, b as renderComponent, r as renderTemplate, u as unescapeHTML, d as addAttribute, m as maybeRenderHead } from '../chunks/astro/server_Cr-soRLN.mjs';
import 'piccolore';
import { l as locations, $ as $$LocationLayout, a as $$LocationCTA } from '../chunks/locations_CEsRFxJ4.mjs';
import { a as $$TrustStrip, $ as $$PageHero } from '../chunks/TrustStrip_BQ1W8xK4.mjs';
export { renderers } from '../renderers.mjs';

var __freeze = Object.freeze;
var __defProp = Object.defineProperty;
var __template = (cooked, raw) => __freeze(__defProp(cooked, "raw", { value: __freeze(cooked.slice()) }));
var _a;
const $$Index = createComponent(($$result, $$props, $$slots) => {
  const title = "Service Areas | Emerald City Limos";
  const description = "Luxury chauffeur and black-car service across the Seattle metro \u2014 King, Pierce, and Snohomish counties. 20 service areas including SEA-TAC, Boeing Field, Bellevue, Tacoma, and Everett.";
  const keywords = "seattle chauffeur service areas, bellevue limo, tacoma chauffeur, sea-tac airport transfer, eastside black car service";
  const canonical = "https://emeraldcitylimos.com/locations";
  const byCounty = locations.reduce((acc, loc) => {
    (acc[loc.county] ??= []).push(loc);
    return acc;
  }, {});
  const COUNTY_ORDER = ["King County", "Pierce County", "Snohomish County"];
  const orderedCounties = [
    ...COUNTY_ORDER.filter((c) => byCounty[c]),
    ...Object.keys(byCounty).filter((c) => !COUNTY_ORDER.includes(c))
  ];
  const ctaLocation = {
    name: "the Pacific Northwest",
    slug: "all",
    county: "Washington",
    coordinates: { lat: 47.6062, lng: -122.3321 },
    zipCodes: [],
    heroImage: "",
    heroImageAlt: "",
    heroSupporting: "",
    localValueProp: "",
    nearbyLandmarks: [],
    airportProximity: [],
    popularRoutes: [],
    faqs: [],
    meta: { title: "", description: "", keywords: [] }
  };
  return renderTemplate`${renderComponent($$result, "LocationLayout", $$LocationLayout, { "title": title, "description": description, "keywords": keywords, "canonical": canonical }, { "default": ($$result2) => renderTemplate(_a || (_a = __template([" ", " ", "  ", '<section class="bg-brand-champagne py-16 sm:py-20 lg:py-24" aria-label="All service areas"> <div class="mx-auto max-w-7xl px-6 sm:px-8 lg:px-12"> ', " </div> </section>  ", '  <script type="application/ld+json">', "<\/script> "])), renderComponent($$result2, "PageHero", $$PageHero, { "eyebrow": "Service Areas", "headline": "Luxury chauffeur service", "headlineAccent": "across the Pacific Northwest", "supporting": `${locations.length} service areas across King, Pierce, and Snohomish counties \u2014 including SEA-TAC, Boeing Field, and Paine Field. Flat-rate pricing, flight-tracked airport pickups, business-attired chauffeurs.`, "size": "page", "id": "locations-hero", "breadcrumbs": [{ label: "Home", href: "/" }, { label: "Locations" }] }), renderComponent($$result2, "TrustStrip", $$TrustStrip, {}), maybeRenderHead(), orderedCounties.map((county) => renderTemplate`<div class="mb-14 last:mb-0"> <!-- County heading --> <div class="mb-8 flex items-end justify-between gap-4"> <h2 class="font-display text-2xl font-light text-brand-forest sm:text-3xl"> ${county} </h2> <span class="font-sans text-xs uppercase tracking-[0.2em] text-brand-forest/50 tabular-nums"> ${byCounty[county].length} ${byCounty[county].length === 1 ? "area" : "areas"} </span> </div> <!-- Grid --> <ul class="m-0 grid list-none gap-4 p-0 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4"> ${byCounty[county].map((loc) => renderTemplate`<li> <a${addAttribute(`/locations/${loc.slug}`, "href")} class="ecl-focusable group flex h-full flex-col gap-2 border-l-2 border-brand-gold/60 bg-white p-5 ring-1 ring-brand-forest/10 transition-[border-color,box-shadow] duration-300 hover:border-brand-gold hover:shadow-[0_8px_28px_-12px_rgba(10,35,24,0.18)]"${addAttribute(`${loc.name} chauffeur service \u2014 view details`, "aria-label")}> <h3 class="font-display text-xl font-medium leading-snug text-brand-forest transition-colors duration-300 group-hover:text-brand-gold"> ${loc.name} </h3> <p class="font-sans text-xs uppercase tracking-[0.18em] text-brand-forest/55"> ${loc.county} </p> <p class="mt-2 font-sans text-sm leading-relaxed text-brand-forest/75 line-clamp-3"> ${loc.heroSupporting} </p> <span class="mt-auto inline-flex items-center gap-1.5 pt-3 font-sans text-[11px] font-semibold uppercase tracking-[0.2em] text-brand-gold">
View details
<span aria-hidden="true" class="transition-transform duration-300 group-hover:translate-x-0.5">→</span> </span> </a> </li>`)} </ul> </div>`), renderComponent($$result2, "LocationCTA", $$LocationCTA, { "location": ctaLocation }), unescapeHTML(JSON.stringify({
    "@context": "https://schema.org",
    "@graph": [
      {
        "@type": "BreadcrumbList",
        itemListElement: [
          { "@type": "ListItem", position: 1, name: "Home", item: "https://emeraldcitylimos.com" },
          { "@type": "ListItem", position: 2, name: "Service Areas", item: canonical }
        ]
      },
      {
        "@type": "ItemList",
        name: "Emerald City Limos service areas",
        numberOfItems: locations.length,
        itemListElement: locations.map((loc, i) => ({
          "@type": "ListItem",
          position: i + 1,
          url: `https://emeraldcitylimos.com/locations/${loc.slug}`,
          name: loc.name
        }))
      }
    ]
  }))) })}`;
}, "/home/josh/Documents/emerald-update/src/pages/locations/index.astro", void 0);

const $$file = "/home/josh/Documents/emerald-update/src/pages/locations/index.astro";
const $$url = "/locations";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$Index,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };

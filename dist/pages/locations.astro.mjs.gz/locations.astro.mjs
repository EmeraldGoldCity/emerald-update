import { c as createComponent, r as renderComponent, a as renderTemplate } from '../chunks/astro/server_7-PjRNDj.mjs';
import 'piccolore';
import { c as createLucideIcon, b as MapPin, $ as $$MainLayout } from '../chunks/MainLayout_BwP3NZXh.mjs';
import { jsxs, jsx } from 'react/jsx-runtime';
import 'react';
import { c as counties } from '../chunks/locations_DWBKRY71.mjs';
export { renderers } from '../renderers.mjs';

/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const __iconNode = [
  [
    "path",
    {
      d: "M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",
      key: "oel41y"
    }
  ]
];
const Shield = createLucideIcon("shield", __iconNode);

const seattleBackground = "/images/seattle-landmark.jpg";
function LocationsPage() {
  return /* @__PURE__ */ jsxs("div", { className: "min-h-screen bg-white", children: [
    /* @__PURE__ */ jsxs("section", { className: "relative bg-gradient-to-r from-emerald-900 to-emerald-800 text-white py-20 overflow-hidden", children: [
      /* @__PURE__ */ jsx("div", { className: "absolute inset-0", children: /* @__PURE__ */ jsx(
        "img",
        {
          src: seattleBackground,
          alt: "Seattle Background",
          className: "w-full h-full object-cover object-center opacity-30",
          style: { objectPosition: "center" }
        }
      ) }),
      /* @__PURE__ */ jsxs("div", { className: "relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center", children: [
        /* @__PURE__ */ jsxs("h1", { className: "text-5xl md:text-6xl font-bold mb-6", children: [
          /* @__PURE__ */ jsx("span", { className: "text-[#d4af37]", children: "Service" }),
          " Locations"
        ] }),
        /* @__PURE__ */ jsx("p", { className: "text-xl text-white max-w-3xl mx-auto", children: "We proudly serve the Greater Seattle area, including King, Snohomish, and Pierce counties, plus extended service to Eastern Washington." })
      ] })
    ] }),
    /* @__PURE__ */ jsxs("section", { className: "relative py-20", children: [
      /* @__PURE__ */ jsx("div", { className: "absolute inset-0 overflow-hidden", children: /* @__PURE__ */ jsx(
        "img",
        {
          src: seattleBackground,
          alt: "Seattle Background",
          className: "w-full h-full object-cover object-center opacity-5",
          style: { objectPosition: "center", minHeight: "100%", minWidth: "100%" }
        }
      ) }),
      /* @__PURE__ */ jsxs("div", { className: "relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8", children: [
        /* @__PURE__ */ jsxs("div", { className: "mb-16", children: [
          /* @__PURE__ */ jsxs("div", { className: "text-center mb-12", children: [
            /* @__PURE__ */ jsx("h2", { className: "text-4xl font-bold text-gray-900 mb-4", children: counties.king.name }),
            /* @__PURE__ */ jsx("p", { className: "text-xl text-gray-600", children: "Seattle and surrounding communities" })
          ] }),
          /* @__PURE__ */ jsx("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-8", children: counties.king.cities.map((city) => /* @__PURE__ */ jsxs(
            "a",
            {
              href: `/location/${city.slug}`,
              className: "group bg-white/95 backdrop-blur-sm border-2 border-emerald-200 rounded-lg overflow-hidden hover:border-emerald-500 hover:shadow-xl transition-all",
              children: [
                city.images && /* @__PURE__ */ jsx("div", { className: "h-40 overflow-hidden", children: /* @__PURE__ */ jsx("img", { src: city.images, alt: city.name, className: "w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" }) }),
                /* @__PURE__ */ jsx("div", { className: "p-7" }),
                /* @__PURE__ */ jsxs("div", { className: "flex items-start gap-3 mb-5", children: [
                  /* @__PURE__ */ jsx(MapPin, { className: "w-6 h-6 text-emerald-700 flex-shrink-0 mt-0.5" }),
                  /* @__PURE__ */ jsx("h3", { className: "text-lg font-bold text-gray-900 group-hover:text-emerald-700 transition-colors leading-snug", children: city.name })
                ] }),
                /* @__PURE__ */ jsx("p", { className: "text-gray-600 text-sm leading-relaxed pl-9", children: city.description })
              ]
            },
            city.slug
          )) })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "mb-16", children: [
          /* @__PURE__ */ jsxs("div", { className: "text-center mb-12", children: [
            /* @__PURE__ */ jsx("h2", { className: "text-4xl font-bold text-gray-900 mb-4", children: counties.snohomish.name }),
            /* @__PURE__ */ jsx("p", { className: "text-xl text-gray-600", children: "North Sound communities" })
          ] }),
          /* @__PURE__ */ jsx("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-8", children: counties.snohomish.cities.map((city) => /* @__PURE__ */ jsxs(
            "a",
            {
              href: `/location/${city.slug}`,
              className: "group bg-white/95 backdrop-blur-sm border-2 border-yellow-300 rounded-lg overflow-hidden hover:border-yellow-500 hover:shadow-xl transition-all",
              children: [
                city.images && /* @__PURE__ */ jsx("div", { className: "h-40 overflow-hidden", children: /* @__PURE__ */ jsx("img", { src: city.images, alt: city.name, className: "w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" }) }),
                /* @__PURE__ */ jsx("div", { className: "p-7" }),
                /* @__PURE__ */ jsxs("div", { className: "flex items-start gap-3 mb-5", children: [
                  /* @__PURE__ */ jsx(MapPin, { className: "w-6 h-6 text-emerald-700 flex-shrink-0 mt-0.5" }),
                  /* @__PURE__ */ jsx("h3", { className: "text-lg font-bold text-gray-900 group-hover:text-emerald-700 transition-colors leading-snug", children: city.name })
                ] }),
                /* @__PURE__ */ jsx("p", { className: "text-gray-600 text-sm leading-relaxed pl-9", children: city.description })
              ]
            },
            city.slug
          )) })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "mb-16", children: [
          /* @__PURE__ */ jsxs("div", { className: "text-center mb-12", children: [
            /* @__PURE__ */ jsx("h2", { className: "text-4xl font-bold text-gray-900 mb-4", children: counties.pierce.name }),
            /* @__PURE__ */ jsx("p", { className: "text-xl text-gray-600", children: "South Sound region" }),
            /* @__PURE__ */ jsx("div", { className: "mt-6 max-w-4xl mx-auto bg-gradient-to-r from-emerald-50 to-yellow-50 border-2 border-[#d4af37] rounded-lg p-6", children: /* @__PURE__ */ jsxs("div", { className: "flex items-start gap-4", children: [
              /* @__PURE__ */ jsx("div", { className: "flex-shrink-0", children: /* @__PURE__ */ jsx(Shield, { className: "w-8 h-8 text-emerald-700" }) }),
              /* @__PURE__ */ jsxs("div", { className: "text-left", children: [
                /* @__PURE__ */ jsx("h3", { className: "text-lg font-bold text-gray-900 mb-2", children: "Military Transportation Services" }),
                /* @__PURE__ */ jsx("p", { className: "text-gray-700", children: counties.pierce.description })
              ] })
            ] }) })
          ] }),
          /* @__PURE__ */ jsx("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-8", children: counties.pierce.cities.map((city) => /* @__PURE__ */ jsxs(
            "a",
            {
              href: `/location/${city.slug}`,
              className: "group bg-white/95 backdrop-blur-sm border-2 border-emerald-200 rounded-lg p-7 hover:border-emerald-500 hover:shadow-xl transition-all",
              children: [
                /* @__PURE__ */ jsxs("div", { className: "flex items-start gap-3 mb-5", children: [
                  /* @__PURE__ */ jsx(MapPin, { className: "w-6 h-6 text-emerald-700 flex-shrink-0 mt-0.5" }),
                  /* @__PURE__ */ jsx("h3", { className: "text-lg font-bold text-gray-900 group-hover:text-emerald-700 transition-colors leading-snug", children: city.name })
                ] }),
                /* @__PURE__ */ jsx("p", { className: "text-gray-600 text-sm leading-relaxed pl-9", children: city.description })
              ]
            },
            city.slug
          )) })
        ] }),
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsxs("div", { className: "text-center mb-12", children: [
            /* @__PURE__ */ jsx("h2", { className: "text-4xl font-bold text-gray-900 mb-4", children: counties.other.name }),
            /* @__PURE__ */ jsx("p", { className: "text-xl text-gray-600", children: "Eastern Washington destinations" })
          ] }),
          /* @__PURE__ */ jsx("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto", children: counties.other.cities.map((city) => /* @__PURE__ */ jsxs(
            "a",
            {
              href: `/location/${city.slug}`,
              className: "group bg-white/95 backdrop-blur-sm border-2 border-yellow-300 rounded-lg p-7 hover:border-yellow-500 hover:shadow-xl transition-all",
              children: [
                /* @__PURE__ */ jsxs("div", { className: "flex items-start gap-3 mb-5", children: [
                  /* @__PURE__ */ jsx(MapPin, { className: "w-6 h-6 text-yellow-600 flex-shrink-0 mt-0.5" }),
                  /* @__PURE__ */ jsx("h3", { className: "text-lg font-bold text-gray-900 group-hover:text-yellow-700 transition-colors leading-snug", children: city.name })
                ] }),
                /* @__PURE__ */ jsx("p", { className: "text-gray-600 text-sm leading-relaxed pl-9", children: city.description })
              ]
            },
            city.slug
          )) })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsx("section", { className: "py-20 bg-gradient-to-r from-emerald-900 to-emerald-800 text-white", children: /* @__PURE__ */ jsxs("div", { className: "max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8", children: [
      /* @__PURE__ */ jsx("h2", { className: "text-4xl font-bold mb-6", children: "Don't See Your Location?" }),
      /* @__PURE__ */ jsx("p", { className: "text-xl mb-8 text-gray-200", children: "We may still be able to serve you! Contact us to inquire about transportation to other areas." }),
      /* @__PURE__ */ jsxs("div", { className: "flex flex-col sm:flex-row gap-4 justify-center", children: [
        /* @__PURE__ */ jsx(
          "a",
          {
            href: "/book-now",
            className: "bg-[#d4af37] hover:bg-[#b8941f] text-black px-8 py-4 rounded-lg font-semibold transition-all",
            children: "BOOK NOW"
          }
        ),
        /* @__PURE__ */ jsx(
          "a",
          {
            href: "mailto:client@a1charterspnw.com",
            className: "bg-transparent border-2 border-white hover:bg-white hover:text-emerald-900 text-white px-8 py-4 rounded-lg font-semibold transition-all",
            children: "Email Us"
          }
        )
      ] })
    ] }) })
  ] });
}

const $$Locations = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "MainLayout", $$MainLayout, { "title": "Service Locations - Emerald City Limos Seattle Area Coverage", "description": "Emerald City Limos provides luxury limousine and black car service throughout King, Snohomish, and Pierce counties, plus Spokane and Wenatchee.", "keywords": "seattle limo service locations, king county car service, snohomish county limo, pierce county transportation, emerald city limos" }, { "default": ($$result2) => renderTemplate` ${renderComponent($$result2, "LocationsPage", LocationsPage, { "client:load": true, "client:component-hydration": "load", "client:component-path": "@/app/pages/LocationsPage", "client:component-export": "LocationsPage" })} ` })}`;
}, "/home/josh/Documents/emerald-update/src/pages/locations.astro", void 0);

const $$file = "/home/josh/Documents/emerald-update/src/pages/locations.astro";
const $$url = "/locations";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$Locations,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };

import { b as createAstro, c as createComponent, d as addAttribute, f as renderScript, a as renderTemplate, e as renderSlot, g as renderHead, u as unescapeHTML, r as renderComponent } from './astro/server_DL3Tye_C.mjs';
import 'piccolore';
/* empty css                          */
import 'clsx';
import { jsxs, Fragment, jsx } from 'react/jsx-runtime';
import { forwardRef, createElement, useState, useRef, useEffect, useCallback } from 'react';

const $$Astro$1 = createAstro("https://emeraldcitylimos.com");
const $$ClientRouter = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$1, $$props, $$slots);
  Astro2.self = $$ClientRouter;
  const { fallback = "animate" } = Astro2.props;
  return renderTemplate`<meta name="astro-view-transitions-enabled" content="true"><meta name="astro-view-transitions-fallback"${addAttribute(fallback, "content")}>${renderScript($$result, "/home/josh/Documents/emerald-update/node_modules/astro/components/ClientRouter.astro?astro&type=script&index=0&lang.ts")}`;
}, "/home/josh/Documents/emerald-update/node_modules/astro/components/ClientRouter.astro", void 0);

var __freeze = Object.freeze;
var __defProp = Object.defineProperty;
var __template = (cooked, raw) => __freeze(__defProp(cooked, "raw", { value: __freeze(cooked.slice()) }));
var _a;
const $$Astro = createAstro("https://emeraldcitylimos.com");
const $$BaseLayout = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$BaseLayout;
  const {
    title,
    description,
    keywords = "luxury car service seattle, black car service seattle, limo service seattle, airport transportation seattle",
    ogImage = "/og-image.jpg",
    canonical
  } = Astro2.props;
  const siteUrl = "https://emeraldcitylimos.com";
  const fullTitle = title.includes("Emerald City Limos") ? title : `${title} | Emerald City Limos - Seattle Luxury Transportation`;
  const canonicalURL = canonical || new URL(Astro2.url.pathname, siteUrl).href;
  return renderTemplate(_a || (_a = __template(['<html lang="en"> <head><!-- Google tag (gtag.js) --><script defer src="https://www.googletagmanager.com/gtag/js?id=G-2D3FQTSFK1"><\/script>', '<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><link rel="icon" type="image/svg+xml" href="/favicon.svg"><meta name="generator"', "><!-- Primary Meta Tags --><title>", '</title><meta name="title"', '><meta name="description"', '><meta name="keywords"', '><link rel="canonical"', '><!-- Author & Copyright --><meta name="author" content="Emerald City Limos"><meta name="copyright" content="Emerald City Limos"><!-- Robots --><meta name="robots" content="index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1"><!-- Geographic Targeting --><meta name="geo.region" content="US-WA"><meta name="geo.placename" content="Seattle"><meta name="geo.position" content="47.6062;-122.3321"><meta name="ICBM" content="47.6062, -122.3321"><!-- Language --><meta http-equiv="content-language" content="en-US"><!-- Open Graph / Facebook --><meta property="og:type" content="website"><meta property="og:url"', '><meta property="og:title"', '><meta property="og:description"', '><meta property="og:image"', '><meta property="og:image:width" content="1200"><meta property="og:image:height" content="630"><meta property="og:locale" content="en_US"><meta property="og:site_name" content="Emerald City Limos"><!-- Twitter --><meta property="twitter:card" content="summary_large_image"><meta property="twitter:url"', '><meta property="twitter:title"', '><meta property="twitter:description"', '><meta property="twitter:image"', '><!-- Alternate Languages --><link rel="alternate" hreflang="en-us"', '><link rel="alternate" hreflang="x-default"', '><!-- Favicon & App Icons --><link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png"><link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png"><link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png"><link rel="manifest" href="/site.webmanifest"><meta name="theme-color" content="#d4af37"><!-- CRITICAL CSS - Inlined for Performance --><style>\n      /* Critical CSS - Mobile-First Performance Optimized */\n    </style><!-- Preconnect to important origins --><link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link rel="preconnect" href="https://images.unsplash.com"><link rel="preconnect" href="https://static.moovs.app"><link rel="preconnect" href="https://api-production.moovs.app"><link rel="dns-prefetch" href="https://images.unsplash.com"><!-- Preload Critical Resources --><link rel="preload" as="image" href="/images/emerald-hero.webp" type="image/webp" fetchpriority="high" media="(min-width: 768px)"><link rel="preload" as="image" href="/images/hero-mobile.webp" type="image/webp" fetchpriority="high" media="(max-width: 767px)"><!-- Preload critical Unsplash images (until replaced with local) --><link rel="preload" as="image" href="https://images.unsplash.com/photo-1549317661-bd32c8ce0db2?w=640&h=360&fit=crop&q=70&fm=webp" type="image/webp" fetchpriority="high" media="(max-width: 768px)"><link rel="preload" as="image" href="https://images.unsplash.com/photo-1549317661-bd32c8ce0db2?w=1920&h=1080&fit=crop&q=75&fm=webp" type="image/webp" fetchpriority="high" media="(min-width: 769px)"><!-- View Transitions for instant navigation -->', '<!-- Business Schema --><script type="application/ld+json">', "<\/script>", '</head> <body class="min-h-screen bg-white"> ', ` <!-- Performance Optimization Script --> <script>
  (function() {
    'use strict';
    
    // Prefetch likely next pages after page is idle
    if ('requestIdleCallback' in window) {
      requestIdleCallback(function() {
        var pages = ['/book-now', '/services', '/airport-transfers', '/fleet', '/locations'];
        pages.forEach(function(page) {
          var link = document.createElement('link');
          link.rel = 'prefetch';
          link.href = page;
          link.as = 'document';
          document.head.appendChild(link);
        });
      });
    }
    
    // Resource hint for booking system
    if ('requestIdleCallback' in window) {
      requestIdleCallback(function() {
        var bookingHint = document.createElement('link');
        bookingHint.rel = 'dns-prefetch';
        bookingHint.href = 'https://customer.moovs.app';
        document.head.appendChild(bookingHint);
      });
    }
  })();

  // Moovs booking widget
  window["moovsAPI"] = moovsAPI = window["moovsAPI"] || [];
  moovsAPI.push(["operator", "d7ca8eda-6ef3-11ef-87b0-9b8d3824ce6b"]);
  (function(m, oo, v, s) {
    s = m.createElement(oo);
    s.src = v;
    s.async = 1;
    m.head.appendChild(s);
  })(document, "script", "https://static.moovs.app");
<\/script> </body> </html>`])), renderScript($$result, "/home/josh/Documents/emerald-update/src/layouts/BaseLayout.astro?astro&type=script&index=0&lang.ts"), addAttribute(Astro2.generator, "content"), fullTitle, addAttribute(fullTitle, "content"), addAttribute(description, "content"), addAttribute(keywords, "content"), addAttribute(canonicalURL, "href"), addAttribute(canonicalURL, "content"), addAttribute(fullTitle, "content"), addAttribute(description, "content"), addAttribute(new URL(ogImage, siteUrl).href, "content"), addAttribute(canonicalURL, "content"), addAttribute(fullTitle, "content"), addAttribute(description, "content"), addAttribute(new URL(ogImage, siteUrl).href, "content"), addAttribute(canonicalURL, "href"), addAttribute(canonicalURL, "href"), renderComponent($$result, "ViewTransitions", $$ClientRouter, {}), unescapeHTML(JSON.stringify({
    "@context": "https://schema.org",
    "@type": "LimousineBusiness",
    "name": "Emerald City Limos",
    "image": new URL(ogImage, siteUrl).href,
    "@id": siteUrl,
    "url": siteUrl,
    "telephone": "+1-206-595-9675",
    "email": "client@emeraldcitylimos.com",
    "address": {
      "@type": "PostalAddress",
      "streetAddress": "",
      "addressLocality": "Seattle",
      "addressRegion": "WA",
      "postalCode": "98101",
      "addressCountry": "US"
    },
    "geo": {
      "@type": "GeoCoordinates",
      "latitude": 47.6062,
      "longitude": -122.3321
    },
    "openingHoursSpecification": {
      "@type": "OpeningHoursSpecification",
      "dayOfWeek": [
        "Monday",
        "Tuesday",
        "Wednesday",
        "Thursday",
        "Friday",
        "Saturday",
        "Sunday"
      ],
      "opens": "00:00",
      "closes": "23:59"
    },
    "priceRange": "$$",
    "sameAs": [
      "https://www.facebook.com/emeraldcitylimos",
      "https://www.instagram.com/emeraldcitylimos",
      "https://www.linkedin.com/company/emeraldcitylimos",
      "https://www.yelp.com/biz/emerald-city-limos-seattle"
    ],
    "areaServed": [
      {
        "@type": "City",
        "name": "Seattle",
        "containedInPlace": {
          "@type": "State",
          "name": "Washington"
        },
        "sameAs": "https://en.wikipedia.org/wiki/Seattle"
      },
      {
        "@type": "City",
        "name": "Bellevue",
        "sameAs": "https://en.wikipedia.org/wiki/Bellevue,_Washington"
      },
      {
        "@type": "City",
        "name": "Tacoma",
        "sameAs": "https://en.wikipedia.org/wiki/Tacoma,_Washington"
      },
      {
        "@type": "City",
        "name": "Kirkland"
      },
      {
        "@type": "City",
        "name": "Redmond"
      },
      {
        "@type": "City",
        "name": "Everett"
      }
    ],
    "serviceType": [
      "Airport Transportation",
      "Corporate Car Service",
      "Wedding Limo Service",
      "Black Car Service",
      "Luxury Transportation",
      "Executive Transportation"
    ],
    "potentialAction": {
      "@type": "ReserveAction",
      "target": {
        "@type": "EntryPoint",
        "urlTemplate": `${siteUrl}/book-now`,
        "actionPlatform": [
          "http://schema.org/DesktopWebPlatform",
          "http://schema.org/MobileWebPlatform"
        ]
      },
      "result": {
        "@type": "Reservation",
        "name": "Book Limo Service"
      }
    },
    "aggregateRating": {
      "@type": "AggregateRating",
      "ratingValue": "4.9",
      "reviewCount": "127",
      "bestRating": "5",
      "worstRating": "1"
    }
  })), renderHead(), renderSlot($$result, $$slots["default"]));
}, "/home/josh/Documents/emerald-update/src/layouts/BaseLayout.astro", void 0);

/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */

const toKebabCase = (string) => string.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase();
const toCamelCase = (string) => string.replace(
  /^([A-Z])|[\s-_]+(\w)/g,
  (match, p1, p2) => p2 ? p2.toUpperCase() : p1.toLowerCase()
);
const toPascalCase = (string) => {
  const camelCase = toCamelCase(string);
  return camelCase.charAt(0).toUpperCase() + camelCase.slice(1);
};
const mergeClasses = (...classes) => classes.filter((className, index, array) => {
  return Boolean(className) && className.trim() !== "" && array.indexOf(className) === index;
}).join(" ").trim();

/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */

var defaultAttributes = {
  xmlns: "http://www.w3.org/2000/svg",
  width: 24,
  height: 24,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 2,
  strokeLinecap: "round",
  strokeLinejoin: "round"
};

/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const Icon = forwardRef(
  ({
    color = "currentColor",
    size = 24,
    strokeWidth = 2,
    absoluteStrokeWidth,
    className = "",
    children,
    iconNode,
    ...rest
  }, ref) => {
    return createElement(
      "svg",
      {
        ref,
        ...defaultAttributes,
        width: size,
        height: size,
        stroke: color,
        strokeWidth: absoluteStrokeWidth ? Number(strokeWidth) * 24 / Number(size) : strokeWidth,
        className: mergeClasses("lucide", className),
        ...rest
      },
      [
        ...iconNode.map(([tag, attrs]) => createElement(tag, attrs)),
        ...Array.isArray(children) ? children : [children]
      ]
    );
  }
);

/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const createLucideIcon = (iconName, iconNode) => {
  const Component = forwardRef(
    ({ className, ...props }, ref) => createElement(Icon, {
      ref,
      iconNode,
      className: mergeClasses(
        `lucide-${toKebabCase(toPascalCase(iconName))}`,
        `lucide-${iconName}`,
        className
      ),
      ...props
    })
  );
  Component.displayName = toPascalCase(iconName);
  return Component;
};

/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const __iconNode$9 = [
  ["path", { d: "M16 20V4a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16", key: "jecpp" }],
  ["rect", { width: "20", height: "14", x: "2", y: "6", rx: "2", key: "i6l2r4" }]
];
const Briefcase = createLucideIcon("briefcase", __iconNode$9);

/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const __iconNode$8 = [["path", { d: "m6 9 6 6 6-6", key: "qrunsl" }]];
const ChevronDown = createLucideIcon("chevron-down", __iconNode$8);

/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const __iconNode$7 = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["polyline", { points: "12 6 12 12 16 14", key: "68esgv" }]
];
const Clock = createLucideIcon("clock", __iconNode$7);

/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const __iconNode$6 = [
  [
    "path",
    {
      d: "M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z",
      key: "c3ymky"
    }
  ]
];
const Heart = createLucideIcon("heart", __iconNode$6);

/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const __iconNode$5 = [
  [
    "path",
    {
      d: "M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0",
      key: "1r0f0z"
    }
  ],
  ["circle", { cx: "12", cy: "10", r: "3", key: "ilqhr7" }]
];
const MapPin = createLucideIcon("map-pin", __iconNode$5);

/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const __iconNode$4 = [
  ["line", { x1: "4", x2: "20", y1: "12", y2: "12", key: "1e0a9i" }],
  ["line", { x1: "4", x2: "20", y1: "6", y2: "6", key: "1owob3" }],
  ["line", { x1: "4", x2: "20", y1: "18", y2: "18", key: "yk5zj1" }]
];
const Menu = createLucideIcon("menu", __iconNode$4);

/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const __iconNode$3 = [
  [
    "path",
    {
      d: "M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z",
      key: "foiqr5"
    }
  ]
];
const Phone = createLucideIcon("phone", __iconNode$3);

/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const __iconNode$2 = [
  [
    "path",
    {
      d: "M17.8 19.2 16 11l3.5-3.5C21 6 21.5 4 21 3c-1-.5-3 0-4.5 1.5L13 8 4.8 6.2c-.5-.1-.9.1-1.1.5l-.3.5c-.2.5-.1 1 .3 1.3L9 12l-2 3H4l-1 1 3 2 2 3 1-1v-3l3-2 3.5 5.3c.3.4.8.5 1.3.3l.5-.2c.4-.3.6-.7.5-1.2z",
      key: "1v9wt8"
    }
  ]
];
const Plane = createLucideIcon("plane", __iconNode$2);

/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const __iconNode$1 = [
  [
    "path",
    {
      d: "M9.937 15.5A2 2 0 0 0 8.5 14.063l-6.135-1.582a.5.5 0 0 1 0-.962L8.5 9.936A2 2 0 0 0 9.937 8.5l1.582-6.135a.5.5 0 0 1 .963 0L14.063 8.5A2 2 0 0 0 15.5 9.937l6.135 1.581a.5.5 0 0 1 0 .964L15.5 14.063a2 2 0 0 0-1.437 1.437l-1.582 6.135a.5.5 0 0 1-.963 0z",
      key: "4pj2yx"
    }
  ],
  ["path", { d: "M20 3v4", key: "1olli1" }],
  ["path", { d: "M22 5h-4", key: "1gvqau" }],
  ["path", { d: "M4 17v2", key: "vumght" }],
  ["path", { d: "M5 18H3", key: "zchphs" }]
];
const Sparkles = createLucideIcon("sparkles", __iconNode$1);

/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const __iconNode = [
  ["path", { d: "M18 6 6 18", key: "1bl5f8" }],
  ["path", { d: "m6 6 12 12", key: "d8bk6v" }]
];
const X = createLucideIcon("x", __iconNode);

const PHONE_DISPLAY = "(206) 595-9675";
const PHONE_HREF = "tel:+12065959675";
const SERVICES = [
  {
    name: "Airport Transfers",
    href: "/airport-transfers",
    icon: Plane,
    desc: "SEA-TAC, BFI, PAE — flight tracked, on time."
  },
  {
    name: "Corporate Travel",
    href: "/service/executive-transportation",
    icon: Briefcase,
    desc: "Executive ground transport with discretion."
  },
  {
    name: "Weddings",
    href: "/service/wedding-transportation",
    icon: Heart,
    desc: "White-glove service for the day that matters."
  },
  {
    name: "Hourly Chauffeur",
    href: "/service/hourly-charters",
    icon: Clock,
    desc: "On-demand chauffeur, by the hour."
  },
  {
    name: "Special Events",
    href: "/service/special-occasions",
    icon: Sparkles,
    desc: "Galas, anniversaries, milestone moments."
  }
];
const LOCATIONS = {
  king: {
    label: "King County",
    items: [
      { name: "Seattle", href: "/locations/seattle" },
      { name: "Bellevue", href: "/locations/bellevue" },
      { name: "Redmond", href: "/locations/redmond" },
      { name: "Kirkland", href: "/locations/kirkland" },
      { name: "Sammamish", href: "/locations/sammamish" },
      { name: "Renton", href: "/locations/renton" },
      { name: "Kent", href: "/locations/kent" },
      { name: "Auburn", href: "/locations/auburn" },
      { name: "Federal Way", href: "/locations/federal-way" },
      { name: "Woodinville", href: "/locations/woodinville" }
    ]
  },
  snohomish: {
    label: "Snohomish County",
    items: [
      { name: "Everett", href: "/locations/everett" },
      { name: "Marysville", href: "/locations/marysville" },
      { name: "Lynnwood", href: "/locations/lynnwood" },
      { name: "Edmonds", href: "/locations/edmonds" },
      { name: "Bothell", href: "/locations/bothell" }
    ]
  },
  pierce: {
    label: "Pierce County",
    items: [
      { name: "Tacoma", href: "/locations/tacoma" },
      { name: "Lakewood", href: "/locations/lakewood" },
      { name: "Puyallup", href: "/locations/puyallup" }
    ]
  },
  airports: {
    label: "Airports",
    items: [
      { name: "SeaTac (SEA)", href: "/locations/seatac-airport" },
      { name: "Boeing Field (BFI)", href: "/locations/boeing-field" }
    ]
  }
};
const AIRPORTS = [
  { name: "Sea-Tac (SEA)", href: "/airport/sea-tac", tag: "Most popular" },
  { name: "Boeing Field (BFI)", href: "/airport/boeing-field" },
  { name: "Paine Field (PAE)", href: "/airport/paine-field" }
];
const NAV = [
  // { type: 'link', name: 'Home', href: '/' },
  { type: "mega", name: "Services", key: "services" },
  { type: "link", name: "Fleet", href: "/fleet" },
  { type: "mega", name: "Locations", key: "locations" },
  { type: "link", name: "About", href: "/#about" },
  { type: "link", name: "Blog", href: "/blog" },
  { type: "link", name: "Contact", href: "/book-now#contact" }
];
const SERVICES_PATH_PREFIXES = ["/services", "/service/", "/airport-transfers"];
const LOCATIONS_PATH_PREFIXES = ["/locations", "/airport/"];
const RING = "outline-none focus-visible:ring-2 focus-visible:ring-brand-gold focus-visible:ring-offset-2 focus-visible:ring-offset-brand-forest";
const RING_TIGHT = "outline-none focus-visible:ring-2 focus-visible:ring-brand-gold";
function Navigation({ variant = "overlay" }) {
  const [scrolled, setScrolled] = useState(variant === "solid");
  const [pathname, setPathname] = useState("");
  const [openMega, setOpenMega] = useState(null);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [mobileSection, setMobileSection] = useState(null);
  const headerRef = useRef(null);
  const closeTimer = useRef(null);
  const triggerRefs = useRef({});
  const hamburgerRef = useRef(null);
  useEffect(() => {
    if (variant === "solid") return;
    const onScroll = () => setScrolled((window.scrollY || 0) > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, [variant]);
  useEffect(() => {
    setPathname(window.location.pathname);
  }, []);
  useEffect(() => {
    const onKey = (e) => {
      if (e.key !== "Escape") return;
      if (openMega) {
        const k = openMega;
        setOpenMega(null);
        triggerRefs.current[k]?.focus();
      } else if (mobileOpen) {
        setMobileOpen(false);
      }
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [openMega, mobileOpen]);
  useEffect(() => {
    if (!mobileOpen) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = prev;
    };
  }, [mobileOpen]);
  useEffect(() => {
    if (!openMega) return;
    const onPointer = (e) => {
      const el = headerRef.current;
      if (el && !el.contains(e.target)) setOpenMega(null);
    };
    document.addEventListener("pointerdown", onPointer);
    return () => document.removeEventListener("pointerdown", onPointer);
  }, [openMega]);
  const isLinkActive = useCallback(
    (href) => {
      if (!pathname) return false;
      if (href === "/") return pathname === "/";
      const bare = href.split("#")[0];
      if (!bare) return false;
      return pathname === bare || pathname.startsWith(bare + "/");
    },
    [pathname]
  );
  const isMegaActive = useCallback(
    (key) => {
      if (!pathname) return false;
      const prefixes = key === "services" ? SERVICES_PATH_PREFIXES : LOCATIONS_PATH_PREFIXES;
      return prefixes.some((p) => pathname === p || pathname.startsWith(p));
    },
    [pathname]
  );
  const cancelClose = () => {
    if (closeTimer.current) {
      window.clearTimeout(closeTimer.current);
      closeTimer.current = null;
    }
  };
  const scheduleClose = () => {
    cancelClose();
    closeTimer.current = window.setTimeout(() => setOpenMega(null), 140);
  };
  const closeMobile = () => setMobileOpen(false);
  const isSolid = variant === "solid" || scrolled || openMega !== null;
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx(
      "header",
      {
        ref: headerRef,
        "data-scrolled": isSolid ? "true" : "false",
        className: [
          "fixed inset-x-0 top-0 z-50",
          "transition-[background-color,backdrop-filter,box-shadow] duration-300 ease-out motion-reduce:transition-none",
          isSolid ? "bg-brand-forest/90 backdrop-blur-md shadow-[0_1px_0_rgba(163,126,44,0.18),0_8px_28px_-12px_rgba(0,0,0,0.5)]" : "bg-gradient-to-b from-black/45 via-black/15 to-transparent"
        ].join(" "),
        children: /* @__PURE__ */ jsxs("div", { className: "relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8", children: [
          /* @__PURE__ */ jsxs(
            "div",
            {
              className: [
                "flex items-center justify-between gap-4",
                "transition-[height] duration-300 ease-out motion-reduce:transition-none",
                isSolid ? "h-16 md:h-[72px]" : "h-20 md:h-24"
              ].join(" "),
              children: [
                /* @__PURE__ */ jsxs(
                  "a",
                  {
                    href: "/",
                    className: `group flex items-center gap-3 rounded-md ${RING}`,
                    "aria-label": "Emerald City Limos — return to homepage",
                    children: [
                      /* @__PURE__ */ jsx(
                        "img",
                        {
                          src: "/images/logo.webp",
                          alt: "",
                          width: 180,
                          height: 48,
                          className: [
                            "w-auto transition-[height] duration-300 ease-out motion-reduce:transition-none",
                            isSolid ? "h-9 md:h-10" : "h-11 md:h-12"
                          ].join(" ")
                        }
                      ),
                      /* @__PURE__ */ jsx("span", { className: "sr-only", children: "Emerald City Limos" })
                    ]
                  }
                ),
                /* @__PURE__ */ jsx(
                  "nav",
                  {
                    className: "hidden lg:block",
                    "aria-label": "Primary",
                    onMouseLeave: scheduleClose,
                    children: /* @__PURE__ */ jsx("ul", { className: "flex items-center gap-1", role: "list", children: NAV.map(
                      (item) => item.type === "link" ? /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(
                        NavLink,
                        {
                          href: item.href,
                          active: isLinkActive(item.href),
                          label: item.name
                        }
                      ) }, item.name) : /* @__PURE__ */ jsx("li", { className: "relative", children: /* @__PURE__ */ jsx(
                        MegaTrigger,
                        {
                          label: item.name,
                          controlsId: `mega-${item.key}`,
                          open: openMega === item.key,
                          active: isMegaActive(item.key),
                          onOpen: () => {
                            cancelClose();
                            setOpenMega(item.key);
                          },
                          onToggle: () => setOpenMega((cur) => cur === item.key ? null : item.key),
                          registerRef: (el) => {
                            triggerRefs.current[item.key] = el;
                          }
                        }
                      ) }, item.name)
                    ) })
                  }
                ),
                /* @__PURE__ */ jsxs("div", { className: "hidden items-center gap-2 lg:flex", children: [
                  /* @__PURE__ */ jsxs(
                    "a",
                    {
                      href: PHONE_HREF,
                      className: `group inline-flex items-center gap-2 rounded-md px-3 py-2 text-sm font-extra-light text-brand-champagne transition-colors hover:text-brand-gold-soft ${RING_TIGHT}`,
                      "aria-label": `Call us at ${PHONE_DISPLAY}, available twenty-four hours a day`,
                      children: [
                        /* @__PURE__ */ jsx(Phone, { className: "h-4 w-4", "aria-hidden": "true" }),
                        /* @__PURE__ */ jsx("span", { className: "tabular-nums", children: PHONE_DISPLAY })
                      ]
                    }
                  ),
                  /* @__PURE__ */ jsx(
                    "a",
                    {
                      href: "/book-now",
                      className: `inline-flex items-center rounded-none bg-brand-gold px-5 py-2.5 text-sm font-semibold tracking-wide text-brand-forest shadow-[0_2px_0_rgba(0,0,0,0.08)] transition-[background-color,box-shadow] duration-200 hover:bg-brand-gold-soft hover:shadow-[0_6px_20px_-6px_rgba(163,126,44,0.6)] motion-reduce:transition-none ${RING}`,
                      children: "Book Now"
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-1 lg:hidden", children: [
                  /* @__PURE__ */ jsx(
                    "a",
                    {
                      href: PHONE_HREF,
                      className: `inline-flex h-11 w-11 items-center justify-center rounded-md text-brand-champagne transition-colors hover:text-brand-gold-soft ${RING_TIGHT}`,
                      "aria-label": `Call ${PHONE_DISPLAY}`,
                      children: /* @__PURE__ */ jsx(Phone, { className: "h-5 w-5", "aria-hidden": "true" })
                    }
                  ),
                  /* @__PURE__ */ jsx(
                    "button",
                    {
                      ref: hamburgerRef,
                      type: "button",
                      onClick: () => setMobileOpen(true),
                      className: `inline-flex h-11 w-11 items-center justify-center rounded-md text-brand-champagne transition-colors hover:text-brand-gold-soft ${RING_TIGHT}`,
                      "aria-label": "Open navigation menu",
                      "aria-expanded": mobileOpen,
                      "aria-controls": "mobile-drawer",
                      children: /* @__PURE__ */ jsx(Menu, { className: "h-6 w-6", "aria-hidden": "true" })
                    }
                  )
                ] })
              ]
            }
          ),
          /* @__PURE__ */ jsx(
            "div",
            {
              className: [
                "absolute inset-x-4 top-full z-10 hidden sm:inset-x-6 lg:inset-x-8 lg:block",
                "transition-[opacity,transform] duration-200 ease-out motion-reduce:transition-none",
                openMega ? "translate-y-0 opacity-100 pointer-events-auto" : "-translate-y-1 opacity-0 pointer-events-none"
              ].join(" "),
              onMouseEnter: cancelClose,
              onMouseLeave: scheduleClose,
              children: /* @__PURE__ */ jsxs("div", { className: "mx-auto w-full max-w-[72rem]", children: [
                openMega === "services" && /* @__PURE__ */ jsx(ServicesMega, { onSelect: () => setOpenMega(null) }),
                openMega === "locations" && /* @__PURE__ */ jsx(LocationsMega, { onSelect: () => setOpenMega(null) })
              ] })
            }
          )
        ] })
      }
    ),
    /* @__PURE__ */ jsx(
      MobileDrawer,
      {
        open: mobileOpen,
        onClose: closeMobile,
        section: mobileSection,
        setSection: setMobileSection,
        isLinkActive,
        returnFocusRef: hamburgerRef
      }
    )
  ] });
}
function NavLink({
  href,
  label,
  active
}) {
  return /* @__PURE__ */ jsx(
    "a",
    {
      href,
      "aria-current": active ? "page" : void 0,
      className: [
        "relative inline-flex items-center px-4 py-2 text-[0.78rem] font-medium uppercase tracking-[0.1em]",
        "text-brand-champagne/85 transition-colors hover:text-brand-champagne",
        "rounded-md",
        RING_TIGHT,
        "after:absolute after:inset-x-4 after:bottom-1 after:h-px after:bg-brand-gold",
        "after:origin-center after:scale-x-0 after:transition-transform after:duration-200 motion-reduce:after:transition-none",
        "hover:after:scale-x-100",
        active ? "text-brand-champagne after:scale-x-100" : ""
      ].join(" "),
      children: label
    }
  );
}
function MegaTrigger({
  label,
  controlsId,
  open,
  active,
  onOpen,
  onToggle,
  registerRef
}) {
  return /* @__PURE__ */ jsxs(
    "button",
    {
      ref: registerRef,
      type: "button",
      "aria-haspopup": "true",
      "aria-expanded": open,
      "aria-controls": controlsId,
      onMouseEnter: onOpen,
      onFocus: onOpen,
      onClick: onToggle,
      className: [
        "relative inline-flex items-center gap-1 px-4 py-2 text-[0.78rem] font-medium uppercase tracking-[0.1em]",
        "text-brand-champagne/85 transition-colors hover:text-brand-champagne",
        "rounded-md",
        RING_TIGHT,
        "after:absolute after:inset-x-4 after:bottom-1 after:h-px after:bg-brand-gold",
        "after:origin-center after:scale-x-0 after:transition-transform after:duration-200 motion-reduce:after:transition-none",
        open || active ? "text-brand-champagne after:scale-x-100" : "hover:after:scale-x-100"
      ].join(" "),
      children: [
        label,
        /* @__PURE__ */ jsx(
          ChevronDown,
          {
            className: `h-3.5 w-3.5 transition-transform duration-200 motion-reduce:transition-none ${open ? "rotate-180" : ""}`,
            "aria-hidden": "true"
          }
        )
      ]
    }
  );
}
function ServicesMega({ onSelect }) {
  return /* @__PURE__ */ jsxs(
    "div",
    {
      id: "mega-services",
      className: "-mt-5 overflow-hidden rounded-2xl border border-brand-gold/20 bg-brand-forest-deep/95 shadow-[0_24px_56px_-16px_rgba(0,0,0,0.65)] backdrop-blur-xl",
      children: [
        /* @__PURE__ */ jsx("ul", { role: "list", className: "grid grid-cols-1 gap-1 p-3 md:grid-cols-2 lg:grid-cols-3", children: SERVICES.map((s) => /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsxs(
          "a",
          {
            href: s.href,
            onClick: onSelect,
            className: `group flex items-start gap-3 rounded-xl p-4 transition-colors hover:bg-brand-gold/10 ${RING_TIGHT}`,
            children: [
              /* @__PURE__ */ jsx("span", { className: "mt-0.5 inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-md bg-brand-gold/15 text-brand-gold transition-colors group-hover:bg-brand-gold group-hover:text-brand-forest", children: /* @__PURE__ */ jsx(s.icon, { className: "h-4 w-4", "aria-hidden": "true" }) }),
              /* @__PURE__ */ jsxs("span", { className: "min-w-0", children: [
                /* @__PURE__ */ jsx("span", { className: "block text-sm font-semibold text-brand-champagne", children: s.name }),
                /* @__PURE__ */ jsx("span", { className: "mt-0.5 block text-xs leading-relaxed text-brand-champagne/65", children: s.desc })
              ] })
            ]
          }
        ) }, s.href)) }),
        /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-2 border-t border-brand-gold/15 bg-brand-forest px-5 py-3 sm:flex-row sm:items-center sm:justify-between", children: [
          /* @__PURE__ */ jsx("p", { className: "text-xs text-brand-champagne/70", children: "Need something custom? We charter for any occasion." }),
          /* @__PURE__ */ jsx(
            "a",
            {
              href: "/services",
              onClick: onSelect,
              className: `rounded-sm text-xs font-semibold tracking-wide text-brand-gold transition-colors hover:text-brand-gold-soft ${RING_TIGHT}`,
              children: "View all services →"
            }
          )
        ] })
      ]
    }
  );
}
function LocationsMega({ onSelect }) {
  return /* @__PURE__ */ jsxs(
    "div",
    {
      id: "mega-locations",
      className: "-mt-5 overflow-hidden rounded-2xl border border-brand-gold/20 bg-brand-forest-deep/95 shadow-[0_24px_56px_-16px_rgba(0,0,0,0.65)] backdrop-blur-xl",
      children: [
        /* @__PURE__ */ jsx("div", { className: "grid gap-6 p-6 md:grid-cols-4", children: Object.entries(LOCATIONS).map(([k, group]) => /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsxs("p", { className: "mb-3 flex items-center gap-1.5 text-[0.68rem] font-semibold uppercase tracking-[0.14em] text-brand-gold", children: [
            /* @__PURE__ */ jsx(MapPin, { className: "h-3 w-3", "aria-hidden": "true" }),
            group.label
          ] }),
          /* @__PURE__ */ jsx("ul", { role: "list", className: "space-y-0.5", children: group.items.map((c) => /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(
            "a",
            {
              href: c.href,
              onClick: onSelect,
              className: `block rounded-md px-2 py-1.5 text-sm text-brand-champagne/85 transition-colors hover:bg-brand-gold/10 hover:text-brand-champagne ${RING_TIGHT}`,
              children: c.name
            }
          ) }, c.href)) })
        ] }, k)) }),
        /* @__PURE__ */ jsx("div", { className: "border-t border-brand-gold/15 bg-brand-forest px-6 py-5", children: /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-3 md:flex-row md:items-end md:justify-between", children: [
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsxs("p", { className: "mb-2 flex items-center gap-1.5 text-[0.68rem] font-semibold uppercase tracking-[0.14em] text-brand-gold", children: [
              /* @__PURE__ */ jsx(Plane, { className: "h-3 w-3", "aria-hidden": "true" }),
              "Airports"
            ] }),
            /* @__PURE__ */ jsx("ul", { role: "list", className: "flex flex-wrap gap-2", children: AIRPORTS.map((a) => /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsxs(
              "a",
              {
                href: a.href,
                onClick: onSelect,
                className: `inline-flex items-center gap-2 rounded-full border border-brand-gold/25 bg-brand-forest px-3 py-1.5 text-xs text-brand-champagne transition-colors hover:border-brand-gold hover:text-brand-gold-soft ${RING_TIGHT}`,
                children: [
                  a.name,
                  "tag" in a && a.tag && /* @__PURE__ */ jsx("span", { className: "rounded-full bg-brand-emerald/20 px-1.5 py-0.5 text-[0.6rem] font-semibold uppercase tracking-wide text-brand-emerald", children: a.tag })
                ]
              }
            ) }, a.href)) })
          ] }),
          /* @__PURE__ */ jsx(
            "a",
            {
              href: "/locations",
              onClick: onSelect,
              className: `self-start rounded-sm text-xs font-semibold tracking-wide text-brand-gold transition-colors hover:text-brand-gold-soft md:self-auto ${RING_TIGHT}`,
              children: "View all locations →"
            }
          )
        ] }) })
      ]
    }
  );
}
function MobileDrawer({
  open,
  onClose,
  section,
  setSection,
  isLinkActive,
  returnFocusRef
}) {
  const drawerRef = useRef(null);
  const closeBtnRef = useRef(null);
  useEffect(() => {
    if (!open) return;
    const t = window.setTimeout(() => closeBtnRef.current?.focus(), 30);
    return () => window.clearTimeout(t);
  }, [open]);
  useEffect(() => {
    if (open) return;
    returnFocusRef.current?.focus();
  }, [open, returnFocusRef]);
  useEffect(() => {
    if (!open) return;
    const drawer = drawerRef.current;
    if (!drawer) return;
    const onKey = (e) => {
      if (e.key !== "Tab") return;
      const focusable = drawer.querySelectorAll(
        'a[href], button:not([disabled]), [tabindex]:not([tabindex="-1"])'
      );
      if (focusable.length === 0) return;
      const first = focusable[0];
      const last = focusable[focusable.length - 1];
      const active = document.activeElement;
      if (e.shiftKey && active === first) {
        e.preventDefault();
        last.focus();
      } else if (!e.shiftKey && active === last) {
        e.preventDefault();
        first.focus();
      }
    };
    drawer.addEventListener("keydown", onKey);
    return () => drawer.removeEventListener("keydown", onKey);
  }, [open]);
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx(
      "div",
      {
        className: [
          "fixed inset-0 z-40 bg-black/60 backdrop-blur-sm",
          "transition-opacity duration-300 ease-out motion-reduce:transition-none",
          open ? "opacity-100" : "pointer-events-none opacity-0"
        ].join(" "),
        onClick: onClose,
        "aria-hidden": "true"
      }
    ),
    /* @__PURE__ */ jsxs(
      "aside",
      {
        id: "mobile-drawer",
        ref: drawerRef,
        role: "dialog",
        "aria-modal": "true",
        "aria-label": "Site navigation",
        className: [
          "fixed right-0 top-0 z-50 flex h-[100dvh] w-[88vw] max-w-sm flex-col",
          "bg-brand-forest text-brand-champagne shadow-2xl",
          "transition-transform duration-300 ease-out motion-reduce:transition-none",
          open ? "translate-x-0" : "translate-x-full"
        ].join(" "),
        children: [
          /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between border-b border-brand-gold/15 px-5 py-4", children: [
            /* @__PURE__ */ jsxs(
              "a",
              {
                href: "/",
                onClick: onClose,
                className: `flex items-center gap-2 rounded-md ${RING_TIGHT}`,
                "aria-label": "Emerald City Limos — homepage",
                children: [
                  /* @__PURE__ */ jsx("img", { src: "/images/logo.webp", alt: "", className: "h-9 w-auto" }),
                  /* @__PURE__ */ jsx("span", { className: "sr-only", children: "Emerald City Limos" })
                ]
              }
            ),
            /* @__PURE__ */ jsx(
              "button",
              {
                ref: closeBtnRef,
                type: "button",
                onClick: onClose,
                className: `inline-flex h-11 w-11 items-center justify-center rounded-md text-brand-champagne transition-colors hover:text-brand-gold-soft ${RING_TIGHT}`,
                "aria-label": "Close navigation menu",
                children: /* @__PURE__ */ jsx(X, { className: "h-6 w-6", "aria-hidden": "true" })
              }
            )
          ] }),
          /* @__PURE__ */ jsx(
            "nav",
            {
              className: "flex-1 overflow-y-auto overscroll-contain px-3 py-4",
              "aria-label": "Mobile primary",
              children: /* @__PURE__ */ jsx("ul", { role: "list", className: "space-y-1", children: NAV.map((item) => {
                if (item.type === "link") {
                  const active = isLinkActive(item.href);
                  return /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(
                    "a",
                    {
                      href: item.href,
                      onClick: onClose,
                      "aria-current": active ? "page" : void 0,
                      className: [
                        "flex min-h-[48px] items-center rounded-lg px-4 text-base",
                        RING_TIGHT,
                        active ? "bg-brand-gold/15 font-semibold text-brand-gold-soft" : "font-medium text-brand-champagne hover:bg-brand-gold/10"
                      ].join(" "),
                      children: item.name
                    }
                  ) }, item.name);
                }
                const isOpen = section === item.key;
                const panelId = `m-${item.key}`;
                return /* @__PURE__ */ jsxs("li", { children: [
                  /* @__PURE__ */ jsxs(
                    "button",
                    {
                      type: "button",
                      onClick: () => setSection(isOpen ? null : item.key),
                      "aria-expanded": isOpen,
                      "aria-controls": panelId,
                      className: `flex min-h-[48px] w-full items-center justify-between rounded-lg px-4 text-base font-medium text-brand-champagne transition-colors hover:bg-brand-gold/10 ${RING_TIGHT}`,
                      children: [
                        item.name,
                        /* @__PURE__ */ jsx(
                          ChevronDown,
                          {
                            className: `h-4 w-4 text-brand-gold transition-transform duration-200 motion-reduce:transition-none ${isOpen ? "rotate-180" : ""}`,
                            "aria-hidden": "true"
                          }
                        )
                      ]
                    }
                  ),
                  /* @__PURE__ */ jsx(
                    "div",
                    {
                      id: panelId,
                      hidden: !isOpen,
                      className: "ml-4 mt-1 mb-2 border-l border-brand-gold/20 pl-3",
                      children: item.key === "services" ? /* @__PURE__ */ jsxs("ul", { role: "list", className: "space-y-0.5", children: [
                        SERVICES.map((s) => /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(
                          "a",
                          {
                            href: s.href,
                            onClick: onClose,
                            className: `flex min-h-[44px] items-center rounded-md px-3 text-sm text-brand-champagne/85 transition-colors hover:bg-brand-gold/10 hover:text-brand-champagne ${RING_TIGHT}`,
                            children: s.name
                          }
                        ) }, s.href)),
                        /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(
                          "a",
                          {
                            href: "/services",
                            onClick: onClose,
                            className: `flex min-h-[44px] items-center rounded-md px-3 text-sm font-semibold text-brand-gold hover:text-brand-gold-soft ${RING_TIGHT}`,
                            children: "View all services →"
                          }
                        ) })
                      ] }) : /* @__PURE__ */ jsxs("div", { className: "space-y-3", children: [
                        /* @__PURE__ */ jsx("ul", { role: "list", className: "flex flex-wrap gap-1.5", children: AIRPORTS.map((a) => /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(
                          "a",
                          {
                            href: a.href,
                            onClick: onClose,
                            className: `inline-flex min-h-[40px] items-center rounded-full border border-brand-gold/25 px-3 text-xs font-semibold text-brand-champagne transition-colors hover:border-brand-gold hover:text-brand-gold-soft ${RING_TIGHT}`,
                            children: a.name
                          }
                        ) }, a.href)) }),
                        Object.entries(LOCATIONS).map(([k, group]) => /* @__PURE__ */ jsxs("div", { children: [
                          /* @__PURE__ */ jsx("p", { className: "px-1 pt-1 text-[0.68rem] font-semibold uppercase tracking-[0.14em] text-brand-gold", children: group.label }),
                          /* @__PURE__ */ jsx("ul", { role: "list", className: "space-y-0.5", children: group.items.map((c) => /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(
                            "a",
                            {
                              href: c.href,
                              onClick: onClose,
                              className: `flex min-h-[40px] items-center rounded-md px-3 text-sm text-brand-champagne/80 transition-colors hover:bg-brand-gold/10 hover:text-brand-champagne ${RING_TIGHT}`,
                              children: c.name
                            }
                          ) }, c.href)) })
                        ] }, k)),
                        /* @__PURE__ */ jsx(
                          "a",
                          {
                            href: "/locations",
                            onClick: onClose,
                            className: `block rounded-sm px-1 py-2 text-sm font-semibold text-brand-gold hover:text-brand-gold-soft ${RING_TIGHT}`,
                            children: "View all locations →"
                          }
                        )
                      ] })
                    }
                  )
                ] }, item.name);
              }) })
            }
          ),
          /* @__PURE__ */ jsxs("div", { className: "space-y-2.5 border-t border-brand-gold/15 bg-brand-forest-deep px-5 py-4", children: [
            /* @__PURE__ */ jsx(
              "a",
              {
                href: "/book-now",
                onClick: onClose,
                className: "flex min-h-[52px] w-full items-center justify-center rounded-none bg-brand-gold px-5 font-semibold tracking-wide text-brand-forest outline-none transition-colors hover:bg-brand-gold-soft focus-visible:ring-2 focus-visible:ring-brand-champagne",
                children: "Book Now"
              }
            ),
            /* @__PURE__ */ jsx(
              "a",
              {
                href: "/book-now?intent=quote",
                onClick: onClose,
                className: `flex min-h-[48px] w-full items-center justify-center rounded-none border border-brand-champagne/30 px-5 font-semibold text-brand-champagne transition-colors hover:border-brand-gold hover:text-brand-gold-soft ${RING_TIGHT}`,
                children: "Get a Quote"
              }
            ),
            /* @__PURE__ */ jsxs(
              "a",
              {
                href: PHONE_HREF,
                onClick: onClose,
                className: `flex min-h-[48px] w-full items-center justify-center gap-2 rounded-md text-brand-champagne transition-colors hover:text-brand-gold-soft ${RING_TIGHT}`,
                "aria-label": `Call ${PHONE_DISPLAY}`,
                children: [
                  /* @__PURE__ */ jsx(Phone, { className: "h-4 w-4", "aria-hidden": "true" }),
                  /* @__PURE__ */ jsx("span", { className: "text-base font-semibold tabular-nums", children: PHONE_DISPLAY })
                ]
              }
            ),
            /* @__PURE__ */ jsx("p", { className: "text-center text-xs text-brand-champagne/55", children: "Available 24 hours · Seven days a week" })
          ] })
        ]
      }
    )
  ] });
}

export { $$BaseLayout as $, Clock as C, MapPin as M, Navigation as N, Phone as P, ChevronDown as a, createLucideIcon as c };

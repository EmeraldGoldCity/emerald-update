import { b as createAstro, c as createComponent, a as renderTemplate, e as renderSlot, d as addAttribute, r as renderComponent, F as Fragment, m as maybeRenderHead } from './astro/server_DL3Tye_C.mjs';
import 'piccolore';

var __freeze = Object.freeze;
var __defProp = Object.defineProperty;
var __template = (cooked, raw) => __freeze(__defProp(cooked, "raw", { value: __freeze(cooked.slice()) }));
var _a;
const $$Astro = createAstro("https://emeraldcitylimos.com");
const $$PageHero = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$PageHero;
  const {
    eyebrow,
    headline,
    headlineAccent,
    supporting,
    ctaPrimary = { label: "Book Now", href: "/book-now", id: "cta-hero-primary" },
    ctaSecondary = {
      label: "Get a Quote",
      href: "tel:+12065959675",
      id: "cta-hero-secondary",
      phone: "(206) 595-9675"
    },
    image,
    size = "page",
    id = "page-hero",
    noAnim = false
  } = Astro2.props;
  const sectionMinH = size === "full" ? "h-[100svh]" : "h-[68svh]";
  const anim = (cls) => noAnim ? "" : cls;
  return renderTemplate(_a || (_a = __template(["", "<section", "", "> ", " <!-- Base + three-layer overlay tuned for bottom-left legibility --> <div", ' aria-hidden="true"></div> <div class="absolute inset-0" style="background: linear-gradient(to bottom, rgba(10,35,24,0.15) 0%, rgba(10,35,24,0.35) 40%, rgba(10,35,24,0.78) 75%, rgba(10,35,24,0.94) 100%);" aria-hidden="true"></div> <div class="absolute inset-0" style="background: radial-gradient(ellipse 75% 65% at 20% 85%, rgba(10,35,24,0.55) 0%, transparent 70%);" aria-hidden="true"></div> <!-- Top decorative gold rule --> <div', ' style="background: linear-gradient(90deg, transparent, rgba(163,126,44,0.5), transparent);" aria-hidden="true"></div> <!-- Content (bottom-left) --> <div', '> <div class="w-full max-w-xl text-left"> ', " <h1", ' class="mb-2 font-display font-light text-[clamp(36px,5.5vw,74px)] leading-[1.04] tracking-[-0.02em] text-[#F5F0E8] sm:mb-4"> ', " </h1> <p", ' style="font-size: clamp(0.90rem, 1.5vw, 1.rem);"> ', " </p> <div", ' role="group" aria-label="Booking options"> <a', "", ' data-cta="hero_primary"', ' class="ecl-btn-primary ecl-focusable inline-flex min-h-[52px] w-full items-center justify-center gap-2 rounded-none border border-brand-gold-soft bg-brand-gold-soft px-8 font-sans text-[11px] font-semibold uppercase tracking-[0.2em] text-brand-forest sm:w-auto"> ', ' <span aria-hidden="true" class="ecl-arrow">\u2192</span> </a> <a', "", ' data-cta="hero_secondary"', ' class="ecl-btn-secondary ecl-focusable inline-flex min-h-[52px] w-full items-center justify-center gap-2 rounded-none border border-white/40 bg-transparent px-8 font-sans text-[11px] font-semibold uppercase tracking-[0.2em] text-white hover:border-white/70 sm:w-auto"> ', ' <span class="tabular-nums">', "</span> </a> </div> ", ` </div> </div> <!-- Bottom decorative gold rule --> <div class="absolute bottom-0 left-0 right-0 h-px" style="background: linear-gradient(90deg, transparent, rgba(163,126,44,0.3), transparent);" aria-hidden="true"></div> </section> <script>
  document.querySelectorAll('section.ecl-hero a[data-cta]').forEach((el) => {
    el.addEventListener('click', () => {
      const label = el.getAttribute('data-cta');
      if (window.gtag) window.gtag('event', 'click', { event_category: 'hero_cta', event_label: label });
    });
  });
<\/script>`])), maybeRenderHead(), addAttribute(["ecl-hero ecl-noise relative w-full overflow-hidden", sectionMinH], "class:list"), addAttribute(id, "aria-labelledby"), image && renderTemplate`<picture> ${image.srcMobile && renderTemplate`<source media="(max-width: 767px)"${addAttribute(image.srcMobile, "srcset")}>`} <img${addAttribute(image.src, "src")}${addAttribute(image.alt, "alt")}${addAttribute(image.width ?? 1920, "width")}${addAttribute(image.height ?? 1080, "height")} fetchpriority="high" loading="eager" decoding="async" class="absolute inset-0 h-full w-full object-cover object-center"> </picture>`, addAttribute(["absolute inset-0", image ? "bg-brand-forest/15" : "bg-brand-forest"], "class:list"), addAttribute(["absolute left-0 right-0 top-0 h-px", anim("ecl-anim ecl-anim-line ecl-delay-1")], "class:list"), addAttribute([
    size === "full" ? "relative z-10 flex h-full flex-col justify-end px-6 pb-12 pt-24 sm:px-10 sm:pb-16 sm:pt-32 md:px-14 lg:px-20 lg:pb-20" : "relative z-10 flex h-full flex-col justify-end px-6 pb-8 pt-0 sm:px-10 sm:pb-12 md:px-14 lg:px-20 lg:pb-14",
    sectionMinH
  ], "class:list"), eyebrow && renderTemplate`<div${addAttribute(["mb-4 flex items-center gap-3 sm:mb-6", anim("ecl-anim ecl-anim-fade-in ecl-delay-2")], "class:list")}> <span class="h-px w-10 sm:w-12" style="background: linear-gradient(to right, rgba(163,126,44,0.6), transparent);" aria-hidden="true"></span> <p class="font-sans text-[10px] font-semibold uppercase tracking-[0.22em] text-brand-gold-soft sm:text-[11px]"> ${eyebrow} </p> </div>`, addAttribute(id, "id"), headline === "Luxury Chauffeur Service" ? renderTemplate`${renderComponent($$result, "Fragment", Fragment, {}, { "default": ($$result2) => renderTemplate` <span class="whitespace-nowrap">
Luxury Chauffeur Service
</span> <br> <span class="italic whitespace-nowrap"> <span class="text-white">in </span> <span class="text-brand-gold-soft">${headlineAccent}</span> </span> ` })}` : renderTemplate`${renderComponent($$result, "Fragment", Fragment, {}, { "default": ($$result2) => renderTemplate` <span${addAttribute([anim("ecl-anim ecl-anim-fade-up ecl-delay-2")], "class:list")}> ${headline} </span> ${headlineAccent && renderTemplate`${renderComponent($$result2, "Fragment", Fragment, {}, { "default": ($$result3) => renderTemplate` <br> <span${addAttribute([
    "italic text-[#c39a45]",
    anim("ecl-anim ecl-anim-fade-up ecl-delay-3")
  ], "class:list")}> ${headlineAccent} </span> ` })}`}` })}`, addAttribute([
    "mb-4 max-w-xl font-sans font-light leading-relaxed tracking-[0.01em] text-white/80 sm:mb-6",
    anim("ecl-anim ecl-anim-fade-up ecl-delay-5")
  ], "class:list"), supporting, addAttribute([
    "flex flex-col items-stretch gap-3 sm:flex-row sm:items-center sm:justify-start sm:gap-4",
    anim("ecl-anim ecl-anim-fade-up ecl-delay-6")
  ], "class:list"), addAttribute(ctaPrimary.href, "href"), addAttribute(ctaPrimary.id ?? "cta-hero-primary", "id"), addAttribute(`${ctaPrimary.label} \u2014 Emerald City Limos`, "aria-label"), ctaPrimary.label, addAttribute(ctaSecondary.href, "href"), addAttribute(ctaSecondary.id ?? "cta-hero-secondary", "id"), addAttribute(
    ctaSecondary.phone ? `Call us at ${ctaSecondary.phone}` : `${ctaSecondary.label} \u2014 Emerald City Limos`,
    "aria-label"
  ), ctaSecondary.phone && renderTemplate`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" width="14" height="14" aria-hidden="true"> <path stroke-linecap="round" stroke-linejoin="round" d="M2.25 6.75c0 8.284 6.716 15 15 15h2.25a2.25 2.25 0 002.25-2.25v-1.372c0-.516-.351-.966-.852-1.091l-4.423-1.106c-.44-.11-.902.055-1.173.417l-.97 1.293c-.282.376-.769.542-1.21.38a12.035 12.035 0 01-7.143-7.143c-.162-.441.004-.928.38-1.21l1.293-.97c.363-.271.527-.734.417-1.173L6.963 3.102a1.125 1.125 0 00-1.091-.852H4.5A2.25 2.25 0 002.25 4.5v2.25z"></path> </svg>`, ctaSecondary.phone ?? ctaSecondary.label, renderSlot($$result, $$slots["below"]));
}, "/home/josh/Documents/emerald-update/src/components/shared/PageHero.astro", void 0);

const $$TrustStrip = createComponent(($$result, $$props, $$slots) => {
  const items = [
    { label: "Since 2010", icon: "clock" },
    { label: "Licensed & Insured", icon: "shield" },
    { label: "24/7 Availability", icon: "sparkles" },
    { label: "SeaTac Specialists", icon: "plane" },
    { label: "3 Counties Served", icon: "map-pin" }
  ];
  const ICON_PATHS = {
    clock: "M12 6v6h4.5m4.5 0a9 9 0 11-18 0 9 9 0 0118 0z",
    shield: "M9 12.75L11.25 15 15 9.75M21 12c0 1.268-.63 2.39-1.593 3.068a3.745 3.745 0 01-1.043 3.296 3.745 3.745 0 01-3.296 1.043A3.745 3.745 0 0112 21c-1.268 0-2.39-.63-3.068-1.593a3.746 3.746 0 01-3.296-1.043 3.745 3.745 0 01-1.043-3.296A3.745 3.745 0 013 12c0-1.268.63-2.39 1.593-3.068a3.745 3.745 0 011.043-3.296 3.746 3.746 0 013.296-1.043A3.746 3.746 0 0112 3c1.268 0 2.39.63 3.068 1.593a3.746 3.746 0 013.296 1.043 3.746 3.746 0 011.043 3.296A3.745 3.745 0 0121 12z",
    sparkles: "M9.813 15.904L9 18.75l-.813-2.846a4.5 4.5 0 00-3.09-3.09L2.25 12l2.846-.813a4.5 4.5 0 003.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 003.09 3.09L15.75 12l-2.846.813a4.5 4.5 0 00-3.09 3.09zM18.259 8.715L18 9.75l-.259-1.035a3.375 3.375 0 00-2.456-2.456L14.25 6l1.035-.259a3.375 3.375 0 002.456-2.456L18 2.25l.259 1.035a3.375 3.375 0 002.456 2.456L21.75 6l-1.035.259a3.375 3.375 0 00-2.456 2.456zM16.894 20.567L16.5 21.75l-.394-1.183a2.25 2.25 0 00-1.423-1.423L13.5 18.75l1.183-.394a2.25 2.25 0 001.423-1.423l.394-1.183.394 1.183a2.25 2.25 0 001.423 1.423l1.183.394-1.183.394a2.25 2.25 0 00-1.423 1.423z",
    plane: "M6 12L3.269 3.125A59.769 59.769 0 0121.485 12 59.768 59.768 0 013.27 20.875L5.999 12zm0 0h7.5",
    "map-pin": "M15 10.5a3 3 0 11-6 0 3 3 0 016 0z M19.5 10.5c0 7.142-7.5 11.25-7.5 11.25S4.5 17.642 4.5 10.5a7.5 7.5 0 1115 0z"
  };
  return renderTemplate`${maybeRenderHead()}<section class="relative bg-brand-forest py-4 sm:py-6 lg:py-8" aria-label="Trust signals"> <!-- Top hairline (continues the hero's bottom gold rule) --> <div class="absolute left-0 right-0 top-0 h-px" style="background: linear-gradient(90deg, transparent, rgba(163,126,44,0.35), transparent);" aria-hidden="true"></div> <div class="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8"> <ul class="m-0 flex flex-wrap items-center justify-center p-0 py-4 sm:py-5" role="list"> ${items.map((item, i) => renderTemplate`<li class="flex items-center whitespace-nowrap font-sans text-[10px] font-medium uppercase tracking-[0.14em] text-white/80 sm:text-[11px] sm:tracking-[0.16em]"> ${i > 0 && renderTemplate`<span class="mx-3 text-brand-gold-soft/55 sm:mx-4 lg:mx-6" aria-hidden="true">·</span>`} <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" width="18" height="18" class="mr-2 flex-shrink-0 text-brand-gold" aria-hidden="true"> ${item.icon === "map-pin" ? renderTemplate`${renderComponent($$result, "Fragment", Fragment, {}, { "default": ($$result2) => renderTemplate` <path stroke-linecap="round" stroke-linejoin="round" d="M15 10.5a3 3 0 11-6 0 3 3 0 016 0z"></path> <path stroke-linecap="round" stroke-linejoin="round" d="M19.5 10.5c0 7.142-7.5 11.25-7.5 11.25S4.5 17.642 4.5 10.5a7.5 7.5 0 1115 0z"></path> ` })}` : renderTemplate`<path stroke-linecap="round" stroke-linejoin="round"${addAttribute(ICON_PATHS[item.icon], "d")}></path>`} </svg> <span>${item.label}</span> </li>`)} </ul> </div> <!-- Bottom hairline --> <div class="absolute bottom-0 left-0 right-0 h-px" style="background: linear-gradient(90deg, transparent, rgba(163,126,44,0.2), transparent);" aria-hidden="true"></div> </section>`;
}, "/home/josh/Documents/emerald-update/src/components/shared/TrustStrip.astro", void 0);

export { $$PageHero as $, $$TrustStrip as a };

import { b as createAstro, c as createComponent, m as maybeRenderHead, d as addAttribute, a as renderTemplate } from './astro/server_DL3Tye_C.mjs';
import 'piccolore';
import 'clsx';

const fleet = [
  {
    id: "escalade-esv",
    name: "Cadillac Escalade ESV",
    category: "Luxury SUV",
    capacity: 6,
    capacityLabel: "Up to 6 passengers",
    features: [
      "Massaging executive seats",
      "Bose Studio audio",
      "Ambient cabin lighting",
      "Extended wheelbase"
    ],
    bestFor: ["Corporate", "VIP transport", "Airport"],
    imageSrc: "/images/cadl2.webp",
    imageAlt: "Black Cadillac Escalade ESV luxury SUV — Emerald City Limos chauffeur fleet",
    featured: true,
    href: "/fleet#escalade-esv"
  },
  {
    id: "navigator-l",
    name: "Lincoln Navigator L",
    category: "SUV",
    capacity: 6,
    capacityLabel: "Up to 6 passengers",
    features: [
      "Premium leather interior",
      "Panoramic roof",
      "In-vehicle WiFi",
      "Dual climate zones"
    ],
    bestFor: ["Airport transfers", "Corporate groups"],
    // imageSrc: '/images/fleet/navigator.webp',
    imageAlt: "Black Lincoln Navigator L luxury SUV — Emerald City Limos chauffeur fleet",
    featured: false,
    href: "/fleet#navigator-l"
  },
  {
    id: "sprinter",
    name: "Mercedes-Benz Sprinter",
    category: "Executive Van",
    capacity: 12,
    capacityLabel: "Up to 12 passengers",
    features: [
      "Club seating",
      "Privacy glass",
      "USB charging at every seat",
      "Bar setup"
    ],
    bestFor: ["Groups", "Events", "Wine tours"],
    imageSrc: "/images/SPRINTER.jpeg",
    imageAlt: "Mercedes-Benz Sprinter executive edition van — Emerald City Limos chauffeur fleet",
    featured: false,
    href: "/fleet#sprinter"
  },
  {
    id: "s-class-s580",
    name: "Mercedes-Benz S‑Class S580",
    category: "Luxury Sedan",
    capacity: 3,
    capacityLabel: "Up to 3 passengers",
    features: [
      "Executive rear seating",
      "Burmester surround audio",
      "Seat massage",
      "Ambient cabin lighting"
    ],
    bestFor: ["Solo executive travel", "Airport", "VIP"],
    imageSrc: "/images/merc.webp",
    imageAlt: "Mercedes-Benz S-Class S580 luxury sedan — Emerald City Limos chauffeur fleet",
    featured: false,
    href: "/fleet#s-class-s580"
  },
  {
    id: "town-car-stretch",
    name: "Lincoln Town Car Stretch",
    category: "Limousine",
    capacity: 10,
    capacityLabel: "Up to 10 passengers",
    features: [
      "Fiber-optic lighting",
      "Wet bar",
      "Privacy divider",
      "Rear entertainment system"
    ],
    bestFor: ["Weddings", "Proms", "Special occasions"],
    imageSrc: "/images/party1.webp",
    imageAlt: "Lincoln Town Car stretch limousine — Emerald City Limos chauffeur fleet",
    featured: false,
    href: "/fleet#town-car-stretch"
  }
];
const defaultFeaturedId = "escalade-esv";
const fleetCategoryTabs = [
  { value: "All", label: "All" },
  { value: "Luxury Sedan", label: "Sedan" },
  { value: "SUV", label: "SUV" },
  { value: "Luxury SUV", label: "Luxury SUV" },
  { value: "Executive Van", label: "Van" },
  { value: "Limousine", label: "Limousine" }
];

const $$Astro = createAstro("https://emeraldcitylimos.com");
const $$FleetCard = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$FleetCard;
  const { vehicle } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<article data-fleet-card${addAttribute(vehicle.category, "data-category")} role="article"${addAttribute(`${vehicle.name} \u2014 ${vehicle.category}`, "aria-label")} class="ecl-fleet-card group relative flex h-full flex-col overflow-hidden border-l-2 border-brand-gold/60 bg-white ring-1 ring-brand-forest/10 transition-[border-color,box-shadow] duration-300 hover:border-brand-gold hover:shadow-[0_8px_28px_-12px_rgba(10,35,24,0.18)] focus-within:border-brand-gold">  <a${addAttribute(vehicle.href, "href")} class="ecl-focusable absolute inset-0 z-10"${addAttribute(`View details for ${vehicle.name} (${vehicle.category}, ${vehicle.capacityLabel})`, "aria-label")}> <span class="sr-only">View details</span> </a>  <div class="relative aspect-[4/3] w-full overflow-hidden bg-brand-forest"> ${vehicle.imageSrc ? renderTemplate`<img${addAttribute(vehicle.imageSrc, "src")}${addAttribute(vehicle.imageAlt, "alt")} loading="lazy" decoding="async" width="800" height="600" class="absolute inset-0 h-full w-full object-cover object-center transition-transform duration-500 ease-out group-hover:scale-[1.03]">` : renderTemplate`<div class="absolute inset-0 flex items-center justify-center" aria-hidden="true"> <span class="absolute inset-0" style="background: radial-gradient(ellipse 60% 55% at center, var(--color-brand-gold-soft) 0%, transparent 70%); opacity: 0.16;"></span> <span class="absolute left-3 top-3 h-px w-6 bg-brand-gold/50"></span> <span class="absolute left-3 top-3 h-6 w-px bg-brand-gold/50"></span> <span class="absolute bottom-3 right-3 h-px w-6 bg-brand-gold/50"></span> <span class="absolute bottom-3 right-3 h-6 w-px bg-brand-gold/50"></span> <span class="relative font-sans text-[11px] font-semibold uppercase tracking-[0.22em] text-brand-gold-soft"> ${vehicle.category} </span> </div>`}  <span aria-hidden="true" class="ecl-fleet-card__reveal pointer-events-none absolute inset-x-0 bottom-0 flex translate-y-full items-center justify-between bg-brand-forest/92 px-4 py-3 font-sans text-xs font-semibold uppercase tracking-[0.2em] text-white opacity-0 transition-[transform,opacity] duration-300 ease-out group-hover:translate-y-0 group-hover:opacity-100 group-focus-within:translate-y-0 group-focus-within:opacity-100">
View Details
<span class="text-brand-gold-soft">&rarr;</span> </span> </div>  <div class="flex flex-1 flex-col gap-2 p-5 sm:p-6"> <p class="font-sans text-[11px] font-semibold uppercase tracking-[0.22em] text-brand-gold"> ${vehicle.category} </p> <h3 class="font-display text-xl font-medium leading-snug text-brand-forest transition-colors duration-300 group-hover:text-brand-gold"> ${vehicle.name} </h3> <p class="font-sans text-xs font-light text-neutral-600 tabular-nums"> ${vehicle.capacityLabel} </p> </div> </article>`;
}, "/home/josh/Documents/emerald-update/src/components/fleet/FleetCard.astro", void 0);

export { $$FleetCard as $, fleetCategoryTabs as a, defaultFeaturedId as d, fleet as f };

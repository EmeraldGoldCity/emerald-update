import { b as createAstro, c as createComponent, r as renderComponent, a as renderTemplate, m as maybeRenderHead, e as renderSlot, d as addAttribute } from './astro/server_DL3Tye_C.mjs';
import 'piccolore';
import { $ as $$BaseLayout, N as Navigation } from './Navigation_Dndl7_vA.mjs';
import 'clsx';

const $$Astro$1 = createAstro("https://emeraldcitylimos.com");
const $$LocationLayout = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$1, $$props, $$slots);
  Astro2.self = $$LocationLayout;
  const props = Astro2.props;
  return renderTemplate`${renderComponent($$result, "BaseLayout", $$BaseLayout, { ...props }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<a href="#main-content" class="skip-link sr-only-focusable">
Skip to main content
</a> ${renderComponent($$result2, "Navigation", Navigation, { "client:load": true, "client:component-hydration": "load", "client:component-path": "@/components/react/Navigation", "client:component-export": "Navigation" })} <main id="main-content" role="main"> ${renderSlot($$result2, $$slots["default"])} </main> ` })}`;
}, "/home/josh/Documents/emerald-update/src/layouts/LocationLayout.astro", void 0);

var __freeze = Object.freeze;
var __defProp = Object.defineProperty;
var __template = (cooked, raw) => __freeze(__defProp(cooked, "raw", { value: __freeze(cooked.slice()) }));
var _a;
const $$Astro = createAstro("https://emeraldcitylimos.com");
const $$LocationCTA = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$LocationCTA;
  const { location } = Astro2.props;
  const PHONE = "(206) 595-9675";
  const TEL_HREF = "tel:+12065959675";
  return renderTemplate(_a || (_a = __template(["", '<section class="relative overflow-hidden bg-brand-forest py-20 text-white sm:py-24"', '> <!-- Top gold rule --> <div class="absolute top-0 left-0 right-0 h-px" style="background: linear-gradient(90deg, transparent, rgba(163,126,44,0.5), transparent);" aria-hidden="true"></div> <!-- Subtle radial gradient for depth --> <div class="absolute inset-0" style="background: radial-gradient(ellipse 60% 50% at 50% 50%, rgba(163,126,44,0.08) 0%, transparent 70%);" aria-hidden="true"></div> <div class="relative mx-auto max-w-3xl px-6 text-center sm:px-8 lg:px-12"> <p class="mb-3 font-sans text-[11px] font-semibold uppercase tracking-[0.22em] text-brand-gold-soft">\nReserve your chauffeur\n</p> <h2', ' class="mb-6 font-display font-light leading-[1.1] text-white" style="font-size: clamp(2rem, 4vw, 3rem);">\nBook your\n<span class="italic text-brand-gold-soft">', '</span>\nride\n</h2> <p class="mx-auto mb-10 max-w-xl font-sans text-base leading-relaxed text-white/75 sm:text-lg">\nAvailable 24/7. Live flight tracking on every airport pickup. No surge pricing, no hidden tolls.\n</p> <div class="flex flex-col items-center justify-center gap-3 sm:flex-row sm:gap-4" role="group"', '> <a href="/book-now" data-cta="location_cta_book_now"', ' class="ecl-focusable inline-flex min-h-[52px] w-full items-center justify-center gap-2 rounded-none border border-brand-gold-soft bg-brand-gold-soft px-8 font-sans text-[11px] font-semibold uppercase tracking-[0.2em] text-brand-forest sm:w-auto">\nBook Now\n<span aria-hidden="true">\u2192</span> </a> <a', ' data-cta="location_cta_call"', ' class="ecl-focusable inline-flex min-h-[52px] w-full items-center justify-center gap-2 rounded-none border border-white/40 bg-transparent px-8 font-sans text-[11px] font-semibold uppercase tracking-[0.2em] text-white hover:border-white/70 sm:w-auto"> <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" width="14" height="14" aria-hidden="true"> <path stroke-linecap="round" stroke-linejoin="round" d="M2.25 6.75c0 8.284 6.716 15 15 15h2.25a2.25 2.25 0 002.25-2.25v-1.372c0-.516-.351-.966-.852-1.091l-4.423-1.106c-.44-.11-.902.055-1.173.417l-.97 1.293c-.282.376-.769.542-1.21.38a12.035 12.035 0 01-7.143-7.143c-.162-.441.004-.928.38-1.21l1.293-.97c.363-.271.527-.734.417-1.173L6.963 3.102a1.125 1.125 0 00-1.091-.852H4.5A2.25 2.25 0 002.25 4.5v2.25z"></path> </svg> <span class="tabular-nums">', `</span> </a> </div> </div> <!-- Bottom gold rule --> <div class="absolute bottom-0 left-0 right-0 h-px" style="background: linear-gradient(90deg, transparent, rgba(163,126,44,0.3), transparent);" aria-hidden="true"></div> </section> <script>
  document.querySelectorAll('a[data-cta^="location_cta"]').forEach((el) => {
    el.addEventListener('click', () => {
      const label = el.getAttribute('data-cta');
      if (window.gtag) window.gtag('event', 'click', { event_category: 'location_cta', event_label: label });
    });
  });
<\/script>`])), maybeRenderHead(), addAttribute(`cta-${location.slug}`, "aria-labelledby"), addAttribute(`cta-${location.slug}`, "id"), location.name, addAttribute(`Booking options for ${location.name}`, "aria-label"), addAttribute(`Book your ${location.name} chauffeur now`, "aria-label"), addAttribute(TEL_HREF, "href"), addAttribute(`Call ${PHONE}`, "aria-label"), PHONE);
}, "/home/josh/Documents/emerald-update/src/components/locations/LocationCTA.astro", void 0);

const HERO_DEFAULT = "/images/cad1.webp";
const HERO_IMAGES = {
  seattle: "/images/seattle-landmark.jpg",
  bellevue: "/images/Bellevue-landmark.jpg",
  redmond: "/images/Redmond-landmark.webp",
  kirkland: "/images/kirkland-landmark.jpg",
  renton: "/images/renton-landmark.jpg",
  tacoma: "/images/tacoma.jpg",
  everett: "/images/everrett.webp",
  lynnwood: "/images/lynnwood.jpg",
  edmonds: "/images/edmond.webp",
  bothell: "/images/bothell.png",
  woodinville: "/images/woodinville.webp",
  auburn: "/images/auburn-landmark.jpg",
  "federal-way": "/images/federal-way-landmark.webp",
  sammamish: "/images/sammamish-landmark.jpg",
  kent: "/images/kent-landmark.jpg",
  lakewood: "/images/lakewood.jpg",
  puyallup: "/images/puyallup.webp",
  marysville: "/images/marysville.jpg",
  "seatac-airport": "/images/seatac-airport.webp",
  "boeing-field": "/images/Boeing-Field-airport.jpg"
};
const locations = [
  {
    name: "Seattle",
    slug: "seattle",
    county: "King County",
    coordinates: { lat: 47.6062, lng: -122.3321 },
    zipCodes: ["98101", "98104", "98109", "98112", "98119", "98121", "98122", "98134", "98144"],
    heroImage: HERO_DEFAULT,
    heroImageAlt: "Black luxury chauffeur sedan on a downtown Seattle street with the Space Needle in the background",
    heroSupporting: "On-time, professionally chauffeured black-car service across downtown Seattle, Capitol Hill, Belltown, and the waterfront — booked 24/7.",
    localValueProp: "Seattle moves on its own clock. Meetings stack up in South Lake Union, dinners run late on Capitol Hill, and the I-5 reversible express lanes change direction without warning. Emerald City Limos is built around that reality. Our Seattle chauffeurs know which surface streets stay open during a Mariners game, where the loading zones at the Fairmont Olympic and Four Seasons actually let a Cadillac Escalade ESV pull up, and how to time a SeaTac run so you clear the airport expressway before it backs up. We hold a Washington Utilities and Transportation Commission permit, carry $1.5M in liability coverage, and dispatch flight-tracked rides for every airport pickup.",
    localValuePropExtended: "Whether you are flying in for a Microsoft, Amazon, or Boeing meeting, hosting clients during a Climate Pledge Arena event, or boarding a cruise at Pier 91, our chauffeurs greet you in business attire, handle your luggage, and route around the Mercer mess so you arrive composed.",
    nearbyLandmarks: [
      "Space Needle",
      "Pike Place Market",
      "Climate Pledge Arena",
      "Lumen Field",
      "T-Mobile Park",
      "Pier 91 Cruise Terminal",
      "Washington State Convention Center"
    ],
    businessDistricts: ["Downtown", "South Lake Union", "Belltown", "Pioneer Square"],
    hotels: ["Fairmont Olympic", "Four Seasons", "The Edgewater", "Lotte Hotel Seattle"],
    eventVenues: ["Climate Pledge Arena", "Lumen Field", "Paramount Theatre", "Benaroya Hall"],
    airportProximity: [
      { airport: "SEA-TAC International Airport", code: "SEA", distanceMiles: 13, driveTime: "20–30 min" },
      { airport: "Boeing Field (BFI)", code: "BFI", distanceMiles: 6, driveTime: "12–18 min" },
      { airport: "Paine Field (PAE)", code: "PAE", distanceMiles: 25, driveTime: "35–45 min" }
    ],
    popularRoutes: [
      { to: "SEA-TAC Airport", driveTime: "20–30 min", distanceMiles: 13, startingPriceUSD: 75 },
      { to: "Bellevue", driveTime: "15–25 min", distanceMiles: 10, startingPriceUSD: 75 },
      { to: "Redmond", driveTime: "25–40 min", distanceMiles: 16, startingPriceUSD: 95 },
      { to: "Pier 91 Cruise Terminal", driveTime: "15–25 min", distanceMiles: 4, startingPriceUSD: 75 },
      { to: "Tacoma", driveTime: "35–55 min", distanceMiles: 33, startingPriceUSD: 135 }
    ],
    faqs: [
      {
        question: "Do you serve all of Seattle, including Capitol Hill and West Seattle?",
        answer: "Yes. We serve every Seattle neighborhood — Downtown, Capitol Hill, Queen Anne, Ballard, Fremont, West Seattle, Magnolia, the U-District, Columbia City, and beyond. Our chauffeurs route around bridge openings and stadium-day closures so you arrive on time."
      },
      {
        question: "How much is an airport transfer from downtown Seattle to SEA-TAC?",
        answer: "Sedan service from downtown Seattle to SEA-TAC starts at $75 flat-rate; luxury SUVs start at $95. Pricing is all-inclusive — no surge, no hidden tolls — and every airport ride includes flight tracking and a 60-minute domestic / 90-minute international meet-and-greet grace period."
      },
      {
        question: "Can you handle corporate transportation for Seattle-based companies?",
        answer: "Yes. We run dedicated chauffeur accounts for executives across South Lake Union, Pioneer Square, and downtown — with consolidated billing, dispatcher-direct lines, and the same chauffeur reassigned to recurring rides on request."
      },
      {
        question: "Do you pick up from Pier 91 and Pier 66 cruise terminals?",
        answer: "Absolutely. Cruise transfers are one of our most-booked services from May through October. We monitor disembarkation times and stage chauffeurs in the designated black-car queue at both Pier 91 (Smith Cove) and Pier 66."
      },
      {
        question: "What vehicles are available for Seattle pickups?",
        answer: "Our Seattle fleet includes the Mercedes-Benz S-Class, Cadillac Escalade ESV, Lincoln Navigator L, Mercedes Sprinter executive vans, and stretch limousines for special occasions."
      }
    ],
    meta: {
      title: "Seattle Chauffeur Service | Emerald City Limos",
      description: "Luxury chauffeur and black-car service in Seattle. SEA-TAC airport transfers, corporate rides, weddings, and hourly chauffeur — booked 24/7.",
      keywords: ["seattle chauffeur", "seattle black car service", "seattle limo service", "seattle airport transfer"]
    }
  },
  {
    name: "Bellevue",
    slug: "bellevue",
    county: "King County",
    coordinates: { lat: 47.6101, lng: -122.2015 },
    zipCodes: ["98004", "98005", "98006", "98007", "98008"],
    heroImage: HERO_DEFAULT,
    heroImageAlt: "Black luxury chauffeur SUV waiting outside a Bellevue high-rise office tower at dusk",
    heroSupporting: "Executive chauffeur service for Bellevue’s tech corridor — flight-tracked airport runs, corporate accounts, and event transportation across the Eastside.",
    localValueProp: "Bellevue is no longer Seattle’s suburb — it is a Fortune-100 hub with Microsoft satellite offices, T-Mobile’s headquarters, and Amazon’s growing Eastside campus. Our Bellevue chauffeurs know the Bellevue Collection loading zones, where to stage at The Westin and the Hyatt Regency, and how the 520 toll plaza behaves at 5 p.m. on a Thursday. We also know that an executive flying into SEA-TAC at 8:55 p.m. needs a chauffeur already in the cell lot at 8:35 — not en route. Every airport pickup includes live flight tracking, a 60-minute domestic grace period, and a chauffeur in business attire holding a sign at the curb or, for international arrivals, baggage claim.",
    localValuePropExtended: "For events at Meydenbauer Center, holiday shopping at Bellevue Square, or wine tours into Woodinville, we deploy Cadillac Escalade ESVs and Mercedes Sprinter executive vans staged within ten minutes of the Eastside.",
    nearbyLandmarks: [
      "Bellevue Collection",
      "Bellevue Square",
      "Meydenbauer Center",
      "Bellevue Botanical Garden",
      "Downtown Park",
      "KEMPER Development office towers"
    ],
    businessDistricts: ["Downtown Bellevue", "Bel-Red Corridor", "Factoria", "Eastgate"],
    hotels: ["The Westin Bellevue", "Hyatt Regency Bellevue", "W Bellevue", "Hilton Bellevue"],
    eventVenues: ["Meydenbauer Center", "Hyatt Regency Bellevue ballrooms", "Bellevue Arts Museum"],
    airportProximity: [
      { airport: "SEA-TAC International Airport", code: "SEA", distanceMiles: 17, driveTime: "25–40 min" },
      { airport: "Boeing Field (BFI)", code: "BFI", distanceMiles: 13, driveTime: "20–30 min" },
      { airport: "Paine Field (PAE)", code: "PAE", distanceMiles: 26, driveTime: "35–50 min" }
    ],
    popularRoutes: [
      { to: "SEA-TAC Airport", driveTime: "25–40 min", distanceMiles: 17, startingPriceUSD: 95 },
      { to: "Downtown Seattle", driveTime: "15–25 min", distanceMiles: 10, startingPriceUSD: 75 },
      { to: "Redmond (Microsoft Campus)", driveTime: "10–20 min", distanceMiles: 7, startingPriceUSD: 75 },
      { to: "Woodinville Wine Country", driveTime: "15–25 min", distanceMiles: 10, startingPriceUSD: 95 },
      { to: "Paine Field", driveTime: "35–50 min", distanceMiles: 26, startingPriceUSD: 145 }
    ],
    faqs: [
      {
        question: "Do you serve all of Bellevue, including Bridle Trails and Somerset?",
        answer: "Yes. We serve every Bellevue neighborhood — Downtown, Bel-Red, Factoria, Eastgate, Bridle Trails, Somerset, Newport, and Crossroads — with the same flat-rate pricing and 24/7 dispatch."
      },
      {
        question: "What does an airport transfer from Bellevue to SEA-TAC cost?",
        answer: "Sedan service from Bellevue to SEA-TAC starts at $95 flat-rate; luxury SUVs from $115. Pricing is all-inclusive — flight tracking, meet-and-greet, tolls, and gratuity-disclosed."
      },
      {
        question: "Can you handle corporate transportation for Bellevue-based companies?",
        answer: "Yes. We run dedicated chauffeur accounts for Eastside companies including consolidated monthly billing, dispatcher-direct phone lines, and recurring chauffeur assignments for executives who want the same driver every week."
      },
      {
        question: "Do you provide chauffeurs for events at Meydenbauer Center?",
        answer: "We do — we routinely stage Cadillac Escalade ESVs and Mercedes Sprinter vans for conferences, galas, and corporate events at Meydenbauer Center, the Hyatt Regency Bellevue, and the Bellevue Collection."
      }
    ],
    meta: {
      title: "Bellevue Chauffeur Service | Emerald City Limos",
      description: "Premium chauffeur service in Bellevue, WA. Flight-tracked SEA-TAC transfers, corporate accounts, weddings, and hourly chauffeur — booked 24/7.",
      keywords: ["bellevue chauffeur", "bellevue black car service", "bellevue limo service", "bellevue corporate transportation"]
    }
  },
  {
    name: "Redmond",
    slug: "redmond",
    county: "King County",
    coordinates: { lat: 47.674, lng: -122.1215 },
    zipCodes: ["98052", "98053", "98073"],
    heroImage: HERO_DEFAULT,
    heroImageAlt: "Black luxury chauffeur sedan parked at the Microsoft Redmond campus entrance",
    heroSupporting: "Chauffeur service for the Microsoft Redmond Campus, Marymoor Park, and the Eastside tech corridor — flight-tracked, business-attired, on time.",
    localValueProp: "Redmond runs on Microsoft’s campus rhythm and a tightly packed schedule of investor visits, partner meetings, and offsite retreats. Our Redmond chauffeurs know every campus building number — from Studio H to The Commons — and route around the daily 520 backups so a 9 a.m. arrival at Building 33 lands at 8:55. We also support the steady stream of international executives flying into SEA-TAC for week-long visits: flight-tracked pickups, a chauffeur waiting in baggage claim with a discreet sign, and a quiet ride to the Westin Redmond or the Marriott Redmond Town Center.",
    nearbyLandmarks: [
      "Microsoft Redmond Campus",
      "Marymoor Park",
      "Redmond Town Center",
      "Sammamish River Trail",
      "Willows Run Golf Club"
    ],
    businessDistricts: ["Microsoft Campus", "Overlake", "Downtown Redmond", "Education Hill"],
    hotels: ["The Westin Redmond", "Marriott Redmond Town Center", "Residence Inn Redmond"],
    eventVenues: ["Marymoor Park", "Microsoft Conference Center", "Redmond Town Center plaza"],
    airportProximity: [
      { airport: "SEA-TAC International Airport", code: "SEA", distanceMiles: 22, driveTime: "30–45 min" },
      { airport: "Boeing Field (BFI)", code: "BFI", distanceMiles: 18, driveTime: "25–40 min" },
      { airport: "Paine Field (PAE)", code: "PAE", distanceMiles: 24, driveTime: "30–45 min" }
    ],
    popularRoutes: [
      { to: "SEA-TAC Airport", driveTime: "30–45 min", distanceMiles: 22, startingPriceUSD: 110 },
      { to: "Downtown Seattle", driveTime: "25–40 min", distanceMiles: 16, startingPriceUSD: 95 },
      { to: "Bellevue", driveTime: "10–20 min", distanceMiles: 7, startingPriceUSD: 75 },
      { to: "Woodinville Wine Country", driveTime: "15–25 min", distanceMiles: 8, startingPriceUSD: 85 }
    ],
    faqs: [
      {
        question: "Do you serve the Microsoft Redmond Campus?",
        answer: "Yes. We pick up and drop off at every Microsoft building. Our chauffeurs have campus access protocols memorized and use the correct visitor entries."
      },
      {
        question: "How much is a Redmond to SEA-TAC airport transfer?",
        answer: "Sedan service from Redmond to SEA-TAC starts at $110 flat-rate; luxury SUVs from $135. Includes flight tracking, meet-and-greet, and tolls."
      },
      {
        question: "Can you set up a corporate account for our Redmond office?",
        answer: "Yes. We onboard corporate accounts in 48 hours with consolidated invoicing, named chauffeur preferences, and a dispatcher-direct line."
      },
      {
        question: "Do you offer hourly chauffeur service in Redmond?",
        answer: "Yes. Hourly chauffeur (3-hour minimum) is popular for back-to-back partner meetings, board offsites, and full-day customer briefings."
      }
    ],
    meta: {
      title: "Redmond Chauffeur Service | Emerald City Limos",
      description: "Luxury chauffeur service in Redmond, WA. Microsoft Campus pickups, SEA-TAC transfers, corporate accounts — flight-tracked and booked 24/7.",
      keywords: ["redmond chauffeur", "redmond limo service", "microsoft campus car service", "redmond airport transfer"]
    }
  },
  {
    name: "Kirkland",
    slug: "kirkland",
    county: "King County",
    coordinates: { lat: 47.6815, lng: -122.2087 },
    zipCodes: ["98033", "98034"],
    heroImage: HERO_DEFAULT,
    heroImageAlt: "Black luxury chauffeur SUV at a Kirkland waterfront restaurant overlooking Lake Washington",
    heroSupporting: "Chauffeured transportation across Kirkland — Google’s Eastside campus, Carillon Point, and the Lake Washington waterfront, available 24/7.",
    localValueProp: "Kirkland is where the Eastside loosens its tie. Carillon Point hosts client dinners on the water, Google’s Kirkland campus runs partner offsites, and Juanita Bay weddings spill into late summer evenings. Our Kirkland chauffeurs are staged within ten minutes of downtown — they know the Houghton Beach pickup quirks, the Heathman Hotel valet rotation, and which Lake Street side streets stay clear during the summer farmers market. For airport runs, we monitor flights live and pre-position the chauffeur so a return from SEA-TAC drops you at your front door before the takeout cools.",
    nearbyLandmarks: ["Carillon Point", "Kirkland Waterfront", "Juanita Bay Park", "Marina Park", "Google Kirkland Campus"],
    businessDistricts: ["Downtown Kirkland", "Totem Lake", "Houghton", "Juanita"],
    hotels: ["The Heathman Hotel Kirkland", "Woodmark Hotel & Still Spa"],
    eventVenues: ["Woodmark Hotel ballroom", "Carillon Point", "Kirkland Performance Center"],
    airportProximity: [
      { airport: "SEA-TAC International Airport", code: "SEA", distanceMiles: 22, driveTime: "30–45 min" },
      { airport: "Boeing Field (BFI)", code: "BFI", distanceMiles: 18, driveTime: "25–40 min" },
      { airport: "Paine Field (PAE)", code: "PAE", distanceMiles: 21, driveTime: "28–40 min" }
    ],
    popularRoutes: [
      { to: "SEA-TAC Airport", driveTime: "30–45 min", distanceMiles: 22, startingPriceUSD: 105 },
      { to: "Downtown Seattle", driveTime: "20–35 min", distanceMiles: 12, startingPriceUSD: 85 },
      { to: "Bellevue", driveTime: "10–20 min", distanceMiles: 6, startingPriceUSD: 75 },
      { to: "Woodinville Wine Country", driveTime: "12–20 min", distanceMiles: 6, startingPriceUSD: 75 }
    ],
    faqs: [
      {
        question: "Do you serve all of Kirkland, including Totem Lake and Juanita?",
        answer: "Yes — Downtown, Houghton, Juanita, Totem Lake, and Finn Hill. Same flat-rate pricing across all Kirkland ZIPs (98033, 98034)."
      },
      {
        question: "How much is a Kirkland to SEA-TAC airport transfer?",
        answer: "Sedan service from Kirkland to SEA-TAC starts at $105 flat-rate; luxury SUVs from $130. All-inclusive pricing with flight tracking and meet-and-greet."
      },
      {
        question: "Do you do wedding transportation for the Woodmark Hotel?",
        answer: "Frequently. The Woodmark is one of our most-served wedding venues. We coordinate with the property’s event team and stage vehicles in the designated lot."
      }
    ],
    meta: {
      title: "Kirkland Chauffeur Service | Emerald City Limos",
      description: "Luxury chauffeur service in Kirkland, WA. Google Campus pickups, Woodmark weddings, SEA-TAC transfers — booked 24/7.",
      keywords: ["kirkland chauffeur", "kirkland limo service", "kirkland car service", "woodmark hotel wedding transportation"]
    }
  },
  {
    name: "Renton",
    slug: "renton",
    county: "King County",
    coordinates: { lat: 47.4829, lng: -122.2171 },
    zipCodes: ["98055", "98056", "98057", "98058", "98059"],
    heroImage: HERO_DEFAULT,
    heroImageAlt: "Black luxury chauffeur sedan parked outside the Boeing Renton plant at sunrise",
    heroSupporting: "Chauffeur service for Renton — Boeing 737 plant, The Landing, and the Seahawks training facility — fast SEA-TAC access at flat-rate pricing.",
    localValueProp: "Renton’s proximity to SEA-TAC (a 12-minute run on a clear day) makes it one of the most popular pickup zones on our schedule. We move Boeing executives between the 737 final assembly plant and the airport, ferry season-ticket holders to Seahawks practice at the Virginia Mason Athletic Center, and run hourly chauffeurs through The Landing and the Renton Highlands. Our chauffeurs know which I-405 ramps to skip during the afternoon Renton-to-Bellevue crawl and which back routes through Skyway shave ten minutes off a SEA-TAC return.",
    nearbyLandmarks: [
      "Boeing Renton Factory",
      "The Landing",
      "Gene Coulon Memorial Beach Park",
      "Virginia Mason Athletic Center (Seahawks)",
      "Renton Municipal Airport"
    ],
    businessDistricts: ["Downtown Renton", "The Landing", "Renton Highlands", "Tukwila border"],
    hotels: ["Hyatt Regency Lake Washington at Seattle’s Southport", "Larkspur Landing Renton"],
    eventVenues: ["Hyatt Regency Lake Washington", "Renton Pavilion Event Center"],
    airportProximity: [
      { airport: "SEA-TAC International Airport", code: "SEA", distanceMiles: 9, driveTime: "12–20 min" },
      { airport: "Boeing Field (BFI)", code: "BFI", distanceMiles: 8, driveTime: "12–18 min" }
    ],
    popularRoutes: [
      { to: "SEA-TAC Airport", driveTime: "12–20 min", distanceMiles: 9, startingPriceUSD: 75 },
      { to: "Downtown Seattle", driveTime: "20–30 min", distanceMiles: 13, startingPriceUSD: 85 },
      { to: "Bellevue", driveTime: "15–25 min", distanceMiles: 9, startingPriceUSD: 85 },
      { to: "Boeing Field", driveTime: "12–18 min", distanceMiles: 8, startingPriceUSD: 75 }
    ],
    faqs: [
      {
        question: "How quickly can I get from Renton to SEA-TAC?",
        answer: "Renton is one of the fastest SEA-TAC pickup zones — typically 12–20 minutes door-to-door. Sedan service starts at $75 flat-rate."
      },
      {
        question: "Do you serve the Boeing Renton Factory?",
        answer: "Yes — we routinely chauffeur Boeing executives, customers, and visiting delegations between the 737 plant and SEA-TAC, downtown Seattle, and Bellevue."
      },
      {
        question: "Can you set up corporate accounts for Renton-based businesses?",
        answer: "Yes — corporate onboarding takes 48 hours and includes consolidated billing, dispatcher-direct lines, and named chauffeur preferences."
      }
    ],
    meta: {
      title: "Renton Chauffeur Service | Emerald City Limos",
      description: "Luxury chauffeur service in Renton, WA. Fast SEA-TAC transfers, Boeing plant pickups, corporate accounts — flat-rate, 24/7.",
      keywords: ["renton chauffeur", "renton limo service", "boeing renton car service", "renton airport transfer"]
    }
  },
  {
    name: "Tacoma",
    slug: "tacoma",
    county: "Pierce County",
    coordinates: { lat: 47.2529, lng: -122.4443 },
    zipCodes: ["98402", "98403", "98404", "98405", "98406", "98407", "98408", "98409"],
    heroImage: HERO_DEFAULT,
    heroImageAlt: "Black luxury chauffeur SUV on the Tacoma Narrows Bridge at sunset",
    heroSupporting: "Chauffeur service across Tacoma — University of Puget Sound, Point Ruston, the Tacoma Dome — with flat-rate SEA-TAC and Sea-Tac cruise transfers.",
    localValueProp: "Tacoma is its own city, not a Seattle suburb — and our Tacoma chauffeur service treats it that way. We run flat-rate transfers from Old Town and Stadium District to SEA-TAC, ferry corporate visitors between the Tacoma Dome, Greater Tacoma Convention Center, and Hotel Murano, and stage Mercedes Sprinter executive vans for events at LeMay – America’s Car Museum and Point Ruston. Our chauffeurs know the I-5 patterns through Fife and the alternate routes via Highway 167 when the southbound lanes wedge up at JBLM.",
    nearbyLandmarks: [
      "Tacoma Dome",
      "Point Defiance Park",
      "Point Ruston",
      "LeMay – America’s Car Museum",
      "Museum of Glass",
      "University of Puget Sound"
    ],
    businessDistricts: ["Downtown Tacoma", "Stadium District", "Hilltop", "Old Town"],
    hotels: ["Hotel Murano", "Marriott Courtyard Tacoma Downtown", "McMenamins Elks Temple"],
    eventVenues: ["Tacoma Dome", "Greater Tacoma Convention Center", "Pantages Theater", "Foss Waterway Seaport"],
    airportProximity: [
      { airport: "SEA-TAC International Airport", code: "SEA", distanceMiles: 21, driveTime: "30–50 min" },
      { airport: "Boeing Field (BFI)", code: "BFI", distanceMiles: 27, driveTime: "35–55 min" }
    ],
    popularRoutes: [
      { to: "SEA-TAC Airport", driveTime: "30–50 min", distanceMiles: 21, startingPriceUSD: 115 },
      { to: "Downtown Seattle", driveTime: "35–55 min", distanceMiles: 33, startingPriceUSD: 145 },
      { to: "Bellevue", driveTime: "40–60 min", distanceMiles: 38, startingPriceUSD: 165 },
      { to: "Joint Base Lewis-McChord", driveTime: "15–25 min", distanceMiles: 12, startingPriceUSD: 95 }
    ],
    faqs: [
      {
        question: "Do you serve all of Tacoma, including Ruston and University Place?",
        answer: "Yes — Downtown, Stadium District, Old Town, Ruston, North End, and out to University Place at flat-rate pricing."
      },
      {
        question: "How much is a Tacoma to SEA-TAC airport transfer?",
        answer: "Sedan service from Tacoma to SEA-TAC starts at $115 flat-rate; luxury SUVs from $145. All-inclusive with flight tracking and tolls."
      },
      {
        question: "Do you offer transportation for Tacoma Dome events?",
        answer: "Yes — we routinely shuttle groups to and from concerts and conventions at the Tacoma Dome, with Mercedes Sprinter vans for groups of 8–14."
      }
    ],
    meta: {
      title: "Tacoma Chauffeur Service | Emerald City Limos",
      description: "Luxury chauffeur service in Tacoma, WA. Flat-rate SEA-TAC transfers, Tacoma Dome events, corporate accounts — flight-tracked, 24/7.",
      keywords: ["tacoma chauffeur", "tacoma limo service", "tacoma airport transfer", "tacoma dome transportation"]
    }
  },
  {
    name: "Everett",
    slug: "everett",
    county: "Snohomish County",
    coordinates: { lat: 47.9789, lng: -122.2021 },
    zipCodes: ["98201", "98203", "98204", "98208"],
    heroImage: HERO_DEFAULT,
    heroImageAlt: "Black luxury chauffeur SUV outside the Boeing Everett Factory at sunrise",
    heroSupporting: "Chauffeur service across Everett — Boeing Everett Factory, Naval Station Everett, Funko HQ — with fast Paine Field and SEA-TAC transfers.",
    localValueProp: "Everett is the heartbeat of Snohomish County aerospace. Our chauffeurs run a steady cadence between the Boeing Everett Factory, Paine Field (PAE), and Naval Station Everett — plus the rapidly growing Funko, Fluke, and Boeing supplier campuses. Paine Field is just three miles from the Boeing plant and runs commercial flights to nine cities, so we handle a high volume of executive transfers without the SEA-TAC hour. For SEA-TAC-bound clients, we time runs against I-5 traffic through Lynnwood and Mountlake Terrace.",
    nearbyLandmarks: [
      "Boeing Everett Factory & Future of Flight",
      "Paine Field (PAE)",
      "Naval Station Everett",
      "Angel of the Winds Arena",
      "Historic Everett Theatre"
    ],
    businessDistricts: ["Downtown Everett", "Boeing/Paine Field corridor", "Silver Lake"],
    hotels: ["Courtyard Marriott Everett", "Hilton Garden Inn Everett", "Holiday Inn Downtown Everett"],
    eventVenues: ["Angel of the Winds Arena", "Historic Everett Theatre", "Future of Flight Aviation Center"],
    airportProximity: [
      { airport: "Paine Field (PAE)", code: "PAE", distanceMiles: 5, driveTime: "8–15 min" },
      { airport: "SEA-TAC International Airport", code: "SEA", distanceMiles: 32, driveTime: "40–60 min" },
      { airport: "Boeing Field (BFI)", code: "BFI", distanceMiles: 32, driveTime: "40–55 min" }
    ],
    popularRoutes: [
      { to: "Paine Field", driveTime: "8–15 min", distanceMiles: 5, startingPriceUSD: 75 },
      { to: "SEA-TAC Airport", driveTime: "40–60 min", distanceMiles: 32, startingPriceUSD: 145 },
      { to: "Downtown Seattle", driveTime: "35–55 min", distanceMiles: 28, startingPriceUSD: 135 },
      { to: "Boeing Everett Factory", driveTime: "5–10 min", distanceMiles: 3, startingPriceUSD: 65 }
    ],
    faqs: [
      {
        question: "Do you serve the Boeing Everett Factory?",
        answer: "Yes — daily. Our chauffeurs have visitor protocols memorized and stage at the correct gates for executive arrivals and Future of Flight tours."
      },
      {
        question: "How much is an Everett to SEA-TAC airport transfer?",
        answer: "Sedan service from Everett to SEA-TAC starts at $145 flat-rate; luxury SUVs from $175. We route around I-5 backups when traffic warrants."
      },
      {
        question: "Do you serve Paine Field commercial passengers?",
        answer: "Absolutely — Paine Field is one of our highest-volume pickup airports. Sedan service from Everett to PAE starts at $75."
      }
    ],
    meta: {
      title: "Everett Chauffeur Service | Emerald City Limos",
      description: "Luxury chauffeur service in Everett, WA. Boeing Factory pickups, Paine Field and SEA-TAC transfers, corporate accounts — 24/7.",
      keywords: ["everett chauffeur", "everett limo service", "paine field car service", "boeing everett car service"]
    }
  },
  {
    name: "Lynnwood",
    slug: "lynnwood",
    county: "Snohomish County",
    coordinates: { lat: 47.8209, lng: -122.3151 },
    zipCodes: ["98036", "98037", "98087"],
    heroImage: HERO_DEFAULT,
    heroImageAlt: "Black luxury chauffeur SUV outside Alderwood Mall in Lynnwood",
    heroSupporting: "Chauffeur service across Lynnwood — Alderwood Mall, Edmonds Community College, the Lynnwood Convention Center — with flat-rate SEA-TAC and Paine Field transfers.",
    localValueProp: "Lynnwood sits at the I-5/I-405 split — the most-used commute artery between Snohomish and King counties — and our chauffeurs work it daily. We handle SEA-TAC-bound transfers for the entire Alderwood corridor, run hourly chauffeur for events at the Lynnwood Convention Center, and provide group transportation in Mercedes Sprinters for weddings and reunions at the larger banquet venues. With Sound Transit Link light-rail extending to Lynnwood City Center Station, we increasingly meet clients at the station for the “last mile” to home or hotel in a Mercedes S-Class.",
    nearbyLandmarks: [
      "Alderwood Mall",
      "Lynnwood Convention Center",
      "Edmonds Community College",
      "Lynnwood Link light-rail station"
    ],
    businessDistricts: ["Alderwood", "Lynnwood City Center", "Highway 99 corridor"],
    hotels: ["Embassy Suites by Hilton Seattle North Lynnwood", "Hampton Inn & Suites Lynnwood"],
    eventVenues: ["Lynnwood Convention Center", "Embassy Suites ballroom"],
    airportProximity: [
      { airport: "Paine Field (PAE)", code: "PAE", distanceMiles: 9, driveTime: "12–20 min" },
      { airport: "SEA-TAC International Airport", code: "SEA", distanceMiles: 24, driveTime: "30–50 min" },
      { airport: "Boeing Field (BFI)", code: "BFI", distanceMiles: 24, driveTime: "30–45 min" }
    ],
    popularRoutes: [
      { to: "SEA-TAC Airport", driveTime: "30–50 min", distanceMiles: 24, startingPriceUSD: 125 },
      { to: "Paine Field", driveTime: "12–20 min", distanceMiles: 9, startingPriceUSD: 85 },
      { to: "Downtown Seattle", driveTime: "25–45 min", distanceMiles: 17, startingPriceUSD: 105 },
      { to: "Bellevue", driveTime: "25–40 min", distanceMiles: 18, startingPriceUSD: 110 }
    ],
    faqs: [
      {
        question: "Do you serve all of Lynnwood?",
        answer: "Yes — Alderwood, Lynnwood City Center, the Highway 99 corridor, and out to Mountlake Terrace."
      },
      {
        question: "How much is a Lynnwood to SEA-TAC transfer?",
        answer: "Sedan service starts at $125 flat-rate; luxury SUVs from $155. All-inclusive with flight tracking."
      },
      {
        question: "Do you provide chauffeurs for Lynnwood Convention Center events?",
        answer: "Yes — we routinely deploy Mercedes Sprinters and Cadillac Escalades for conferences and corporate events at the Lynnwood Convention Center."
      }
    ],
    meta: {
      title: "Lynnwood Chauffeur Service | Emerald City Limos",
      description: "Luxury chauffeur service in Lynnwood, WA. SEA-TAC and Paine Field transfers, convention center events, corporate accounts — 24/7.",
      keywords: ["lynnwood chauffeur", "lynnwood limo service", "lynnwood airport transfer", "alderwood car service"]
    }
  },
  {
    name: "Edmonds",
    slug: "edmonds",
    county: "Snohomish County",
    coordinates: { lat: 47.8107, lng: -122.3774 },
    zipCodes: ["98020", "98026"],
    heroImage: HERO_DEFAULT,
    heroImageAlt: "Black luxury chauffeur sedan at the Edmonds ferry terminal at golden hour",
    heroSupporting: "Chauffeur service throughout Edmonds — the ferry terminal, downtown waterfront, and Edmonds Center for the Arts — with fast Paine Field and SEA-TAC transfers.",
    localValueProp: "Edmonds is a destination, not a thoroughfare — its quiet, walkable downtown, the Edmonds-Kingston ferry, and Edmonds Center for the Arts pull in a steady stream of visitors who want to leave the car at home. Our chauffeurs handle ferry-aligned pickups (we time arrivals to actual sailings, not advertised ones), shuttle Edmonds residents to SEA-TAC and Paine Field, and run anniversary or birthday occasions in our stretch limousines along the waterfront. We also support corporate clients in the Westgate and Five Corners commercial pockets.",
    nearbyLandmarks: [
      "Edmonds-Kingston Ferry Terminal",
      "Edmonds Center for the Arts",
      "Brackett’s Landing Park",
      "Edmonds Marina"
    ],
    businessDistricts: ["Downtown Edmonds", "Westgate", "Five Corners"],
    hotels: ["Best Western Plus Edmonds Harbor Inn"],
    eventVenues: ["Edmonds Center for the Arts"],
    airportProximity: [
      { airport: "Paine Field (PAE)", code: "PAE", distanceMiles: 11, driveTime: "15–22 min" },
      { airport: "SEA-TAC International Airport", code: "SEA", distanceMiles: 27, driveTime: "35–55 min" }
    ],
    popularRoutes: [
      { to: "SEA-TAC Airport", driveTime: "35–55 min", distanceMiles: 27, startingPriceUSD: 135 },
      { to: "Paine Field", driveTime: "15–22 min", distanceMiles: 11, startingPriceUSD: 95 },
      { to: "Edmonds-Kingston Ferry Terminal", driveTime: "5–10 min", distanceMiles: 1, startingPriceUSD: 65 },
      { to: "Downtown Seattle", driveTime: "25–45 min", distanceMiles: 18, startingPriceUSD: 110 }
    ],
    faqs: [
      {
        question: "Can you time a pickup with my Edmonds-Kingston ferry?",
        answer: "Yes — we monitor WSDOT ferry sailings and adjust pickup times to actual departures, not posted ones. Tell us your booked sailing and we’ll do the rest."
      },
      {
        question: "How much is an Edmonds to SEA-TAC transfer?",
        answer: "Sedan service from Edmonds to SEA-TAC starts at $135 flat-rate; luxury SUVs from $165."
      }
    ],
    meta: {
      title: "Edmonds Chauffeur Service | Emerald City Limos",
      description: "Luxury chauffeur service in Edmonds, WA. Ferry-aligned pickups, SEA-TAC and Paine Field transfers, special occasions — booked 24/7.",
      keywords: ["edmonds chauffeur", "edmonds limo service", "edmonds ferry car service", "edmonds airport transfer"]
    }
  },
  {
    name: "Bothell",
    slug: "bothell",
    county: "King County",
    coordinates: { lat: 47.7623, lng: -122.2054 },
    zipCodes: ["98011", "98012", "98021"],
    heroImage: HERO_DEFAULT,
    heroImageAlt: "Black luxury chauffeur SUV at a Bothell biotech campus parking circle",
    heroSupporting: "Chauffeur service across Bothell — UW Bothell, Canyon Park biotech campuses, Country Village — with quick Paine Field and SEA-TAC access.",
    localValueProp: "Bothell is one of the Eastside’s busiest biotech corridors. Seagen, Juno, AGC Biologics, and a cluster of mid-stage life-sciences companies in Canyon Park draw a steady stream of visiting executives, FDA inspectors, and clinical-trial partners — and we move them. Our chauffeurs know which Canyon Park building circles can fit a Cadillac Escalade, the I-405 patterns into and out of Bellevue, and the back routes via Bothell-Everett Highway when 405 stalls.",
    nearbyLandmarks: ["UW Bothell", "Canyon Park biotech corridor", "Country Village (historic)", "Bothell Landing Park"],
    businessDistricts: ["Canyon Park", "Downtown Bothell", "North Creek"],
    hotels: ["Hilton Garden Inn Seattle/Bothell", "Country Inn & Suites Bothell"],
    eventVenues: ["McMenamins Anderson School"],
    airportProximity: [
      { airport: "Paine Field (PAE)", code: "PAE", distanceMiles: 13, driveTime: "18–28 min" },
      { airport: "SEA-TAC International Airport", code: "SEA", distanceMiles: 25, driveTime: "35–55 min" }
    ],
    popularRoutes: [
      { to: "SEA-TAC Airport", driveTime: "35–55 min", distanceMiles: 25, startingPriceUSD: 125 },
      { to: "Paine Field", driveTime: "18–28 min", distanceMiles: 13, startingPriceUSD: 95 },
      { to: "Bellevue", driveTime: "15–25 min", distanceMiles: 12, startingPriceUSD: 95 },
      { to: "Downtown Seattle", driveTime: "25–45 min", distanceMiles: 18, startingPriceUSD: 110 }
    ],
    faqs: [
      {
        question: "Do you serve the Canyon Park biotech corridor?",
        answer: "Yes — daily. We run dedicated corporate accounts for several Canyon Park companies and onboard new accounts in 48 hours."
      },
      {
        question: "How much is a Bothell to SEA-TAC transfer?",
        answer: "Sedan service from Bothell to SEA-TAC starts at $125 flat-rate; luxury SUVs from $155."
      }
    ],
    meta: {
      title: "Bothell Chauffeur Service | Emerald City Limos",
      description: "Luxury chauffeur service in Bothell, WA. Canyon Park biotech pickups, SEA-TAC transfers, corporate accounts — flight-tracked, 24/7.",
      keywords: ["bothell chauffeur", "bothell limo service", "canyon park car service", "bothell airport transfer"]
    }
  },
  {
    name: "Woodinville",
    slug: "woodinville",
    county: "King County",
    coordinates: { lat: 47.7543, lng: -122.1635 },
    zipCodes: ["98072", "98077"],
    heroImage: HERO_DEFAULT,
    heroImageAlt: "Black luxury chauffeur SUV at a Woodinville winery tasting room patio",
    heroSupporting: "Wine country chauffeur service in Woodinville — Chateau Ste. Michelle, the Hollywood District, the Warehouse District — with private wine tours and group Sprinters.",
    localValueProp: "Woodinville is Washington wine country in miniature: 130+ tasting rooms across the Hollywood, Warehouse, and Downtown districts, all walking distance from Chateau Ste. Michelle. We run private-label wine tours in Cadillac Escalade ESVs, Mercedes Sprinter executive vans for groups of 8–14, and stretch limousines for bachelorette parties and milestone birthdays. Our chauffeurs know the tasting room layouts, where to stage during evening dinner-and-tasting events at The Herbfarm, and how to time a return to Bellevue or downtown Seattle so the night winds down on schedule.",
    nearbyLandmarks: [
      "Chateau Ste. Michelle",
      "Columbia Winery",
      "The Herbfarm",
      "Hollywood Schoolhouse",
      "Warehouse District tasting rooms"
    ],
    businessDistricts: ["Hollywood District", "Warehouse District", "Downtown Woodinville"],
    hotels: ["Willows Lodge"],
    eventVenues: ["Chateau Ste. Michelle amphitheater", "Willows Lodge", "Hollywood Schoolhouse"],
    airportProximity: [
      { airport: "Paine Field (PAE)", code: "PAE", distanceMiles: 17, driveTime: "22–32 min" },
      { airport: "SEA-TAC International Airport", code: "SEA", distanceMiles: 25, driveTime: "35–55 min" }
    ],
    popularRoutes: [
      { to: "SEA-TAC Airport", driveTime: "35–55 min", distanceMiles: 25, startingPriceUSD: 125 },
      { to: "Bellevue", driveTime: "15–25 min", distanceMiles: 10, startingPriceUSD: 85 },
      { to: "Downtown Seattle", driveTime: "30–50 min", distanceMiles: 22, startingPriceUSD: 125 },
      { to: "Kirkland", driveTime: "12–20 min", distanceMiles: 6, startingPriceUSD: 75 }
    ],
    faqs: [
      {
        question: "Do you offer Woodinville wine tours?",
        answer: "Yes — private wine tours are one of our most-booked Woodinville services. Choose 4-, 6-, or 8-hour blocks in a Cadillac Escalade ESV (up to 6) or Mercedes Sprinter (up to 14)."
      },
      {
        question: "Can you handle a Woodinville bachelorette party?",
        answer: "Absolutely. Stretch limousines or Mercedes Sprinters with bar setups, ambient lighting, and a chauffeur who knows the route."
      }
    ],
    meta: {
      title: "Woodinville Wine Tour Chauffeur | Emerald City Limos",
      description: "Luxury chauffeur service and private wine tours in Woodinville, WA. Cadillac Escalades, Mercedes Sprinters, stretch limousines — booked 24/7.",
      keywords: ["woodinville wine tour", "woodinville chauffeur", "woodinville limo service", "chateau ste michelle car service"]
    }
  },
  {
    name: "Auburn",
    slug: "auburn",
    county: "King County",
    coordinates: { lat: 47.3073, lng: -122.2285 },
    zipCodes: ["98001", "98002", "98092"],
    heroImage: HERO_DEFAULT,
    heroImageAlt: "Black luxury chauffeur sedan at Muckleshoot Casino in Auburn",
    heroSupporting: "Chauffeur service across Auburn — Muckleshoot Casino, Emerald Downs, the Boeing Auburn plant — with quick SEA-TAC and Sea-Tac cruise transfers.",
    localValueProp: "Auburn anchors the southern stretch of King County. Muckleshoot Casino draws nightly crowds, Emerald Downs hosts thoroughbred racing through the summer, and the Boeing Auburn site keeps a steady flow of executive visitors. We handle high-volume night runs to and from Muckleshoot in Cadillac Escalade ESVs and stretch limousines, plus SEA-TAC transfers timed against I-5 evening congestion through Federal Way and Kent.",
    nearbyLandmarks: ["Muckleshoot Casino Resort", "Emerald Downs", "Boeing Auburn site", "White River Amphitheatre"],
    businessDistricts: ["Downtown Auburn", "Auburn Way", "Boeing Auburn"],
    hotels: ["Holiday Inn Express Auburn"],
    eventVenues: ["Muckleshoot Casino", "Emerald Downs", "White River Amphitheatre"],
    airportProximity: [
      { airport: "SEA-TAC International Airport", code: "SEA", distanceMiles: 13, driveTime: "20–35 min" },
      { airport: "Boeing Field (BFI)", code: "BFI", distanceMiles: 18, driveTime: "25–40 min" }
    ],
    popularRoutes: [
      { to: "SEA-TAC Airport", driveTime: "20–35 min", distanceMiles: 13, startingPriceUSD: 95 },
      { to: "Muckleshoot Casino", driveTime: "5–12 min", distanceMiles: 3, startingPriceUSD: 65 },
      { to: "Downtown Seattle", driveTime: "30–50 min", distanceMiles: 25, startingPriceUSD: 130 },
      { to: "Tacoma", driveTime: "20–30 min", distanceMiles: 15, startingPriceUSD: 95 }
    ],
    faqs: [
      {
        question: "Do you serve Muckleshoot Casino late at night?",
        answer: "Yes — 24/7 dispatch covers Muckleshoot every night of the week. Sedan or stretch limousine pickups available with 30 minutes notice."
      },
      {
        question: "How much is an Auburn to SEA-TAC transfer?",
        answer: "Sedan service from Auburn to SEA-TAC starts at $95 flat-rate; luxury SUVs from $115."
      }
    ],
    meta: {
      title: "Auburn Chauffeur Service | Emerald City Limos",
      description: "Luxury chauffeur service in Auburn, WA. Muckleshoot Casino, SEA-TAC transfers, Boeing pickups — flat-rate, booked 24/7.",
      keywords: ["auburn chauffeur", "auburn limo service", "muckleshoot casino car service", "auburn airport transfer"]
    }
  },
  {
    name: "Federal Way",
    slug: "federal-way",
    county: "King County",
    coordinates: { lat: 47.3223, lng: -122.3126 },
    zipCodes: ["98003", "98023", "98063"],
    heroImage: HERO_DEFAULT,
    heroImageAlt: "Black luxury chauffeur SUV at the Performing Arts and Event Center in Federal Way",
    heroSupporting: "Chauffeur service across Federal Way — the Performing Arts & Event Center, Wild Waves, the Commons — with fast SEA-TAC transfers.",
    localValueProp: "Federal Way sits 8 miles south of SEA-TAC, making it one of our fastest airport pickup zones in the south end. We chauffeur travelers between Federal Way’s residential neighborhoods and SEA-TAC, run hourly chauffeurs for events at the Performing Arts and Event Center, and provide group transportation to Wild Waves, the Pacific Bonsai Museum, and Dash Point State Park. Our chauffeurs route around I-5 incidents through the Tacoma Dome stretch when traffic warrants.",
    nearbyLandmarks: [
      "Federal Way Performing Arts and Event Center",
      "Wild Waves Theme Park",
      "The Commons at Federal Way",
      "Dash Point State Park",
      "Pacific Bonsai Museum"
    ],
    businessDistricts: ["Downtown Federal Way", "Twin Lakes", "West Campus"],
    hotels: ["Courtyard Marriott Federal Way", "Hampton Inn & Suites Federal Way"],
    eventVenues: ["Federal Way Performing Arts and Event Center"],
    airportProximity: [
      { airport: "SEA-TAC International Airport", code: "SEA", distanceMiles: 8, driveTime: "12–20 min" },
      { airport: "Boeing Field (BFI)", code: "BFI", distanceMiles: 15, driveTime: "20–30 min" }
    ],
    popularRoutes: [
      { to: "SEA-TAC Airport", driveTime: "12–20 min", distanceMiles: 8, startingPriceUSD: 75 },
      { to: "Tacoma", driveTime: "15–25 min", distanceMiles: 10, startingPriceUSD: 85 },
      { to: "Downtown Seattle", driveTime: "25–45 min", distanceMiles: 22, startingPriceUSD: 115 }
    ],
    faqs: [
      {
        question: "How fast is a Federal Way to SEA-TAC transfer?",
        answer: "Typically 12–20 minutes door-to-door. Sedan service starts at $75 flat-rate."
      }
    ],
    meta: {
      title: "Federal Way Chauffeur Service | Emerald City Limos",
      description: "Luxury chauffeur service in Federal Way, WA. Fast SEA-TAC transfers, event transportation, corporate accounts — booked 24/7.",
      keywords: ["federal way chauffeur", "federal way limo service", "federal way airport transfer"]
    }
  },
  {
    name: "Sammamish",
    slug: "sammamish",
    county: "King County",
    coordinates: { lat: 47.6163, lng: -122.0356 },
    zipCodes: ["98074", "98075"],
    heroImage: HERO_DEFAULT,
    heroImageAlt: "Black luxury chauffeur sedan in front of a Sammamish estate at twilight",
    heroSupporting: "Discreet chauffeur service across Sammamish — Pine Lake, Klahanie, Trossachs — with flight-tracked SEA-TAC transfers and executive accounts.",
    localValueProp: "Sammamish is one of King County’s most established residential communities — quiet, deliberate, and home to a steady roster of executives commuting to Microsoft, Google Kirkland, and downtown Seattle. Our chauffeurs run flight-tracked airport transfers for residents, hourly chauffeur for full-day client visits across the Eastside, and special-occasion stretch limousine service for milestone birthdays and weddings at Pine Lake and Beaver Lake venues. We honor a quiet curbside protocol — no horn taps, no loud arrivals — at residential pickups.",
    nearbyLandmarks: ["Pine Lake", "Beaver Lake", "Sammamish Commons", "Klahanie"],
    businessDistricts: ["Sammamish Plateau"],
    airportProximity: [
      { airport: "SEA-TAC International Airport", code: "SEA", distanceMiles: 22, driveTime: "30–45 min" },
      { airport: "Boeing Field (BFI)", code: "BFI", distanceMiles: 19, driveTime: "28–40 min" }
    ],
    popularRoutes: [
      { to: "SEA-TAC Airport", driveTime: "30–45 min", distanceMiles: 22, startingPriceUSD: 115 },
      { to: "Bellevue", driveTime: "15–25 min", distanceMiles: 10, startingPriceUSD: 85 },
      { to: "Microsoft Redmond Campus", driveTime: "15–25 min", distanceMiles: 8, startingPriceUSD: 85 },
      { to: "Downtown Seattle", driveTime: "25–45 min", distanceMiles: 19, startingPriceUSD: 115 }
    ],
    faqs: [
      {
        question: "Do you serve all of Sammamish, including Klahanie and Trossachs?",
        answer: "Yes — every Sammamish neighborhood at flat-rate pricing."
      },
      {
        question: "How much is a Sammamish to SEA-TAC transfer?",
        answer: "Sedan service from Sammamish to SEA-TAC starts at $115 flat-rate; luxury SUVs from $140."
      }
    ],
    meta: {
      title: "Sammamish Chauffeur Service | Emerald City Limos",
      description: "Luxury chauffeur service in Sammamish, WA. Flight-tracked SEA-TAC transfers, executive accounts, special occasions — booked 24/7.",
      keywords: ["sammamish chauffeur", "sammamish limo service", "sammamish airport transfer"]
    }
  },
  {
    name: "Kent",
    slug: "kent",
    county: "King County",
    coordinates: { lat: 47.3809, lng: -122.2348 },
    zipCodes: ["98030", "98031", "98032", "98042"],
    heroImage: HERO_DEFAULT,
    heroImageAlt: "Black luxury chauffeur sedan at the ShoWare Center in Kent",
    heroSupporting: "Chauffeur service across Kent — accesso ShoWare Center, the Kent Valley industrial corridor, Riverbend Golf Complex — with fast SEA-TAC transfers.",
    localValueProp: "Kent is the logistics spine of the Puget Sound. The Kent Valley industrial corridor moves more freight than most U.S. cities its size, and our chauffeurs serve the executives and visiting clients who keep that operation running. We also handle event transportation for accesso ShoWare Center concerts and Seattle Thunderbirds games, plus airport transfers timed against I-5 and SR-167 patterns.",
    nearbyLandmarks: ["accesso ShoWare Center", "Kent Station", "Riverbend Golf Complex", "Lake Meridian Park"],
    businessDistricts: ["Kent Valley industrial corridor", "Kent Station", "East Hill"],
    hotels: ["Best Western Plus Kent / Seattle Area"],
    eventVenues: ["accesso ShoWare Center"],
    airportProximity: [
      { airport: "SEA-TAC International Airport", code: "SEA", distanceMiles: 9, driveTime: "15–25 min" },
      { airport: "Boeing Field (BFI)", code: "BFI", distanceMiles: 12, driveTime: "18–30 min" }
    ],
    popularRoutes: [
      { to: "SEA-TAC Airport", driveTime: "15–25 min", distanceMiles: 9, startingPriceUSD: 85 },
      { to: "Downtown Seattle", driveTime: "25–45 min", distanceMiles: 19, startingPriceUSD: 110 },
      { to: "Tacoma", driveTime: "20–35 min", distanceMiles: 15, startingPriceUSD: 95 }
    ],
    faqs: [
      {
        question: "How much is a Kent to SEA-TAC transfer?",
        answer: "Sedan service from Kent to SEA-TAC starts at $85 flat-rate; luxury SUVs from $105."
      },
      {
        question: "Do you serve accesso ShoWare Center events?",
        answer: "Yes — concerts, hockey games, family shows. Group transportation in Mercedes Sprinter vans available."
      }
    ],
    meta: {
      title: "Kent Chauffeur Service | Emerald City Limos",
      description: "Luxury chauffeur service in Kent, WA. Fast SEA-TAC transfers, ShoWare Center events, corporate accounts — flat-rate, 24/7.",
      keywords: ["kent chauffeur", "kent limo service", "kent airport transfer", "showare center transportation"]
    }
  },
  {
    name: "Lakewood",
    slug: "lakewood",
    county: "Pierce County",
    coordinates: { lat: 47.1718, lng: -122.5185 },
    zipCodes: ["98498", "98499"],
    heroImage: HERO_DEFAULT,
    heroImageAlt: "Black luxury chauffeur SUV at the gates of Joint Base Lewis-McChord",
    heroSupporting: "Chauffeur service across Lakewood and Joint Base Lewis-McChord — flight-tracked SEA-TAC transfers, military relocations, Pierce College pickups.",
    localValueProp: "Lakewood lives next to Joint Base Lewis-McChord (JBLM), and our service reflects that. We run chauffeur transfers for incoming and outgoing military personnel and their families, often timed against PCS move logistics, plus standard airport transfers from the broader Lakewood community to SEA-TAC. Our chauffeurs know the JBLM gate access procedures and stage at the correct gates for visitor arrivals.",
    nearbyLandmarks: ["Joint Base Lewis-McChord", "Lakewood Towne Center", "American Lake", "Fort Steilacoom Park"],
    businessDistricts: ["Lakewood Towne Center", "JBLM corridor"],
    hotels: ["La Quinta Inn & Suites Tacoma – Seattle"],
    airportProximity: [
      { airport: "SEA-TAC International Airport", code: "SEA", distanceMiles: 28, driveTime: "40–60 min" },
      { airport: "Boeing Field (BFI)", code: "BFI", distanceMiles: 33, driveTime: "45–60 min" }
    ],
    popularRoutes: [
      { to: "SEA-TAC Airport", driveTime: "40–60 min", distanceMiles: 28, startingPriceUSD: 145 },
      { to: "Joint Base Lewis-McChord", driveTime: "5–15 min", distanceMiles: 4, startingPriceUSD: 65 },
      { to: "Tacoma", driveTime: "10–20 min", distanceMiles: 9, startingPriceUSD: 75 }
    ],
    faqs: [
      {
        question: "Do you serve Joint Base Lewis-McChord (JBLM)?",
        answer: "Yes — daily. Our chauffeurs know the gate access procedures for visitors and contractors, and we run transfers timed against PCS arrival schedules."
      },
      {
        question: "How much is a Lakewood to SEA-TAC transfer?",
        answer: "Sedan service from Lakewood to SEA-TAC starts at $145 flat-rate; luxury SUVs from $175."
      }
    ],
    meta: {
      title: "Lakewood Chauffeur Service | Emerald City Limos",
      description: "Luxury chauffeur service in Lakewood, WA. JBLM transfers, SEA-TAC airport runs, military and corporate accounts — booked 24/7.",
      keywords: ["lakewood chauffeur", "lakewood limo service", "jblm car service", "lakewood airport transfer"]
    }
  },
  {
    name: "Puyallup",
    slug: "puyallup",
    county: "Pierce County",
    coordinates: { lat: 47.1854, lng: -122.2929 },
    zipCodes: ["98371", "98372", "98373", "98374", "98375"],
    heroImage: HERO_DEFAULT,
    heroImageAlt: "Black luxury chauffeur SUV at the Washington State Fair entrance in Puyallup",
    heroSupporting: "Chauffeur service across Puyallup — the Washington State Fair, the Puyallup Fairgrounds, South Hill — with flat-rate SEA-TAC transfers.",
    localValueProp: "Puyallup hosts the Washington State Fair — the largest single-attraction event in the state — every September, and our chauffeurs handle the surge with Mercedes Sprinter executive vans, Cadillac Escalade ESVs, and stretch limousines. Beyond fair season, we run flat-rate airport transfers from South Hill and downtown Puyallup, hourly chauffeur for vendor events at the fairgrounds, and special-occasion service for weddings at the historic Pioneer Park.",
    nearbyLandmarks: ["Washington State Fair / Puyallup Fairgrounds", "Pioneer Park", "South Hill Mall"],
    businessDistricts: ["Downtown Puyallup", "South Hill"],
    eventVenues: ["Washington State Fairgrounds", "Pioneer Park"],
    airportProximity: [
      { airport: "SEA-TAC International Airport", code: "SEA", distanceMiles: 22, driveTime: "30–50 min" }
    ],
    popularRoutes: [
      { to: "SEA-TAC Airport", driveTime: "30–50 min", distanceMiles: 22, startingPriceUSD: 125 },
      { to: "Tacoma", driveTime: "15–25 min", distanceMiles: 11, startingPriceUSD: 85 },
      { to: "Downtown Seattle", driveTime: "40–60 min", distanceMiles: 35, startingPriceUSD: 155 }
    ],
    faqs: [
      {
        question: "Do you serve the Washington State Fair?",
        answer: "Yes — daily during the fair. We strongly recommend booking 2+ weeks ahead during fair season as Mercedes Sprinters and stretch limousines book out."
      },
      {
        question: "How much is a Puyallup to SEA-TAC transfer?",
        answer: "Sedan service from Puyallup to SEA-TAC starts at $125 flat-rate; luxury SUVs from $155."
      }
    ],
    meta: {
      title: "Puyallup Chauffeur Service | Emerald City Limos",
      description: "Luxury chauffeur service in Puyallup, WA. Washington State Fair transportation, SEA-TAC transfers, weddings — booked 24/7.",
      keywords: ["puyallup chauffeur", "puyallup limo service", "washington state fair transportation", "puyallup airport transfer"]
    }
  },
  {
    name: "Marysville",
    slug: "marysville",
    county: "Snohomish County",
    coordinates: { lat: 48.0518, lng: -122.1771 },
    zipCodes: ["98270", "98271"],
    heroImage: HERO_DEFAULT,
    heroImageAlt: "Black luxury chauffeur sedan at the Tulalip Resort Casino entrance in Marysville",
    heroSupporting: "Chauffeur service across Marysville — Tulalip Resort Casino, Seattle Premium Outlets, Boeing — with flat-rate SEA-TAC and Paine Field transfers.",
    localValueProp: "Marysville and the Tulalip Reservation draw a steady stream of casino, outlet-mall, and Boeing supplier visitors year-round. We run chauffeur service to and from Tulalip Resort Casino in Cadillac Escalade ESVs and stretch limousines, handle Seattle Premium Outlets shopping runs, and provide flight-tracked transfers to both Paine Field and SEA-TAC.",
    nearbyLandmarks: ["Tulalip Resort Casino", "Seattle Premium Outlets", "Hibulb Cultural Center"],
    businessDistricts: ["Downtown Marysville", "Smokey Point"],
    hotels: ["Tulalip Resort Casino Hotel"],
    eventVenues: ["Tulalip Amphitheatre"],
    airportProximity: [
      { airport: "Paine Field (PAE)", code: "PAE", distanceMiles: 13, driveTime: "18–28 min" },
      { airport: "SEA-TAC International Airport", code: "SEA", distanceMiles: 41, driveTime: "50–70 min" }
    ],
    popularRoutes: [
      { to: "SEA-TAC Airport", driveTime: "50–70 min", distanceMiles: 41, startingPriceUSD: 175 },
      { to: "Paine Field", driveTime: "18–28 min", distanceMiles: 13, startingPriceUSD: 95 },
      { to: "Tulalip Resort Casino", driveTime: "5–10 min", distanceMiles: 2, startingPriceUSD: 65 }
    ],
    faqs: [
      {
        question: "Do you serve Tulalip Resort Casino?",
        answer: "Yes — 24/7. Sedan, SUV, and stretch limousine availability with 30 minutes notice."
      },
      {
        question: "How much is a Marysville to SEA-TAC transfer?",
        answer: "Sedan service from Marysville to SEA-TAC starts at $175 flat-rate; luxury SUVs from $210."
      }
    ],
    meta: {
      title: "Marysville Chauffeur Service | Emerald City Limos",
      description: "Luxury chauffeur service in Marysville, WA. Tulalip Resort Casino, SEA-TAC and Paine Field transfers — flat-rate, booked 24/7.",
      keywords: ["marysville chauffeur", "marysville limo service", "tulalip casino car service", "marysville airport transfer"]
    }
  },
  {
    name: "SeaTac Airport",
    slug: "seatac-airport",
    county: "King County",
    coordinates: { lat: 47.4502, lng: -122.3088 },
    zipCodes: ["98148", "98158", "98168", "98188"],
    heroImage: HERO_DEFAULT,
    heroImageAlt: "Black luxury chauffeur SUV at the SeaTac Airport arrivals curb at twilight",
    heroSupporting: "SEA-TAC airport chauffeur service — flight-tracked, business-attired chauffeurs at arrivals or baggage claim with sign-in-hand meet-and-greet.",
    localValueProp: "SEA-TAC International Airport (SEA) handles 50+ million passengers a year, and our airport service is built for that scale. Every airport ride includes live flight tracking, a 60-minute domestic / 90-minute international grace period, and a chauffeur in business attire. For arrivals, choose curbside (Door 00 / Door 30) or the indoor meet-and-greet at baggage claim where your chauffeur will be holding a discreet placard with your name. For departures, we monitor TSA wait times and adjust pickup so you have buffer at the gate.",
    nearbyLandmarks: [
      "SEA-TAC International Airport",
      "Westfield Southcenter",
      "Angle Lake Park",
      "Sound Transit SEA-TAC Link station"
    ],
    businessDistricts: ["SEA-TAC Airport campus", "Tukwila Southcenter"],
    hotels: [
      "DoubleTree by Hilton Seattle Airport",
      "Hilton Seattle Airport",
      "Marriott Seattle Airport",
      "Hyatt Regency Seattle Airport"
    ],
    airportProximity: [
      { airport: "SEA-TAC International Airport", code: "SEA", distanceMiles: 0, driveTime: "On-site" },
      { airport: "Boeing Field (BFI)", code: "BFI", distanceMiles: 7, driveTime: "12–18 min" }
    ],
    popularRoutes: [
      { from: "SEA-TAC Airport", to: "Downtown Seattle", driveTime: "20–30 min", distanceMiles: 13, startingPriceUSD: 75 },
      { from: "SEA-TAC Airport", to: "Bellevue", driveTime: "25–40 min", distanceMiles: 17, startingPriceUSD: 95 },
      { from: "SEA-TAC Airport", to: "Pier 91 Cruise Terminal", driveTime: "25–40 min", distanceMiles: 17, startingPriceUSD: 95 },
      { from: "SEA-TAC Airport", to: "Redmond", driveTime: "30–45 min", distanceMiles: 22, startingPriceUSD: 110 },
      { from: "SEA-TAC Airport", to: "Tacoma", driveTime: "30–50 min", distanceMiles: 21, startingPriceUSD: 115 }
    ],
    faqs: [
      {
        question: "Do you offer meet-and-greet at SEA-TAC baggage claim?",
        answer: "Yes — international arrivals receive complimentary indoor meet-and-greet at baggage claim. Domestic meet-and-greet is available on request."
      },
      {
        question: "What if my flight is delayed?",
        answer: "Every airport ride includes live flight tracking. We adjust your chauffeur’s arrival automatically — no rebooking, no extra fees for the standard grace period."
      },
      {
        question: "Where do you pick up at SEA-TAC?",
        answer: "Curbside at Door 00 (north end) or Door 30 (south end), depending on your airline. International arrivals: indoor meet-and-greet at baggage claim. We confirm your exact pickup point by text once you land."
      }
    ],
    meta: {
      title: "SEA-TAC Airport Chauffeur Service | Emerald City Limos",
      description: "SEA-TAC Airport chauffeur service. Flight-tracked, meet-and-greet at baggage claim, business-attired chauffeurs — flat-rate, booked 24/7.",
      keywords: ["sea-tac chauffeur", "sea-tac airport transfer", "seatac car service", "seatac meet and greet"]
    }
  },
  {
    name: "Boeing Field",
    slug: "boeing-field",
    county: "King County",
    coordinates: { lat: 47.5298, lng: -122.3019 },
    zipCodes: ["98108"],
    heroImage: HERO_DEFAULT,
    heroImageAlt: "Black luxury chauffeur SUV staged at a Boeing Field private aviation FBO",
    heroSupporting: "Private aviation chauffeur service at Boeing Field (KBFI) — Signature, Modern Aviation, and the Galvin Flying FBO ramp — discreet, on-tarmac when authorized.",
    localValueProp: "Boeing Field (King County International Airport, KBFI) is Seattle’s primary private aviation gateway, hosting Signature Flight Support, Modern Aviation, Galvin Flying, and Clay Lacy. Our chauffeurs run on FBO time — staged in the lobby ten minutes before your wheels-down, on the ramp itself when your flight crew authorizes vehicle access, and through the gate without delay. We coordinate with line crews on aircraft tail numbers, monitor ADS-B for actual arrival, and handle multi-leg trip support when you’re continuing to a meeting in Bellevue or Redmond.",
    nearbyLandmarks: ["Boeing Field (KBFI)", "The Museum of Flight", "Signature Flight Support BFI", "Modern Aviation BFI"],
    businessDistricts: ["Boeing Field FBO ramps", "Georgetown", "SoDo"],
    airportProximity: [
      { airport: "Boeing Field (BFI)", code: "BFI", distanceMiles: 0, driveTime: "On-site" },
      { airport: "SEA-TAC International Airport", code: "SEA", distanceMiles: 7, driveTime: "12–18 min" }
    ],
    popularRoutes: [
      { from: "Boeing Field", to: "Downtown Seattle", driveTime: "12–18 min", distanceMiles: 6, startingPriceUSD: 75 },
      { from: "Boeing Field", to: "Bellevue", driveTime: "20–30 min", distanceMiles: 13, startingPriceUSD: 95 },
      { from: "Boeing Field", to: "Redmond", driveTime: "25–40 min", distanceMiles: 18, startingPriceUSD: 110 },
      { from: "Boeing Field", to: "SEA-TAC Airport", driveTime: "12–18 min", distanceMiles: 7, startingPriceUSD: 75 }
    ],
    faqs: [
      {
        question: "Can you meet me on the ramp at Boeing Field?",
        answer: "Yes — ramp access requires FBO authorization on your tail number, but we coordinate with Signature, Modern Aviation, and Galvin Flying line crews routinely."
      },
      {
        question: "Do you handle multi-leg private aviation trips?",
        answer: "Yes — Boeing Field arrival, ground transport to a Bellevue meeting, return to BFI for the next departure. We hold your chauffeur on standby for the full trip."
      }
    ],
    meta: {
      title: "Boeing Field Chauffeur Service | Emerald City Limos",
      description: "Private aviation chauffeur service at Boeing Field (KBFI). FBO ramp access, multi-leg trip support, business-attired chauffeurs — booked 24/7.",
      keywords: ["boeing field chauffeur", "kbfi chauffeur", "private aviation seattle", "fbo ramp transfer"]
    }
  }
];
locations.forEach((loc) => {
  loc.heroImage = HERO_IMAGES[loc.slug] ?? HERO_DEFAULT;
});
Object.fromEntries(locations.map((loc) => [loc.slug, loc]));
locations.map((loc) => loc.slug);

export { $$LocationLayout as $, $$LocationCTA as a, locations as l };

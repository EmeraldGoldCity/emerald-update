import { b as createAstro, c as createComponent, r as renderComponent, a as renderTemplate, m as maybeRenderHead, e as renderSlot } from './astro/server_DL3Tye_C.mjs';
import 'piccolore';
import { c as createLucideIcon, P as Phone, M as MapPin, $ as $$BaseLayout, N as Navigation } from './Navigation_Dndl7_vA.mjs';
import { jsxs, jsx } from 'react/jsx-runtime';

/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const __iconNode$2 = [
  [
    "path",
    { d: "M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z", key: "1jg4f8" }
  ]
];
const Facebook = createLucideIcon("facebook", __iconNode$2);

/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const __iconNode$1 = [
  ["rect", { width: "20", height: "20", x: "2", y: "2", rx: "5", ry: "5", key: "2e1cvw" }],
  ["path", { d: "M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z", key: "9exkf1" }],
  ["line", { x1: "17.5", x2: "17.51", y1: "6.5", y2: "6.5", key: "r4j83e" }]
];
const Instagram = createLucideIcon("instagram", __iconNode$1);

/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const __iconNode = [
  ["rect", { width: "20", height: "16", x: "2", y: "4", rx: "2", key: "18n3k1" }],
  ["path", { d: "m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7", key: "1ocrg3" }]
];
const Mail = createLucideIcon("mail", __iconNode);

const TikTokIcon = () => /* @__PURE__ */ jsx("svg", { className: "h-4 w-4", fill: "currentColor", viewBox: "0 0 24 24", "aria-hidden": "true", children: /* @__PURE__ */ jsx("path", { d: "M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-2.88 2.5 2.89 2.89 0 0 1-2.89-2.89 2.89 2.89 0 0 1 2.89-2.89c.28 0 .54.04.79.1V9.01a6.33 6.33 0 0 0-.79-.05 6.34 6.34 0 0 0-6.34 6.34 6.34 6.34 0 0 0 6.34 6.34 6.34 6.34 0 0 0 6.33-6.34V8.69a8.18 8.18 0 0 0 4.78 1.52V6.75a4.85 4.85 0 0 1-1.01-.06z" }) });
const YouTubeIcon = () => /* @__PURE__ */ jsx("svg", { className: "h-4 w-4", fill: "currentColor", viewBox: "0 0 24 24", "aria-hidden": "true", children: /* @__PURE__ */ jsx("path", { d: "M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z" }) });
const PHONE_DISPLAY = "(206) 595-9675";
const PHONE_TEL = "tel:+12065959675";
const EMAIL = "client@emeraldcitylimos.com";
const QUICK_LINKS = [
  { href: "/", label: "Home" },
  { href: "/services", label: "Services" },
  { href: "/fleet", label: "Fleet" },
  { href: "/locations", label: "Locations" },
  { href: "/blog", label: "Blog" },
  { href: "/affiliates", label: "Affiliates" }
];
const SERVICE_LINKS = [
  { href: "/airport-transfers", label: "Airport Transfers" },
  { href: "/service/executive-transportation", label: "Executive Transport" },
  { href: "/service/wedding-transportation", label: "Weddings" },
  { href: "/service/hourly-charters", label: "Hourly Charters" },
  { href: "/service/cruise-transportation", label: "Cruise Transfers" },
  { href: "/service/game-day-transport", label: "Game Day" },
  { href: "/service/special-occasions", label: "Special Occasions" },
  { href: "/service/infant-car-seats", label: "Infant & Booster Seats" }
];
const SOCIALS = [
  { href: "https://www.facebook.com/emeraldcitylimos", label: "Facebook", Icon: Facebook },
  { href: "https://www.instagram.com/emeraldcitylimos", label: "Instagram", Icon: Instagram },
  { href: "https://www.tiktok.com/@emeraldcitylimos", label: "TikTok", Icon: TikTokIcon },
  { href: "https://www.youtube.com/@emeraldcitylimos", label: "YouTube", Icon: YouTubeIcon }
];
function Footer() {
  const year = (/* @__PURE__ */ new Date()).getFullYear();
  return /* @__PURE__ */ jsxs(
    "footer",
    {
      className: "relative bg-brand-forest text-white",
      "aria-labelledby": "footer-heading",
      children: [
        /* @__PURE__ */ jsx("h2", { id: "footer-heading", className: "sr-only", children: "Site footer" }),
        /* @__PURE__ */ jsx(
          "div",
          {
            className: "absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-brand-gold-soft to-transparent",
            "aria-hidden": "true"
          }
        ),
        /* @__PURE__ */ jsxs("div", { className: "mx-auto max-w-7xl px-6 pb-10 pt-16 sm:px-8 sm:pb-12 sm:pt-20 lg:pt-24", children: [
          /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 gap-12 md:grid-cols-2 md:gap-10 lg:grid-cols-12 lg:gap-12", children: [
            /* @__PURE__ */ jsxs("div", { className: "md:col-span-2 lg:col-span-4", children: [
              /* @__PURE__ */ jsxs(
                "a",
                {
                  href: "/",
                  "aria-label": "Emerald City Limos — home",
                  className: "ecl-focusable inline-block",
                  children: [
                    /* @__PURE__ */ jsx("span", { className: "block font-sans text-xs font-semibold uppercase tracking-widest text-brand-gold", children: "Established 2010" }),
                    /* @__PURE__ */ jsxs("span", { className: "mt-3 block font-display text-3xl font-light leading-none tracking-tight text-white sm:text-4xl", children: [
                      "Emerald City",
                      " ",
                      /* @__PURE__ */ jsx("em", { className: "italic text-brand-gold-soft", children: "Limos" })
                    ] })
                  ]
                }
              ),
              /* @__PURE__ */ jsx("p", { className: "mt-5 max-w-sm font-sans text-sm font-light leading-relaxed text-white/65", children: "Premium chauffeur service for the Greater Seattle area — discreet, precise, and on time. Available 24/7." }),
              /* @__PURE__ */ jsx("ul", { role: "list", className: "mt-7 flex items-center gap-3", children: SOCIALS.map(({ href, label, Icon }) => /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(
                "a",
                {
                  href,
                  target: "_blank",
                  rel: "noopener noreferrer",
                  "aria-label": `${label} (opens in a new tab)`,
                  className: "ecl-focusable inline-flex h-10 w-10 items-center justify-center border border-white/15 text-white/70 transition-colors duration-300 hover:border-brand-gold hover:text-brand-gold",
                  children: /* @__PURE__ */ jsx(Icon, { className: "h-4 w-4", "aria-hidden": "true" })
                }
              ) }, label)) })
            ] }),
            /* @__PURE__ */ jsxs("nav", { "aria-labelledby": "footer-explore", className: "lg:col-span-2", children: [
              /* @__PURE__ */ jsx(
                "h3",
                {
                  id: "footer-explore",
                  className: "font-sans text-xs font-semibold uppercase tracking-widest text-brand-gold",
                  children: "Explore"
                }
              ),
              /* @__PURE__ */ jsx("ul", { role: "list", className: "mt-5 space-y-3", children: QUICK_LINKS.map(({ href, label }) => /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(
                "a",
                {
                  href,
                  className: "ecl-focusable font-sans text-sm font-light text-white/75 transition-colors duration-300 hover:text-brand-gold",
                  children: label
                }
              ) }, href)) })
            ] }),
            /* @__PURE__ */ jsxs("nav", { "aria-labelledby": "footer-services", className: "lg:col-span-3", children: [
              /* @__PURE__ */ jsx(
                "h3",
                {
                  id: "footer-services",
                  className: "font-sans text-xs font-semibold uppercase tracking-widest text-brand-gold",
                  children: "Services"
                }
              ),
              /* @__PURE__ */ jsx("ul", { role: "list", className: "mt-5 space-y-3", children: SERVICE_LINKS.map(({ href, label }) => /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(
                "a",
                {
                  href,
                  className: "ecl-focusable font-sans text-sm font-light text-white/75 transition-colors duration-300 hover:text-brand-gold",
                  children: label
                }
              ) }, href)) })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "lg:col-span-3", children: [
              /* @__PURE__ */ jsx("h3", { className: "font-sans text-xs font-semibold uppercase tracking-widest text-brand-gold", children: "Contact" }),
              /* @__PURE__ */ jsx("address", { className: "mt-5 not-italic", children: /* @__PURE__ */ jsxs("ul", { role: "list", className: "space-y-4", children: [
                /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsxs(
                  "a",
                  {
                    href: PHONE_TEL,
                    className: "ecl-focusable inline-flex items-start gap-3 font-sans text-sm font-light text-white/75 transition-colors duration-300 hover:text-brand-gold",
                    children: [
                      /* @__PURE__ */ jsx(
                        Phone,
                        {
                          className: "mt-0.5 h-4 w-4 flex-shrink-0 text-brand-gold",
                          "aria-hidden": "true"
                        }
                      ),
                      /* @__PURE__ */ jsx("span", { className: "tabular-nums", children: PHONE_DISPLAY })
                    ]
                  }
                ) }),
                /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsxs(
                  "a",
                  {
                    href: `mailto:${EMAIL}`,
                    className: "ecl-focusable inline-flex items-start gap-3 break-all font-sans text-sm font-light text-white/75 transition-colors duration-300 hover:text-brand-gold",
                    children: [
                      /* @__PURE__ */ jsx(
                        Mail,
                        {
                          className: "mt-0.5 h-4 w-4 flex-shrink-0 text-brand-gold",
                          "aria-hidden": "true"
                        }
                      ),
                      /* @__PURE__ */ jsx("span", { children: EMAIL })
                    ]
                  }
                ) }),
                /* @__PURE__ */ jsxs("li", { className: "inline-flex items-start gap-3 font-sans text-sm font-light text-white/75", children: [
                  /* @__PURE__ */ jsx(
                    MapPin,
                    {
                      className: "mt-0.5 h-4 w-4 flex-shrink-0 text-brand-gold",
                      "aria-hidden": "true"
                    }
                  ),
                  /* @__PURE__ */ jsx("span", { children: "Seattle, WA" })
                ] })
              ] }) })
            ] })
          ] }),
          /* @__PURE__ */ jsx("div", { className: "mt-14 border-t border-white/10 pt-8 sm:mt-16", children: /* @__PURE__ */ jsxs("div", { className: "flex flex-col items-center justify-between gap-4 text-center sm:flex-row sm:text-left", children: [
            /* @__PURE__ */ jsxs("p", { className: "font-sans text-xs font-light text-white/50", children: [
              "©",
              " ",
              /* @__PURE__ */ jsx("time", { dateTime: String(year), children: year }),
              " ",
              "Emerald City Limos. All rights reserved."
            ] }),
            /* @__PURE__ */ jsxs("ul", { role: "list", className: "flex flex-wrap items-center justify-center gap-x-6 gap-y-2", children: [
              /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(
                "a",
                {
                  href: "/sitemap.xml",
                  className: "ecl-focusable font-sans text-xs font-light text-white/50 transition-colors duration-300 hover:text-brand-gold",
                  children: "Sitemap"
                }
              ) }),
              /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(
                "a",
                {
                  href: PHONE_TEL,
                  className: "ecl-focusable font-sans text-xs font-light tabular-nums text-white/50 transition-colors duration-300 hover:text-brand-gold",
                  children: PHONE_DISPLAY
                }
              ) })
            ] })
          ] }) })
        ] })
      ]
    }
  );
}

const $$Astro = createAstro("https://emeraldcitylimos.com");
const $$MainLayout = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$MainLayout;
  const props = Astro2.props;
  return renderTemplate`${renderComponent($$result, "BaseLayout", $$BaseLayout, { ...props }, { "default": ($$result2) => renderTemplate`  ${maybeRenderHead()}<a href="#main-content" class="skip-link sr-only-focusable">
Skip to main content
</a>  ${renderComponent($$result2, "Navigation", Navigation, { "client:load": true, "client:component-hydration": "load", "client:component-path": "@/components/react/Navigation", "client:component-export": "Navigation" })}  <main id="main-content" role="main"> ${renderSlot($$result2, $$slots["default"])} </main>  ${renderComponent($$result2, "Footer", Footer, {})} ` })}`;
}, "/home/josh/Documents/emerald-update/src/layouts/MainLayout.astro", void 0);

export { $$MainLayout as $, Mail as M };
